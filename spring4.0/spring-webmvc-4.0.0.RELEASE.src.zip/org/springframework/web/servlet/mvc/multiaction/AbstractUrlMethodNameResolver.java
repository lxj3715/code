/*     */ package org.springframework.web.servlet.mvc.multiaction;
/*     */ 
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ public abstract class AbstractUrlMethodNameResolver
/*     */   implements MethodNameResolver
/*     */ {
/*  41 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  43 */   private UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */ 
/*     */   public void setAlwaysUseFullPath(boolean alwaysUseFullPath)
/*     */   {
/*  54 */     this.urlPathHelper.setAlwaysUseFullPath(alwaysUseFullPath);
/*     */   }
/*     */ 
/*     */   public void setUrlDecode(boolean urlDecode)
/*     */   {
/*  66 */     this.urlPathHelper.setUrlDecode(urlDecode);
/*     */   }
/*     */ 
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/*  77 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/*  78 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */ 
/*     */   public final String getHandlerMethodName(HttpServletRequest request)
/*     */     throws NoSuchRequestHandlingMethodException
/*     */   {
/*  92 */     String urlPath = this.urlPathHelper.getLookupPathForRequest(request);
/*  93 */     String name = getHandlerMethodNameForUrlPath(urlPath);
/*  94 */     if (name == null) {
/*  95 */       throw new NoSuchRequestHandlingMethodException(urlPath, request.getMethod(), request.getParameterMap());
/*     */     }
/*  97 */     if (this.logger.isDebugEnabled()) {
/*  98 */       this.logger.debug("Returning handler method name '" + name + "' for lookup path: " + urlPath);
/*     */     }
/* 100 */     return name;
/*     */   }
/*     */ 
/*     */   protected abstract String getHandlerMethodNameForUrlPath(String paramString);
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.multiaction.AbstractUrlMethodNameResolver
 * JD-Core Version:    0.6.2
 */