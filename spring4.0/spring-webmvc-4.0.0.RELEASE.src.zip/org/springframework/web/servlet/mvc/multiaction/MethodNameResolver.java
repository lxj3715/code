package org.springframework.web.servlet.mvc.multiaction;

import javax.servlet.http.HttpServletRequest;

public abstract interface MethodNameResolver
{
  public abstract String getHandlerMethodName(HttpServletRequest paramHttpServletRequest)
    throws NoSuchRequestHandlingMethodException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.multiaction.MethodNameResolver
 * JD-Core Version:    0.6.2
 */