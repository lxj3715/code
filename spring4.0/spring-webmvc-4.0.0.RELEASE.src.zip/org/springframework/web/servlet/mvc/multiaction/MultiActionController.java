/*     */ package org.springframework.web.servlet.mvc.multiaction;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.validation.ValidationUtils;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.web.HttpSessionRequiredException;
/*     */ import org.springframework.web.bind.ServletRequestDataBinder;
/*     */ import org.springframework.web.bind.support.WebBindingInitializer;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.mvc.AbstractController;
/*     */ import org.springframework.web.servlet.mvc.LastModified;
/*     */ 
/*     */ public class MultiActionController extends AbstractController
/*     */   implements LastModified
/*     */ {
/*     */   public static final String LAST_MODIFIED_METHOD_SUFFIX = "LastModified";
/*     */   public static final String DEFAULT_COMMAND_NAME = "command";
/*     */   public static final String PAGE_NOT_FOUND_LOG_CATEGORY = "org.springframework.web.servlet.PageNotFound";
/* 150 */   protected static final Log pageNotFoundLogger = LogFactory.getLog("org.springframework.web.servlet.PageNotFound");
/*     */   private Object delegate;
/* 156 */   private MethodNameResolver methodNameResolver = new InternalPathMethodNameResolver();
/*     */   private Validator[] validators;
/*     */   private WebBindingInitializer webBindingInitializer;
/* 165 */   private final Map<String, Method> handlerMethodMap = new HashMap();
/*     */ 
/* 168 */   private final Map<String, Method> lastModifiedMethodMap = new HashMap();
/*     */ 
/* 171 */   private final Map<Class<?>, Method> exceptionHandlerMap = new HashMap();
/*     */ 
/*     */   public MultiActionController()
/*     */   {
/* 179 */     this.delegate = this;
/* 180 */     registerHandlerMethods(this.delegate);
/*     */   }
/*     */ 
/*     */   public MultiActionController(Object delegate)
/*     */   {
/* 191 */     setDelegate(delegate);
/*     */   }
/*     */ 
/*     */   public final void setDelegate(Object delegate)
/*     */   {
/* 203 */     Assert.notNull(delegate, "Delegate must not be null");
/* 204 */     this.delegate = delegate;
/* 205 */     registerHandlerMethods(this.delegate);
/*     */ 
/* 207 */     if (this.handlerMethodMap.isEmpty())
/* 208 */       throw new IllegalStateException("No handler methods in class [" + this.delegate.getClass() + "]");
/*     */   }
/*     */ 
/*     */   public final void setMethodNameResolver(MethodNameResolver methodNameResolver)
/*     */   {
/* 217 */     this.methodNameResolver = methodNameResolver;
/*     */   }
/*     */ 
/*     */   public final MethodNameResolver getMethodNameResolver()
/*     */   {
/* 224 */     return this.methodNameResolver;
/*     */   }
/*     */ 
/*     */   public final void setValidators(Validator[] validators)
/*     */   {
/* 232 */     this.validators = validators;
/*     */   }
/*     */ 
/*     */   public final Validator[] getValidators()
/*     */   {
/* 239 */     return this.validators;
/*     */   }
/*     */ 
/*     */   public final void setWebBindingInitializer(WebBindingInitializer webBindingInitializer)
/*     */   {
/* 249 */     this.webBindingInitializer = webBindingInitializer;
/*     */   }
/*     */ 
/*     */   public final WebBindingInitializer getWebBindingInitializer()
/*     */   {
/* 257 */     return this.webBindingInitializer;
/*     */   }
/*     */ 
/*     */   private void registerHandlerMethods(Object delegate)
/*     */   {
/* 265 */     this.handlerMethodMap.clear();
/* 266 */     this.lastModifiedMethodMap.clear();
/* 267 */     this.exceptionHandlerMap.clear();
/*     */ 
/* 271 */     Method[] methods = delegate.getClass().getMethods();
/* 272 */     for (Method method : methods)
/*     */     {
/* 274 */       if (isExceptionHandlerMethod(method)) {
/* 275 */         registerExceptionHandlerMethod(method);
/*     */       }
/* 277 */       else if (isHandlerMethod(method)) {
/* 278 */         registerHandlerMethod(method);
/* 279 */         registerLastModifiedMethodIfExists(delegate, method);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isHandlerMethod(Method method)
/*     */   {
/* 290 */     Class returnType = method.getReturnType();
/* 291 */     if ((ModelAndView.class.equals(returnType)) || (Map.class.equals(returnType)) || (String.class.equals(returnType)) || 
/* 292 */       (Void.TYPE
/* 292 */       .equals(returnType)))
/*     */     {
/* 293 */       Class[] parameterTypes = method.getParameterTypes();
/*     */ 
/* 297 */       return (parameterTypes.length >= 2) && 
/* 295 */         (HttpServletRequest.class
/* 295 */         .equals(parameterTypes[0])) && 
/* 296 */         (HttpServletResponse.class
/* 296 */         .equals(parameterTypes[1])) && (
/* 297 */         (!"handleRequest"
/* 297 */         .equals(method
/* 297 */         .getName())) || (parameterTypes.length != 2));
/*     */     }
/* 299 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean isExceptionHandlerMethod(Method method)
/*     */   {
/* 308 */     return (isHandlerMethod(method)) && 
/* 307 */       (method
/* 307 */       .getParameterTypes().length == 3) && 
/* 308 */       (Throwable.class
/* 308 */       .isAssignableFrom(method
/* 308 */       .getParameterTypes()[2]));
/*     */   }
/*     */ 
/*     */   private void registerHandlerMethod(Method method)
/*     */   {
/* 315 */     if (this.logger.isDebugEnabled()) {
/* 316 */       this.logger.debug("Found action method [" + method + "]");
/*     */     }
/* 318 */     this.handlerMethodMap.put(method.getName(), method);
/*     */   }
/*     */ 
/*     */   private void registerLastModifiedMethodIfExists(Object delegate, Method method)
/*     */   {
/*     */     try
/*     */     {
/* 328 */       Method lastModifiedMethod = delegate.getClass().getMethod(method
/* 329 */         .getName() + "LastModified", new Class[] { HttpServletRequest.class });
/*     */ 
/* 331 */       Class returnType = lastModifiedMethod.getReturnType();
/* 332 */       if ((!Long.TYPE.equals(returnType)) && (!Long.class.equals(returnType))) {
/* 333 */         throw new IllegalStateException("last-modified method [" + lastModifiedMethod + "] declares an invalid return type - needs to be 'long' or 'Long'");
/*     */       }
/*     */ 
/* 337 */       this.lastModifiedMethodMap.put(method.getName(), lastModifiedMethod);
/* 338 */       if (this.logger.isDebugEnabled())
/* 339 */         this.logger.debug("Found last-modified method for handler method [" + method + "]");
/*     */     }
/*     */     catch (NoSuchMethodException ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private void registerExceptionHandlerMethod(Method method)
/*     */   {
/* 351 */     this.exceptionHandlerMap.put(method.getParameterTypes()[2], method);
/* 352 */     if (this.logger.isDebugEnabled())
/* 353 */       this.logger.debug("Found exception handler method [" + method + "]");
/*     */   }
/*     */ 
/*     */   public long getLastModified(HttpServletRequest request)
/*     */   {
/*     */     try
/*     */     {
/* 370 */       String handlerMethodName = this.methodNameResolver.getHandlerMethodName(request);
/* 371 */       Method lastModifiedMethod = (Method)this.lastModifiedMethodMap.get(handlerMethodName);
/* 372 */       if (lastModifiedMethod != null) {
/*     */         try
/*     */         {
/* 375 */           Long wrappedLong = (Long)lastModifiedMethod.invoke(this.delegate, new Object[] { request });
/* 376 */           return wrappedLong != null ? wrappedLong.longValue() : -1L;
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 381 */           this.logger.error("Failed to invoke last-modified method", ex);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (NoSuchRequestHandlingMethodException ex)
/*     */     {
/*     */     }
/*     */ 
/* 390 */     return -1L;
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 408 */       String methodName = this.methodNameResolver.getHandlerMethodName(request);
/* 409 */       return invokeNamedMethod(methodName, request, response);
/*     */     }
/*     */     catch (NoSuchRequestHandlingMethodException ex) {
/* 412 */       return handleNoSuchRequestHandlingMethod(ex, request, response);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleNoSuchRequestHandlingMethod(NoSuchRequestHandlingMethodException ex, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 431 */     pageNotFoundLogger.warn(ex.getMessage());
/* 432 */     response.sendError(404);
/* 433 */     return null;
/*     */   }
/*     */ 
/*     */   protected final ModelAndView invokeNamedMethod(String methodName, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 444 */     Method method = (Method)this.handlerMethodMap.get(methodName);
/* 445 */     if (method == null) {
/* 446 */       throw new NoSuchRequestHandlingMethodException(methodName, getClass());
/*     */     }
/*     */     try
/*     */     {
/* 450 */       Class[] paramTypes = method.getParameterTypes();
/* 451 */       List params = new ArrayList(4);
/* 452 */       params.add(request);
/* 453 */       params.add(response);
/*     */ 
/* 455 */       if ((paramTypes.length >= 3) && (paramTypes[2].equals(HttpSession.class))) {
/* 456 */         HttpSession session = request.getSession(false);
/* 457 */         if (session == null) {
/* 458 */           throw new HttpSessionRequiredException("Pre-existing session required for handler method '" + methodName + "'");
/*     */         }
/*     */ 
/* 461 */         params.add(session);
/*     */       }
/*     */ 
/* 465 */       if ((paramTypes.length >= 3) && 
/* 466 */         (!paramTypes[(paramTypes.length - 1)]
/* 466 */         .equals(HttpSession.class)))
/*     */       {
/* 467 */         Object command = newCommandObject(paramTypes[(paramTypes.length - 1)]);
/* 468 */         params.add(command);
/* 469 */         bind(request, command);
/*     */       }
/*     */ 
/* 472 */       Object returnValue = method.invoke(this.delegate, params.toArray(new Object[params.size()]));
/* 473 */       return massageReturnValueIfNecessary(returnValue);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 477 */       return handleException(request, response, ex.getTargetException());
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 481 */       return handleException(request, response, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private ModelAndView massageReturnValueIfNecessary(Object returnValue)
/*     */   {
/* 492 */     if ((returnValue instanceof ModelAndView)) {
/* 493 */       return (ModelAndView)returnValue;
/*     */     }
/* 495 */     if ((returnValue instanceof Map)) {
/* 496 */       return new ModelAndView().addAllObjects((Map)returnValue);
/*     */     }
/* 498 */     if ((returnValue instanceof String)) {
/* 499 */       return new ModelAndView((String)returnValue);
/*     */     }
/*     */ 
/* 504 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object newCommandObject(Class<?> clazz)
/*     */     throws Exception
/*     */   {
/* 518 */     if (this.logger.isDebugEnabled()) {
/* 519 */       this.logger.debug("Creating new command of class [" + clazz.getName() + "]");
/*     */     }
/* 521 */     return BeanUtils.instantiateClass(clazz);
/*     */   }
/*     */ 
/*     */   protected void bind(HttpServletRequest request, Object command)
/*     */     throws Exception
/*     */   {
/* 531 */     this.logger.debug("Binding request parameters onto MultiActionController command");
/* 532 */     ServletRequestDataBinder binder = createBinder(request, command);
/* 533 */     binder.bind(request);
/* 534 */     if (this.validators != null) {
/* 535 */       for (Validator validator : this.validators) {
/* 536 */         if (validator.supports(command.getClass())) {
/* 537 */           ValidationUtils.invokeValidator(validator, command, binder.getBindingResult());
/*     */         }
/*     */       }
/*     */     }
/* 541 */     binder.closeNoCatch();
/*     */   }
/*     */ 
/*     */   protected ServletRequestDataBinder createBinder(HttpServletRequest request, Object command)
/*     */     throws Exception
/*     */   {
/* 559 */     ServletRequestDataBinder binder = new ServletRequestDataBinder(command, getCommandName(command));
/* 560 */     initBinder(request, binder);
/* 561 */     return binder;
/*     */   }
/*     */ 
/*     */   protected String getCommandName(Object command)
/*     */   {
/* 572 */     return "command";
/*     */   }
/*     */ 
/*     */   protected void initBinder(HttpServletRequest request, ServletRequestDataBinder binder)
/*     */     throws Exception
/*     */   {
/* 593 */     if (this.webBindingInitializer != null)
/* 594 */       this.webBindingInitializer.initBinder(binder, new ServletWebRequest(request));
/*     */   }
/*     */ 
/*     */   protected Method getExceptionHandler(Throwable exception)
/*     */   {
/* 606 */     Class exceptionClass = exception.getClass();
/* 607 */     if (this.logger.isDebugEnabled()) {
/* 608 */       this.logger.debug("Trying to find handler for exception class [" + exceptionClass.getName() + "]");
/*     */     }
/* 610 */     Method handler = (Method)this.exceptionHandlerMap.get(exceptionClass);
/* 611 */     while ((handler == null) && (!exceptionClass.equals(Throwable.class))) {
/* 612 */       if (this.logger.isDebugEnabled()) {
/* 613 */         this.logger.debug("Trying to find handler for exception superclass [" + exceptionClass.getName() + "]");
/*     */       }
/* 615 */       exceptionClass = exceptionClass.getSuperclass();
/* 616 */       handler = (Method)this.exceptionHandlerMap.get(exceptionClass);
/*     */     }
/* 618 */     return handler;
/*     */   }
/*     */ 
/*     */   private ModelAndView handleException(HttpServletRequest request, HttpServletResponse response, Throwable ex)
/*     */     throws Exception
/*     */   {
/* 632 */     Method handler = getExceptionHandler(ex);
/* 633 */     if (handler != null) {
/* 634 */       if (this.logger.isDebugEnabled())
/* 635 */         this.logger.debug("Invoking exception handler [" + handler + "] for exception: " + ex);
/*     */       try
/*     */       {
/* 638 */         Object returnValue = handler.invoke(this.delegate, new Object[] { request, response, ex });
/* 639 */         return massageReturnValueIfNecessary(returnValue);
/*     */       }
/*     */       catch (InvocationTargetException ex2) {
/* 642 */         this.logger.error("Original exception overridden by exception handling failure", ex);
/* 643 */         ReflectionUtils.rethrowException(ex2.getTargetException());
/*     */       }
/*     */       catch (Exception ex2) {
/* 646 */         this.logger.error("Failed to invoke exception handler method", ex2);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 651 */       ReflectionUtils.rethrowException(ex);
/*     */     }
/* 653 */     throw new IllegalStateException("Should never get here");
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.multiaction.MultiActionController
 * JD-Core Version:    0.6.2
 */