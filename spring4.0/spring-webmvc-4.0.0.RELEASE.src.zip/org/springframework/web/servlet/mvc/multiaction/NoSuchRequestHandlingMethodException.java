/*    */ package org.springframework.web.servlet.mvc.multiaction;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.core.style.StylerUtils;
/*    */ import org.springframework.web.util.UrlPathHelper;
/*    */ 
/*    */ public class NoSuchRequestHandlingMethodException extends ServletException
/*    */ {
/*    */   private String methodName;
/*    */ 
/*    */   public NoSuchRequestHandlingMethodException(HttpServletRequest request)
/*    */   {
/* 46 */     this(new UrlPathHelper().getRequestUri(request), request.getMethod(), request.getParameterMap());
/*    */   }
/*    */ 
/*    */   public NoSuchRequestHandlingMethodException(String urlPath, String method, Map<String, String[]> parameterMap)
/*    */   {
/* 56 */     super("No matching handler method found for servlet request: path '" + urlPath + "', method '" + method + "', parameters " + 
/* 57 */       StylerUtils.style(parameterMap));
/*    */   }
/*    */ 
/*    */   public NoSuchRequestHandlingMethodException(String methodName, Class<?> controllerClass)
/*    */   {
/* 66 */     super("No request handling method with name '" + methodName + "' in class [" + controllerClass
/* 67 */       .getName() + "]");
/* 68 */     this.methodName = methodName;
/*    */   }
/*    */ 
/*    */   public String getMethodName()
/*    */   {
/* 76 */     return this.methodName;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException
 * JD-Core Version:    0.6.2
 */