/*     */ package org.springframework.web.servlet.mvc.multiaction;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ParameterMethodNameResolver
/*     */   implements MethodNameResolver
/*     */ {
/*     */   public static final String DEFAULT_PARAM_NAME = "action";
/*  93 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  95 */   private String paramName = "action";
/*     */   private String[] methodParamNames;
/*     */   private Properties logicalMappings;
/*     */   private String defaultMethodName;
/*     */ 
/*     */   public void setParamName(String paramName)
/*     */   {
/* 113 */     if (paramName != null) {
/* 114 */       Assert.hasText(paramName, "'paramName' must not be empty");
/*     */     }
/* 116 */     this.paramName = paramName;
/*     */   }
/*     */ 
/*     */   public void setMethodParamNames(String[] methodParamNames)
/*     */   {
/* 128 */     this.methodParamNames = methodParamNames;
/*     */   }
/*     */ 
/*     */   public void setLogicalMappings(Properties logicalMappings)
/*     */   {
/* 145 */     this.logicalMappings = logicalMappings;
/*     */   }
/*     */ 
/*     */   public void setDefaultMethodName(String defaultMethodName)
/*     */   {
/* 153 */     if (defaultMethodName != null) {
/* 154 */       Assert.hasText(defaultMethodName, "'defaultMethodName' must not be empty");
/*     */     }
/* 156 */     this.defaultMethodName = defaultMethodName;
/*     */   }
/*     */ 
/*     */   public String getHandlerMethodName(HttpServletRequest request)
/*     */     throws NoSuchRequestHandlingMethodException
/*     */   {
/* 162 */     String methodName = null;
/*     */ 
/* 166 */     if (this.methodParamNames != null) {
/* 167 */       for (String candidate : this.methodParamNames) {
/* 168 */         if (WebUtils.hasSubmitParameter(request, candidate)) {
/* 169 */           methodName = candidate;
/* 170 */           if (!this.logger.isDebugEnabled()) break;
/* 171 */           this.logger.debug("Determined handler method '" + methodName + "' based on existence of explicit request parameter of same name"); break;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 180 */     if ((methodName == null) && (this.paramName != null)) {
/* 181 */       methodName = request.getParameter(this.paramName);
/* 182 */       if ((methodName != null) && 
/* 183 */         (this.logger.isDebugEnabled())) {
/* 184 */         this.logger.debug("Determined handler method '" + methodName + "' based on value of request parameter '" + this.paramName + "'");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 190 */     if ((methodName != null) && (this.logicalMappings != null))
/*     */     {
/* 192 */       String originalName = methodName;
/* 193 */       methodName = this.logicalMappings.getProperty(methodName, methodName);
/* 194 */       if (this.logger.isDebugEnabled()) {
/* 195 */         this.logger.debug("Resolved method name '" + originalName + "' to handler method '" + methodName + "'");
/*     */       }
/*     */     }
/*     */ 
/* 199 */     if ((methodName != null) && (!StringUtils.hasText(methodName))) {
/* 200 */       if (this.logger.isDebugEnabled()) {
/* 201 */         this.logger.debug("Method name '" + methodName + "' is empty: treating it as no method name found");
/*     */       }
/* 203 */       methodName = null;
/*     */     }
/*     */ 
/* 206 */     if (methodName == null) {
/* 207 */       if (this.defaultMethodName != null)
/*     */       {
/* 209 */         methodName = this.defaultMethodName;
/* 210 */         if (this.logger.isDebugEnabled()) {
/* 211 */           this.logger.debug("Falling back to default handler method '" + this.defaultMethodName + "'");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 216 */         throw new NoSuchRequestHandlingMethodException(request);
/*     */       }
/*     */     }
/*     */ 
/* 220 */     return methodName;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.multiaction.ParameterMethodNameResolver
 * JD-Core Version:    0.6.2
 */