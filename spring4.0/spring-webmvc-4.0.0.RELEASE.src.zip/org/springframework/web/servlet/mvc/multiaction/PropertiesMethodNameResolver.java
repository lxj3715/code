/*    */ package org.springframework.web.servlet.mvc.multiaction;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.util.AntPathMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.PathMatcher;
/*    */ 
/*    */ public class PropertiesMethodNameResolver extends AbstractUrlMethodNameResolver
/*    */   implements InitializingBean
/*    */ {
/*    */   private Properties mappings;
/* 54 */   private PathMatcher pathMatcher = new AntPathMatcher();
/*    */ 
/*    */   public void setMappings(Properties mappings)
/*    */   {
/* 62 */     this.mappings = mappings;
/*    */   }
/*    */ 
/*    */   public void setPathMatcher(PathMatcher pathMatcher)
/*    */   {
/* 71 */     Assert.notNull(pathMatcher, "PathMatcher must not be null");
/* 72 */     this.pathMatcher = pathMatcher;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 77 */     if ((this.mappings == null) || (this.mappings.isEmpty()))
/* 78 */       throw new IllegalArgumentException("'mappings' property is required");
/*    */   }
/*    */ 
/*    */   protected String getHandlerMethodNameForUrlPath(String urlPath)
/*    */   {
/* 85 */     String methodName = this.mappings.getProperty(urlPath);
/* 86 */     if (methodName != null) {
/* 87 */       return methodName;
/*    */     }
/* 89 */     Enumeration propNames = this.mappings.propertyNames();
/* 90 */     while (propNames.hasMoreElements()) {
/* 91 */       String registeredPath = (String)propNames.nextElement();
/* 92 */       if (this.pathMatcher.match(registeredPath, urlPath)) {
/* 93 */         return (String)this.mappings.get(registeredPath);
/*    */       }
/*    */     }
/* 96 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.multiaction.PropertiesMethodNameResolver
 * JD-Core Version:    0.6.2
 */