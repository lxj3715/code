/*     */ package org.springframework.web.servlet.mvc.support;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.web.servlet.handler.AbstractDetectingUrlHandlerMapping;
/*     */ 
/*     */ public abstract class AbstractControllerUrlHandlerMapping extends AbstractDetectingUrlHandlerMapping
/*     */ {
/*  37 */   private ControllerTypePredicate predicate = new AnnotationControllerTypePredicate();
/*     */ 
/*  39 */   private Set<String> excludedPackages = Collections.singleton("org.springframework.web.servlet.mvc");
/*     */ 
/*  41 */   private Set<Class<?>> excludedClasses = Collections.emptySet();
/*     */ 
/*     */   public void setIncludeAnnotatedControllers(boolean includeAnnotatedControllers)
/*     */   {
/*  48 */     this.predicate = (includeAnnotatedControllers ? new AnnotationControllerTypePredicate() : new ControllerTypePredicate());
/*     */   }
/*     */ 
/*     */   public void setExcludedPackages(String[] excludedPackages)
/*     */   {
/*  64 */     this.excludedPackages = (excludedPackages != null ? new HashSet(
/*  65 */       Arrays.asList(excludedPackages)) : 
/*  65 */       new HashSet());
/*     */   }
/*     */ 
/*     */   public void setExcludedClasses(Class<?>[] excludedClasses)
/*     */   {
/*  73 */     this.excludedClasses = (excludedClasses != null ? new HashSet(
/*  74 */       Arrays.asList(excludedClasses)) : 
/*  74 */       new HashSet());
/*     */   }
/*     */ 
/*     */   protected String[] determineUrlsForHandler(String beanName)
/*     */   {
/*  84 */     Class beanClass = getApplicationContext().getType(beanName);
/*  85 */     if (isEligibleForMapping(beanName, beanClass)) {
/*  86 */       return buildUrlsForHandler(beanName, beanClass);
/*     */     }
/*     */ 
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean isEligibleForMapping(String beanName, Class<?> beanClass)
/*     */   {
/* 102 */     if (beanClass == null) {
/* 103 */       if (this.logger.isDebugEnabled()) {
/* 104 */         this.logger.debug("Excluding controller bean '" + beanName + "' from class name mapping " + "because its bean type could not be determined");
/*     */       }
/*     */ 
/* 107 */       return false;
/*     */     }
/* 109 */     if (this.excludedClasses.contains(beanClass)) {
/* 110 */       if (this.logger.isDebugEnabled()) {
/* 111 */         this.logger.debug("Excluding controller bean '" + beanName + "' from class name mapping " + "because its bean class is explicitly excluded: " + beanClass
/* 112 */           .getName());
/*     */       }
/* 114 */       return false;
/*     */     }
/* 116 */     String beanClassName = beanClass.getName();
/* 117 */     for (String packageName : this.excludedPackages) {
/* 118 */       if (beanClassName.startsWith(packageName)) {
/* 119 */         if (this.logger.isDebugEnabled()) {
/* 120 */           this.logger.debug("Excluding controller bean '" + beanName + "' from class name mapping " + "because its bean class is defined in an excluded package: " + beanClass
/* 121 */             .getName());
/*     */         }
/* 123 */         return false;
/*     */       }
/*     */     }
/* 126 */     return isControllerType(beanClass);
/*     */   }
/*     */ 
/*     */   protected boolean isControllerType(Class<?> beanClass)
/*     */   {
/* 135 */     return this.predicate.isControllerType(beanClass);
/*     */   }
/*     */ 
/*     */   protected boolean isMultiActionControllerType(Class<?> beanClass)
/*     */   {
/* 144 */     return this.predicate.isMultiActionControllerType(beanClass);
/*     */   }
/*     */ 
/*     */   protected abstract String[] buildUrlsForHandler(String paramString, Class<?> paramClass);
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.support.AbstractControllerUrlHandlerMapping
 * JD-Core Version:    0.6.2
 */