/*    */ package org.springframework.web.servlet.mvc.support;
/*    */ 
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.stereotype.Controller;
/*    */ 
/*    */ class AnnotationControllerTypePredicate extends ControllerTypePredicate
/*    */ {
/*    */   public boolean isControllerType(Class<?> beanClass)
/*    */   {
/* 34 */     return (super.isControllerType(beanClass)) || 
/* 34 */       (AnnotationUtils.findAnnotation(beanClass, Controller.class) != null);
/*    */   }
/*    */ 
/*    */   public boolean isMultiActionControllerType(Class<?> beanClass)
/*    */   {
/* 40 */     return (super.isMultiActionControllerType(beanClass)) || 
/* 40 */       (AnnotationUtils.findAnnotation(beanClass, Controller.class) != null);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.support.AnnotationControllerTypePredicate
 * JD-Core Version:    0.6.2
 */