/*    */ package org.springframework.web.servlet.mvc.support;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class ControllerBeanNameHandlerMapping extends AbstractControllerUrlHandlerMapping
/*    */ {
/* 43 */   private String urlPrefix = "";
/*    */ 
/* 45 */   private String urlSuffix = "";
/*    */ 
/*    */   public void setUrlPrefix(String urlPrefix)
/*    */   {
/* 54 */     this.urlPrefix = (urlPrefix != null ? urlPrefix : "");
/*    */   }
/*    */ 
/*    */   public void setUrlSuffix(String urlSuffix)
/*    */   {
/* 63 */     this.urlSuffix = (urlSuffix != null ? urlSuffix : "");
/*    */   }
/*    */ 
/*    */   protected String[] buildUrlsForHandler(String beanName, Class<?> beanClass)
/*    */   {
/* 69 */     List urls = new ArrayList();
/* 70 */     urls.add(generatePathMapping(beanName));
/* 71 */     String[] aliases = getApplicationContext().getAliases(beanName);
/* 72 */     for (String alias : aliases) {
/* 73 */       urls.add(generatePathMapping(alias));
/*    */     }
/* 75 */     return StringUtils.toStringArray(urls);
/*    */   }
/*    */ 
/*    */   protected String generatePathMapping(String beanName)
/*    */   {
/* 82 */     String name = beanName.startsWith("/") ? beanName : new StringBuilder().append("/").append(beanName).toString();
/* 83 */     StringBuilder path = new StringBuilder();
/* 84 */     if (!name.startsWith(this.urlPrefix)) {
/* 85 */       path.append(this.urlPrefix);
/*    */     }
/* 87 */     path.append(name);
/* 88 */     if (!name.endsWith(this.urlSuffix)) {
/* 89 */       path.append(this.urlSuffix);
/*    */     }
/* 91 */     return path.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.support.ControllerBeanNameHandlerMapping
 * JD-Core Version:    0.6.2
 */