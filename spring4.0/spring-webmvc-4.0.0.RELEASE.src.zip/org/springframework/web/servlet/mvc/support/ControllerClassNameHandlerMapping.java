/*     */ package org.springframework.web.servlet.mvc.support;
/*     */ 
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ControllerClassNameHandlerMapping extends AbstractControllerUrlHandlerMapping
/*     */ {
/*     */   private static final String CONTROLLER_SUFFIX = "Controller";
/*  69 */   private boolean caseSensitive = false;
/*     */   private String pathPrefix;
/*     */   private String basePackage;
/*     */ 
/*     */   public void setCaseSensitive(boolean caseSensitive)
/*     */   {
/*  83 */     this.caseSensitive = caseSensitive;
/*     */   }
/*     */ 
/*     */   public void setPathPrefix(String prefixPath)
/*     */   {
/*  93 */     this.pathPrefix = prefixPath;
/*  94 */     if (StringUtils.hasLength(this.pathPrefix)) {
/*  95 */       if (!this.pathPrefix.startsWith("/")) {
/*  96 */         this.pathPrefix = new StringBuilder().append("/").append(this.pathPrefix).toString();
/*     */       }
/*  98 */       if (this.pathPrefix.endsWith("/"))
/*  99 */         this.pathPrefix = this.pathPrefix.substring(0, this.pathPrefix.length() - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setBasePackage(String basePackage)
/*     */   {
/* 117 */     this.basePackage = basePackage;
/* 118 */     if ((StringUtils.hasLength(this.basePackage)) && (!this.basePackage.endsWith(".")))
/* 119 */       this.basePackage = new StringBuilder().append(this.basePackage).append(".").toString();
/*     */   }
/*     */ 
/*     */   protected String[] buildUrlsForHandler(String beanName, Class<?> beanClass)
/*     */   {
/* 126 */     return generatePathMappings(beanClass);
/*     */   }
/*     */ 
/*     */   protected String[] generatePathMappings(Class<?> beanClass)
/*     */   {
/* 137 */     StringBuilder pathMapping = buildPathPrefix(beanClass);
/* 138 */     String className = ClassUtils.getShortName(beanClass);
/*     */ 
/* 140 */     String path = className.endsWith("Controller") ? className
/* 140 */       .substring(0, className
/* 140 */       .lastIndexOf("Controller")) : 
/* 140 */       className;
/* 141 */     if (path.length() > 0) {
/* 142 */       if (this.caseSensitive) {
/* 143 */         pathMapping.append(path.substring(0, 1).toLowerCase()).append(path.substring(1));
/*     */       }
/*     */       else {
/* 146 */         pathMapping.append(path.toLowerCase());
/*     */       }
/*     */     }
/* 149 */     if (isMultiActionControllerType(beanClass)) {
/* 150 */       return new String[] { pathMapping.toString(), new StringBuilder().append(pathMapping.toString()).append("/*").toString() };
/*     */     }
/*     */ 
/* 153 */     return new String[] { new StringBuilder().append(pathMapping.toString()).append("*").toString() };
/*     */   }
/*     */ 
/*     */   private StringBuilder buildPathPrefix(Class<?> beanClass)
/*     */   {
/* 163 */     StringBuilder pathMapping = new StringBuilder();
/* 164 */     if (this.pathPrefix != null) {
/* 165 */       pathMapping.append(this.pathPrefix);
/* 166 */       pathMapping.append("/");
/*     */     }
/*     */     else {
/* 169 */       pathMapping.append("/");
/*     */     }
/* 171 */     if (this.basePackage != null) {
/* 172 */       String packageName = ClassUtils.getPackageName(beanClass);
/* 173 */       if (packageName.startsWith(this.basePackage)) {
/* 174 */         String subPackage = packageName.substring(this.basePackage.length()).replace('.', '/');
/* 175 */         pathMapping.append(this.caseSensitive ? subPackage : subPackage.toLowerCase());
/* 176 */         pathMapping.append("/");
/*     */       }
/*     */     }
/* 179 */     return pathMapping;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.support.ControllerClassNameHandlerMapping
 * JD-Core Version:    0.6.2
 */