/*    */ package org.springframework.web.servlet.mvc.support;
/*    */ 
/*    */ import org.springframework.web.servlet.mvc.Controller;
/*    */ import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
/*    */ 
/*    */ class ControllerTypePredicate
/*    */ {
/*    */   public boolean isControllerType(Class<?> beanClass)
/*    */   {
/* 31 */     return Controller.class.isAssignableFrom(beanClass);
/*    */   }
/*    */ 
/*    */   public boolean isMultiActionControllerType(Class<?> beanClass) {
/* 35 */     return MultiActionController.class.isAssignableFrom(beanClass);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.support.ControllerTypePredicate
 * JD-Core Version:    0.6.2
 */