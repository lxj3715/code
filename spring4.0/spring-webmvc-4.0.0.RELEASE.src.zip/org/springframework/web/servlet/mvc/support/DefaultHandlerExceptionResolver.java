/*     */ package org.springframework.web.servlet.mvc.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.ConversionNotSupportedException;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.MissingServletRequestParameterException;
/*     */ import org.springframework.web.bind.ServletRequestBindingException;
/*     */ import org.springframework.web.multipart.support.MissingServletRequestPartException;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.NoHandlerFoundException;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException;
/*     */ 
/*     */ public class DefaultHandlerExceptionResolver extends AbstractHandlerExceptionResolver
/*     */ {
/*     */   public static final String PAGE_NOT_FOUND_LOG_CATEGORY = "org.springframework.web.servlet.PageNotFound";
/*  90 */   protected static final Log pageNotFoundLogger = LogFactory.getLog("org.springframework.web.servlet.PageNotFound");
/*     */ 
/*     */   public DefaultHandlerExceptionResolver()
/*     */   {
/*  97 */     setOrder(2147483647);
/*     */   }
/*     */ 
/*     */   protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*     */   {
/*     */     try
/*     */     {
/* 106 */       if ((ex instanceof NoSuchRequestHandlingMethodException)) {
/* 107 */         return handleNoSuchRequestHandlingMethod((NoSuchRequestHandlingMethodException)ex, request, response, handler);
/*     */       }
/*     */ 
/* 110 */       if ((ex instanceof HttpRequestMethodNotSupportedException)) {
/* 111 */         return handleHttpRequestMethodNotSupported((HttpRequestMethodNotSupportedException)ex, request, response, handler);
/*     */       }
/*     */ 
/* 114 */       if ((ex instanceof HttpMediaTypeNotSupportedException)) {
/* 115 */         return handleHttpMediaTypeNotSupported((HttpMediaTypeNotSupportedException)ex, request, response, handler);
/*     */       }
/*     */ 
/* 118 */       if ((ex instanceof HttpMediaTypeNotAcceptableException)) {
/* 119 */         return handleHttpMediaTypeNotAcceptable((HttpMediaTypeNotAcceptableException)ex, request, response, handler);
/*     */       }
/*     */ 
/* 122 */       if ((ex instanceof MissingServletRequestParameterException)) {
/* 123 */         return handleMissingServletRequestParameter((MissingServletRequestParameterException)ex, request, response, handler);
/*     */       }
/*     */ 
/* 126 */       if ((ex instanceof ServletRequestBindingException)) {
/* 127 */         return handleServletRequestBindingException((ServletRequestBindingException)ex, request, response, handler);
/*     */       }
/*     */ 
/* 130 */       if ((ex instanceof ConversionNotSupportedException)) {
/* 131 */         return handleConversionNotSupported((ConversionNotSupportedException)ex, request, response, handler);
/*     */       }
/* 133 */       if ((ex instanceof TypeMismatchException)) {
/* 134 */         return handleTypeMismatch((TypeMismatchException)ex, request, response, handler);
/*     */       }
/* 136 */       if ((ex instanceof HttpMessageNotReadableException)) {
/* 137 */         return handleHttpMessageNotReadable((HttpMessageNotReadableException)ex, request, response, handler);
/*     */       }
/* 139 */       if ((ex instanceof HttpMessageNotWritableException)) {
/* 140 */         return handleHttpMessageNotWritable((HttpMessageNotWritableException)ex, request, response, handler);
/*     */       }
/* 142 */       if ((ex instanceof MethodArgumentNotValidException)) {
/* 143 */         return handleMethodArgumentNotValidException((MethodArgumentNotValidException)ex, request, response, handler);
/*     */       }
/* 145 */       if ((ex instanceof MissingServletRequestPartException)) {
/* 146 */         return handleMissingServletRequestPartException((MissingServletRequestPartException)ex, request, response, handler);
/*     */       }
/* 148 */       if ((ex instanceof BindException)) {
/* 149 */         return handleBindException((BindException)ex, request, response, handler);
/*     */       }
/* 151 */       if ((ex instanceof NoHandlerFoundException))
/* 152 */         return handleNoHandlerFoundException((NoHandlerFoundException)ex, request, response, handler);
/*     */     }
/*     */     catch (Exception handlerException)
/*     */     {
/* 156 */       this.logger.warn("Handling of [" + ex.getClass().getName() + "] resulted in Exception", handlerException);
/*     */     }
/* 158 */     return null;
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleNoSuchRequestHandlingMethod(NoSuchRequestHandlingMethodException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 177 */     pageNotFoundLogger.warn(ex.getMessage());
/* 178 */     response.sendError(404);
/* 179 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 198 */     pageNotFoundLogger.warn(ex.getMessage());
/* 199 */     String[] supportedMethods = ex.getSupportedMethods();
/* 200 */     if (supportedMethods != null) {
/* 201 */       response.setHeader("Allow", StringUtils.arrayToDelimitedString(supportedMethods, ", "));
/*     */     }
/* 203 */     response.sendError(405, ex.getMessage());
/* 204 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 222 */     response.sendError(415);
/* 223 */     List mediaTypes = ex.getSupportedMediaTypes();
/* 224 */     if (!CollectionUtils.isEmpty(mediaTypes)) {
/* 225 */       response.setHeader("Accept", MediaType.toString(mediaTypes));
/*     */     }
/* 227 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleHttpMediaTypeNotAcceptable(HttpMediaTypeNotAcceptableException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 246 */     response.sendError(406);
/* 247 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleMissingServletRequestParameter(MissingServletRequestParameterException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 265 */     response.sendError(400, ex.getMessage());
/* 266 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleServletRequestBindingException(ServletRequestBindingException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 283 */     response.sendError(400);
/* 284 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleConversionNotSupported(ConversionNotSupportedException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 301 */     sendServerError(ex, request, response);
/* 302 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected void sendServerError(Exception ex, HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/* 312 */     request.setAttribute("javax.servlet.error.exception", ex);
/* 313 */     response.sendError(500);
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleTypeMismatch(TypeMismatchException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 330 */     response.sendError(400);
/* 331 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 350 */     response.sendError(400);
/* 351 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleHttpMessageNotWritable(HttpMessageNotWritableException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 370 */     sendServerError(ex, request, response);
/* 371 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleMethodArgumentNotValidException(MethodArgumentNotValidException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 386 */     response.sendError(400);
/* 387 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleMissingServletRequestPartException(MissingServletRequestPartException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 402 */     response.sendError(400, ex.getMessage());
/* 403 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleBindException(BindException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 419 */     response.sendError(400);
/* 420 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleNoHandlerFoundException(NoHandlerFoundException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 439 */     response.sendError(404);
/* 440 */     return new ModelAndView();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.support.DefaultHandlerExceptionResolver
 * JD-Core Version:    0.6.2
 */