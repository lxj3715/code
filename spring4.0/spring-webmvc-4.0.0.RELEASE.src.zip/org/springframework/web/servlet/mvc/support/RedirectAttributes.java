package org.springframework.web.servlet.mvc.support;

import java.util.Collection;
import java.util.Map;
import org.springframework.ui.Model;

public abstract interface RedirectAttributes extends Model
{
  public abstract RedirectAttributes addAttribute(String paramString, Object paramObject);

  public abstract RedirectAttributes addAttribute(Object paramObject);

  public abstract RedirectAttributes addAllAttributes(Collection<?> paramCollection);

  public abstract RedirectAttributes mergeAttributes(Map<String, ?> paramMap);

  public abstract RedirectAttributes addFlashAttribute(String paramString, Object paramObject);

  public abstract RedirectAttributes addFlashAttribute(Object paramObject);

  public abstract Map<String, ?> getFlashAttributes();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.support.RedirectAttributes
 * JD-Core Version:    0.6.2
 */