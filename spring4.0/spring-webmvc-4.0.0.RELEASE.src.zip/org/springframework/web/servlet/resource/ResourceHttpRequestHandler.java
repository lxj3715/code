/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.List;
/*     */ import javax.activation.FileTypeMap;
/*     */ import javax.activation.MimetypesFileTypeMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpRequestHandler;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.support.WebContentGenerator;
/*     */ 
/*     */ public class ResourceHttpRequestHandler extends WebContentGenerator
/*     */   implements HttpRequestHandler, InitializingBean
/*     */ {
/*  76 */   private static final Log logger = LogFactory.getLog(ResourceHttpRequestHandler.class);
/*     */ 
/*  79 */   private static final boolean jafPresent = ClassUtils.isPresent("javax.activation.FileTypeMap", ResourceHttpRequestHandler.class
/*  79 */     .getClassLoader());
/*     */   private List<Resource> locations;
/*     */ 
/*     */   public ResourceHttpRequestHandler()
/*     */   {
/*  85 */     super(new String[] { "GET", "HEAD" });
/*     */   }
/*     */ 
/*     */   public void setLocations(List<Resource> locations)
/*     */   {
/*  93 */     Assert.notEmpty(locations, "Locations list must not be empty");
/*  94 */     this.locations = locations;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws Exception
/*     */   {
/*  99 */     if ((logger.isWarnEnabled()) && (CollectionUtils.isEmpty(this.locations)))
/* 100 */       logger.warn("Locations list is empty. No resources will be served");
/*     */   }
/*     */ 
/*     */   public void handleRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 120 */     checkAndPrepare(request, response, true);
/*     */ 
/* 123 */     Resource resource = getResource(request);
/* 124 */     if (resource == null) {
/* 125 */       logger.debug("No matching resource found - returning 404");
/* 126 */       response.sendError(404);
/* 127 */       return;
/*     */     }
/*     */ 
/* 131 */     MediaType mediaType = getMediaType(resource);
/* 132 */     if (mediaType != null) {
/* 133 */       if (logger.isDebugEnabled()) {
/* 134 */         logger.debug("Determined media type '" + mediaType + "' for " + resource);
/*     */       }
/*     */ 
/*     */     }
/* 138 */     else if (logger.isDebugEnabled()) {
/* 139 */       logger.debug("No media type found for " + resource + " - not sending a content-type header");
/*     */     }
/*     */ 
/* 144 */     if (new ServletWebRequest(request, response).checkNotModified(resource.lastModified())) {
/* 145 */       logger.debug("Resource not modified - returning 304");
/* 146 */       return;
/*     */     }
/* 148 */     setHeaders(response, resource, mediaType);
/*     */ 
/* 151 */     if ("HEAD".equals(request.getMethod())) {
/* 152 */       logger.trace("HEAD request - skipping content");
/* 153 */       return;
/*     */     }
/* 155 */     writeContent(response, resource);
/*     */   }
/*     */ 
/*     */   protected Resource getResource(HttpServletRequest request) {
/* 159 */     String path = (String)request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
/* 160 */     if (path == null) {
/* 161 */       throw new IllegalStateException("Required request attribute '" + HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE + "' is not set");
/*     */     }
/*     */ 
/* 165 */     if ((!StringUtils.hasText(path)) || (isInvalidPath(path))) {
/* 166 */       if (logger.isDebugEnabled()) {
/* 167 */         logger.debug("Ignoring invalid resource path [" + path + "]");
/*     */       }
/* 169 */       return null;
/*     */     }
/*     */ 
/* 172 */     for (Resource location : this.locations) {
/*     */       try {
/* 174 */         if (logger.isDebugEnabled()) {
/* 175 */           logger.debug("Trying relative path [" + path + "] against base location: " + location);
/*     */         }
/* 177 */         Resource resource = location.createRelative(path);
/* 178 */         if ((resource.exists()) && (resource.isReadable())) {
/* 179 */           if (logger.isDebugEnabled()) {
/* 180 */             logger.debug("Found matching resource: " + resource);
/*     */           }
/* 182 */           return resource;
/*     */         }
/* 184 */         if (logger.isTraceEnabled())
/* 185 */           logger.trace("Relative resource doesn't exist or isn't readable: " + resource);
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 189 */         logger.debug("Failed to create relative resource - trying next resource location", ex);
/*     */       }
/*     */     }
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean isInvalidPath(String path)
/*     */   {
/* 203 */     return (path.contains("WEB-INF")) || (path.contains("META-INF")) || (StringUtils.cleanPath(path).startsWith(".."));
/*     */   }
/*     */ 
/*     */   protected MediaType getMediaType(Resource resource)
/*     */   {
/* 212 */     MediaType mediaType = null;
/* 213 */     String mimeType = getServletContext().getMimeType(resource.getFilename());
/* 214 */     if (StringUtils.hasText(mimeType)) {
/* 215 */       mediaType = MediaType.parseMediaType(mimeType);
/*     */     }
/* 217 */     if ((jafPresent) && ((mediaType == null) || (MediaType.APPLICATION_OCTET_STREAM.equals(mediaType)))) {
/* 218 */       MediaType jafMediaType = ActivationMediaTypeFactory.getMediaType(resource.getFilename());
/* 219 */       if ((jafMediaType != null) && (!MediaType.APPLICATION_OCTET_STREAM.equals(jafMediaType))) {
/* 220 */         mediaType = jafMediaType;
/*     */       }
/*     */     }
/* 223 */     return mediaType;
/*     */   }
/*     */ 
/*     */   protected void setHeaders(HttpServletResponse response, Resource resource, MediaType mediaType)
/*     */     throws IOException
/*     */   {
/* 235 */     long length = resource.contentLength();
/* 236 */     if (length > 2147483647L) {
/* 237 */       throw new IOException("Resource content too long (beyond Integer.MAX_VALUE): " + resource);
/*     */     }
/* 239 */     response.setContentLength((int)length);
/*     */ 
/* 241 */     if (mediaType != null)
/* 242 */       response.setContentType(mediaType.toString());
/*     */   }
/*     */ 
/*     */   protected void writeContent(HttpServletResponse response, Resource resource)
/*     */     throws IOException
/*     */   {
/* 254 */     FileCopyUtils.copy(resource.getInputStream(), response.getOutputStream());
/*     */   }
/*     */ 
/*     */   private static class ActivationMediaTypeFactory
/*     */   {
/* 266 */     private static final FileTypeMap fileTypeMap = loadFileTypeMapFromContextSupportModule();
/*     */ 
/*     */     private static FileTypeMap loadFileTypeMapFromContextSupportModule()
/*     */     {
/* 271 */       Resource mappingLocation = new ClassPathResource("org/springframework/mail/javamail/mime.types");
/* 272 */       if (mappingLocation.exists()) {
/* 273 */         InputStream inputStream = null;
/*     */         try {
/* 275 */           inputStream = mappingLocation.getInputStream();
/* 276 */           return new MimetypesFileTypeMap(inputStream);
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */         }
/*     */         finally {
/* 282 */           if (inputStream != null) {
/*     */             try {
/* 284 */               inputStream.close();
/*     */             }
/*     */             catch (IOException ex)
/*     */             {
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 292 */       return FileTypeMap.getDefaultFileTypeMap();
/*     */     }
/*     */ 
/*     */     public static MediaType getMediaType(String filename) {
/* 296 */       String mediaType = fileTypeMap.getContentType(filename);
/* 297 */       return StringUtils.hasText(mediaType) ? MediaType.parseMediaType(mediaType) : null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.resource.ResourceHttpRequestHandler
 * JD-Core Version:    0.6.2
 */