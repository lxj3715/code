/*    */ package org.springframework.web.servlet.support;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
/*    */ 
/*    */ public abstract class AbstractAnnotationConfigDispatcherServletInitializer extends AbstractDispatcherServletInitializer
/*    */ {
/*    */   protected WebApplicationContext createRootApplicationContext()
/*    */   {
/* 51 */     Class[] rootConfigClasses = getRootConfigClasses();
/* 52 */     if (!ObjectUtils.isEmpty(rootConfigClasses)) {
/* 53 */       AnnotationConfigWebApplicationContext rootAppContext = new AnnotationConfigWebApplicationContext();
/*    */ 
/* 55 */       rootAppContext.register(rootConfigClasses);
/* 56 */       return rootAppContext;
/*    */     }
/*    */ 
/* 59 */     return null;
/*    */   }
/*    */ 
/*    */   protected WebApplicationContext createServletApplicationContext()
/*    */   {
/* 72 */     AnnotationConfigWebApplicationContext servletAppContext = new AnnotationConfigWebApplicationContext();
/*    */ 
/* 74 */     Class[] servletConfigClasses = getServletConfigClasses();
/* 75 */     Assert.notEmpty(servletConfigClasses, "getServletConfigClasses() did not return any configuration classes");
/*    */ 
/* 78 */     servletAppContext.register(servletConfigClasses);
/* 79 */     return servletAppContext;
/*    */   }
/*    */ 
/*    */   protected abstract Class<?>[] getRootConfigClasses();
/*    */ 
/*    */   protected abstract Class<?>[] getServletConfigClasses();
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer
 * JD-Core Version:    0.6.2
 */