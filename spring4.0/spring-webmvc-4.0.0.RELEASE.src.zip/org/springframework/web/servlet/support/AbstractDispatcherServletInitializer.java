/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterRegistration.Dynamic;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRegistration.Dynamic;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.context.AbstractContextLoaderInitializer;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ 
/*     */ public abstract class AbstractDispatcherServletInitializer extends AbstractContextLoaderInitializer
/*     */ {
/*     */   public static final String DEFAULT_SERVLET_NAME = "dispatcher";
/*     */ 
/*     */   public void onStartup(ServletContext servletContext)
/*     */     throws ServletException
/*     */   {
/*  68 */     super.onStartup(servletContext);
/*     */ 
/*  70 */     registerDispatcherServlet(servletContext);
/*     */   }
/*     */ 
/*     */   protected void registerDispatcherServlet(ServletContext servletContext)
/*     */   {
/*  84 */     String servletName = getServletName();
/*  85 */     Assert.hasLength(servletName, "getServletName() may not return empty or null");
/*     */ 
/*  87 */     WebApplicationContext servletAppContext = createServletApplicationContext();
/*  88 */     Assert.notNull(servletAppContext, "createServletApplicationContext() did not return an application context for servlet [" + servletName + "]");
/*     */ 
/*  92 */     DispatcherServlet dispatcherServlet = new DispatcherServlet(servletAppContext);
/*     */ 
/*  95 */     ServletRegistration.Dynamic registration = servletContext
/*  95 */       .addServlet(servletName, dispatcherServlet);
/*     */ 
/*  97 */     Assert.notNull(registration, "Failed to register servlet with name '" + servletName + "'. " + "Check if there is another servlet registered under the same name.");
/*     */ 
/* 101 */     registration.setLoadOnStartup(1);
/* 102 */     registration.addMapping(getServletMappings());
/* 103 */     registration.setAsyncSupported(isAsyncSupported());
/*     */ 
/* 105 */     Filter[] filters = getServletFilters();
/* 106 */     if (!ObjectUtils.isEmpty(filters)) {
/* 107 */       for (Filter filter : filters) {
/* 108 */         registerServletFilter(servletContext, filter);
/*     */       }
/*     */     }
/*     */ 
/* 112 */     customizeRegistration(registration);
/*     */   }
/*     */ 
/*     */   protected String getServletName()
/*     */   {
/* 121 */     return "dispatcher";
/*     */   }
/*     */ 
/*     */   protected abstract WebApplicationContext createServletApplicationContext();
/*     */ 
/*     */   protected abstract String[] getServletMappings();
/*     */ 
/*     */   protected Filter[] getServletFilters()
/*     */   {
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */   protected FilterRegistration.Dynamic registerServletFilter(ServletContext servletContext, Filter filter)
/*     */   {
/* 170 */     String filterName = Conventions.getVariableName(filter);
/* 171 */     FilterRegistration.Dynamic registration = servletContext.addFilter(filterName, filter);
/* 172 */     registration.setAsyncSupported(isAsyncSupported());
/* 173 */     registration.addMappingForServletNames(getDispatcherTypes(), false, new String[] { getServletName() });
/* 174 */     return registration;
/*     */   }
/*     */ 
/*     */   private EnumSet<DispatcherType> getDispatcherTypes()
/*     */   {
/* 180 */     return isAsyncSupported() ? 
/* 179 */       EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD, DispatcherType.INCLUDE, DispatcherType.ASYNC) : 
/* 180 */       EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD, DispatcherType.INCLUDE);
/*     */   }
/*     */ 
/*     */   protected boolean isAsyncSupported()
/*     */   {
/* 189 */     return true;
/*     */   }
/*     */ 
/*     */   protected void customizeRegistration(ServletRegistration.Dynamic registration)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.support.AbstractDispatcherServletInitializer
 * JD-Core Version:    0.6.2
 */