/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.FlashMap;
/*     */ import org.springframework.web.servlet.FlashMapManager;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ public abstract class AbstractFlashMapManager
/*     */   implements FlashMapManager
/*     */ {
/*  46 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  48 */   private int flashMapTimeout = 180;
/*     */ 
/*  50 */   private UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */ 
/*  52 */   private static final Object writeLock = new Object();
/*     */ 
/*     */   public void setFlashMapTimeout(int flashMapTimeout)
/*     */   {
/*  60 */     this.flashMapTimeout = flashMapTimeout;
/*     */   }
/*     */ 
/*     */   public int getFlashMapTimeout()
/*     */   {
/*  67 */     return this.flashMapTimeout;
/*     */   }
/*     */ 
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/*  74 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/*  75 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */ 
/*     */   public UrlPathHelper getUrlPathHelper()
/*     */   {
/*  82 */     return this.urlPathHelper;
/*     */   }
/*     */ 
/*     */   public final FlashMap retrieveAndUpdate(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  88 */     List maps = retrieveFlashMaps(request);
/*  89 */     if (CollectionUtils.isEmpty(maps)) {
/*  90 */       return null;
/*     */     }
/*  92 */     if (this.logger.isDebugEnabled()) {
/*  93 */       this.logger.debug("Retrieved FlashMap(s): " + maps);
/*     */     }
/*     */ 
/*  96 */     List mapsToRemove = getExpiredFlashMaps(maps);
/*     */ 
/*  98 */     FlashMap match = getMatchingFlashMap(maps, request);
/*  99 */     if (match != null) {
/* 100 */       mapsToRemove.add(match);
/*     */     }
/*     */ 
/* 103 */     if (!mapsToRemove.isEmpty()) {
/* 104 */       if (this.logger.isDebugEnabled()) {
/* 105 */         this.logger.debug("Removing FlashMap(s): " + mapsToRemove);
/*     */       }
/* 107 */       synchronized (writeLock) {
/* 108 */         maps = retrieveFlashMaps(request);
/* 109 */         maps.removeAll(mapsToRemove);
/* 110 */         updateFlashMaps(maps, request, response);
/*     */       }
/*     */     }
/*     */ 
/* 114 */     return match;
/*     */   }
/*     */ 
/*     */   protected abstract List<FlashMap> retrieveFlashMaps(HttpServletRequest paramHttpServletRequest);
/*     */ 
/*     */   private List<FlashMap> getExpiredFlashMaps(List<FlashMap> allMaps)
/*     */   {
/* 128 */     List result = new ArrayList();
/* 129 */     for (FlashMap map : allMaps) {
/* 130 */       if (map.isExpired()) {
/* 131 */         result.add(map);
/*     */       }
/*     */     }
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */   private FlashMap getMatchingFlashMap(List<FlashMap> allMaps, HttpServletRequest request)
/*     */   {
/* 142 */     List result = new ArrayList();
/* 143 */     for (FlashMap flashMap : allMaps) {
/* 144 */       if (isFlashMapForRequest(flashMap, request)) {
/* 145 */         result.add(flashMap);
/*     */       }
/*     */     }
/* 148 */     if (!result.isEmpty()) {
/* 149 */       Collections.sort(result);
/* 150 */       if (this.logger.isDebugEnabled()) {
/* 151 */         this.logger.debug("Found matching FlashMap(s): " + result);
/*     */       }
/* 153 */       return (FlashMap)result.get(0);
/*     */     }
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean isFlashMapForRequest(FlashMap flashMap, HttpServletRequest request)
/*     */   {
/* 164 */     if (flashMap.getTargetRequestPath() != null) {
/* 165 */       String requestUri = this.urlPathHelper.getOriginatingRequestUri(request);
/* 166 */       if ((!requestUri.equals(flashMap.getTargetRequestPath())) && 
/* 167 */         (!requestUri
/* 167 */         .equals(flashMap
/* 167 */         .getTargetRequestPath() + "/"))) {
/* 168 */         return false;
/*     */       }
/*     */     }
/* 171 */     MultiValueMap targetParams = flashMap.getTargetRequestParams();
/* 172 */     for (Iterator localIterator1 = targetParams.keySet().iterator(); localIterator1.hasNext(); ) { paramName = (String)localIterator1.next();
/* 173 */       for (String targetValue : (List)targetParams.get(paramName))
/* 174 */         if (!ObjectUtils.containsElement(request.getParameterValues(paramName), targetValue))
/* 175 */           return false;
/*     */     }
/*     */     String paramName;
/* 179 */     return true;
/*     */   }
/*     */ 
/*     */   public final void saveOutputFlashMap(FlashMap flashMap, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 184 */     if (CollectionUtils.isEmpty(flashMap)) {
/* 185 */       return;
/*     */     }
/*     */ 
/* 188 */     String path = decodeAndNormalizePath(flashMap.getTargetRequestPath(), request);
/* 189 */     flashMap.setTargetRequestPath(path);
/*     */ 
/* 191 */     decodeParameters(flashMap.getTargetRequestParams(), request);
/*     */ 
/* 193 */     if (this.logger.isDebugEnabled()) {
/* 194 */       this.logger.debug("Saving FlashMap=" + flashMap);
/*     */     }
/*     */ 
/* 197 */     flashMap.startExpirationPeriod(this.flashMapTimeout);
/*     */ 
/* 199 */     synchronized (writeLock) {
/* 200 */       List allMaps = retrieveFlashMaps(request);
/* 201 */       allMaps = allMaps == null ? new CopyOnWriteArrayList() : allMaps;
/* 202 */       allMaps.add(flashMap);
/* 203 */       updateFlashMaps(allMaps, request, response);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String decodeAndNormalizePath(String path, HttpServletRequest request) {
/* 208 */     if (path != null) {
/* 209 */       path = this.urlPathHelper.decodeRequestString(request, path);
/* 210 */       if (path.charAt(0) != '/') {
/* 211 */         String requestUri = this.urlPathHelper.getRequestUri(request);
/* 212 */         path = requestUri.substring(0, requestUri.lastIndexOf(47) + 1) + path;
/* 213 */         path = StringUtils.cleanPath(path);
/*     */       }
/*     */     }
/* 216 */     return path;
/*     */   }
/*     */ 
/*     */   private void decodeParameters(MultiValueMap<String, String> params, HttpServletRequest request) {
/* 220 */     for (Iterator localIterator1 = new ArrayList(params.keySet()).iterator(); localIterator1.hasNext(); ) { name = (String)localIterator1.next();
/* 221 */       for (String value : new ArrayList((Collection)params.remove(name)))
/* 222 */         params.add(name, this.urlPathHelper.decodeRequestString(request, value));
/*     */     }
/*     */     String name;
/*     */   }
/*     */ 
/*     */   protected abstract void updateFlashMaps(List<FlashMap> paramList, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.support.AbstractFlashMapManager
 * JD-Core Version:    0.6.2
 */