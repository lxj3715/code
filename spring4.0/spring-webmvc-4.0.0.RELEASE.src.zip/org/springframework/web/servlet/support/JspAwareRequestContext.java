/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ 
/*     */ public class JspAwareRequestContext extends RequestContext
/*     */ {
/*     */   private PageContext pageContext;
/*     */ 
/*     */   public JspAwareRequestContext(PageContext pageContext)
/*     */   {
/*  48 */     initContext(pageContext, null);
/*     */   }
/*     */ 
/*     */   public JspAwareRequestContext(PageContext pageContext, Map<String, Object> model)
/*     */   {
/*  59 */     initContext(pageContext, model);
/*     */   }
/*     */ 
/*     */   protected void initContext(PageContext pageContext, Map<String, Object> model)
/*     */   {
/*  70 */     if (!(pageContext.getRequest() instanceof HttpServletRequest)) {
/*  71 */       throw new IllegalArgumentException("RequestContext only supports HTTP requests");
/*     */     }
/*  73 */     this.pageContext = pageContext;
/*  74 */     initContext((HttpServletRequest)pageContext.getRequest(), (HttpServletResponse)pageContext.getResponse(), pageContext
/*  75 */       .getServletContext(), model);
/*     */   }
/*     */ 
/*     */   protected final PageContext getPageContext()
/*     */   {
/*  84 */     return this.pageContext;
/*     */   }
/*     */ 
/*     */   protected Locale getFallbackLocale()
/*     */   {
/*  94 */     if (jstlPresent) {
/*  95 */       Locale locale = JstlPageLocaleResolver.getJstlLocale(getPageContext());
/*  96 */       if (locale != null) {
/*  97 */         return locale;
/*     */       }
/*     */     }
/* 100 */     return getRequest().getLocale();
/*     */   }
/*     */ 
/*     */   private static class JstlPageLocaleResolver
/*     */   {
/*     */     public static Locale getJstlLocale(PageContext pageContext)
/*     */     {
/* 111 */       Object localeObject = Config.find(pageContext, "javax.servlet.jsp.jstl.fmt.locale");
/* 112 */       return (localeObject instanceof Locale) ? (Locale)localeObject : null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.support.JspAwareRequestContext
 * JD-Core Version:    0.6.2
 */