/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceResolvable;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.SimpleTimeZoneAwareLocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.ui.context.Theme;
/*     */ import org.springframework.ui.context.ThemeSource;
/*     */ import org.springframework.ui.context.support.ResourceBundleThemeSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.web.bind.EscapedErrors;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.servlet.LocaleContextResolver;
/*     */ import org.springframework.web.servlet.LocaleResolver;
/*     */ import org.springframework.web.servlet.ThemeResolver;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ import org.springframework.web.util.UriTemplate;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class RequestContext
/*     */ {
/*     */   public static final String DEFAULT_THEME_NAME = "theme";
/*  90 */   public static final String WEB_APPLICATION_CONTEXT_ATTRIBUTE = RequestContext.class.getName() + ".CONTEXT";
/*     */   private static final String REQUEST_DATA_VALUE_PROCESSOR_BEAN_NAME = "requestDataValueProcessor";
/*  99 */   protected static final boolean jstlPresent = ClassUtils.isPresent("javax.servlet.jsp.jstl.core.Config", RequestContext.class
/* 100 */     .getClassLoader());
/*     */   private HttpServletRequest request;
/*     */   private HttpServletResponse response;
/*     */   private Map<String, Object> model;
/*     */   private WebApplicationContext webApplicationContext;
/*     */   private Locale locale;
/*     */   private TimeZone timeZone;
/*     */   private Theme theme;
/*     */   private Boolean defaultHtmlEscape;
/*     */   private UrlPathHelper urlPathHelper;
/*     */   private RequestDataValueProcessor requestDataValueProcessor;
/*     */   private Map<String, Errors> errorsMap;
/*     */ 
/*     */   public RequestContext(HttpServletRequest request)
/*     */   {
/* 136 */     initContext(request, null, null, null);
/*     */   }
/*     */ 
/*     */   public RequestContext(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 151 */     initContext(request, response, null, null);
/*     */   }
/*     */ 
/*     */   public RequestContext(HttpServletRequest request, ServletContext servletContext)
/*     */   {
/* 167 */     initContext(request, null, servletContext, null);
/*     */   }
/*     */ 
/*     */   public RequestContext(HttpServletRequest request, Map<String, Object> model)
/*     */   {
/* 182 */     initContext(request, null, null, model);
/*     */   }
/*     */ 
/*     */   public RequestContext(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext, Map<String, Object> model)
/*     */   {
/* 202 */     initContext(request, response, servletContext, model);
/*     */   }
/*     */ 
/*     */   protected RequestContext()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void initContext(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext, Map<String, Object> model)
/*     */   {
/* 229 */     this.request = request;
/* 230 */     this.response = response;
/* 231 */     this.model = model;
/*     */ 
/* 235 */     this.webApplicationContext = ((WebApplicationContext)request.getAttribute(WEB_APPLICATION_CONTEXT_ATTRIBUTE));
/* 236 */     if (this.webApplicationContext == null) {
/* 237 */       this.webApplicationContext = RequestContextUtils.getWebApplicationContext(request, servletContext);
/*     */     }
/*     */ 
/* 241 */     LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
/* 242 */     if ((localeResolver instanceof LocaleContextResolver)) {
/* 243 */       LocaleContext localeContext = ((LocaleContextResolver)localeResolver).resolveLocaleContext(request);
/* 244 */       this.locale = localeContext.getLocale();
/* 245 */       if ((localeContext instanceof TimeZoneAwareLocaleContext)) {
/* 246 */         this.timeZone = ((TimeZoneAwareLocaleContext)localeContext).getTimeZone();
/*     */       }
/*     */     }
/* 249 */     else if (localeResolver != null)
/*     */     {
/* 251 */       this.locale = localeResolver.resolveLocale(request);
/*     */     }
/*     */ 
/* 255 */     if (this.locale == null) {
/* 256 */       this.locale = getFallbackLocale();
/*     */     }
/* 258 */     if (this.timeZone == null) {
/* 259 */       this.timeZone = getFallbackTimeZone();
/*     */     }
/*     */ 
/* 264 */     this.defaultHtmlEscape = WebUtils.getDefaultHtmlEscape(this.webApplicationContext.getServletContext());
/*     */ 
/* 266 */     this.urlPathHelper = new UrlPathHelper();
/*     */ 
/* 268 */     if (this.webApplicationContext.containsBean("requestDataValueProcessor"))
/* 269 */       this.requestDataValueProcessor = ((RequestDataValueProcessor)this.webApplicationContext.getBean("requestDataValueProcessor", RequestDataValueProcessor.class));
/*     */   }
/*     */ 
/*     */   protected Locale getFallbackLocale()
/*     */   {
/* 282 */     if (jstlPresent) {
/* 283 */       Locale locale = JstlLocaleResolver.getJstlLocale(getRequest(), getServletContext());
/* 284 */       if (locale != null) {
/* 285 */         return locale;
/*     */       }
/*     */     }
/* 288 */     return getRequest().getLocale();
/*     */   }
/*     */ 
/*     */   protected TimeZone getFallbackTimeZone()
/*     */   {
/* 298 */     if (jstlPresent) {
/* 299 */       TimeZone timeZone = JstlLocaleResolver.getJstlTimeZone(getRequest(), getServletContext());
/* 300 */       if (timeZone != null) {
/* 301 */         return timeZone;
/*     */       }
/*     */     }
/* 304 */     return null;
/*     */   }
/*     */ 
/*     */   protected Theme getFallbackTheme()
/*     */   {
/* 313 */     ThemeSource themeSource = RequestContextUtils.getThemeSource(getRequest());
/* 314 */     if (themeSource == null) {
/* 315 */       themeSource = new ResourceBundleThemeSource();
/*     */     }
/* 317 */     Theme theme = themeSource.getTheme("theme");
/* 318 */     if (theme == null) {
/* 319 */       throw new IllegalStateException("No theme defined and no fallback theme found");
/*     */     }
/* 321 */     return theme;
/*     */   }
/*     */ 
/*     */   protected final HttpServletRequest getRequest()
/*     */   {
/* 329 */     return this.request;
/*     */   }
/*     */ 
/*     */   protected final ServletContext getServletContext()
/*     */   {
/* 336 */     return this.webApplicationContext.getServletContext();
/*     */   }
/*     */ 
/*     */   public final WebApplicationContext getWebApplicationContext()
/*     */   {
/* 343 */     return this.webApplicationContext;
/*     */   }
/*     */ 
/*     */   public final MessageSource getMessageSource()
/*     */   {
/* 350 */     return this.webApplicationContext;
/*     */   }
/*     */ 
/*     */   public final Map<String, Object> getModel()
/*     */   {
/* 358 */     return this.model;
/*     */   }
/*     */ 
/*     */   public final Locale getLocale()
/*     */   {
/* 368 */     return this.locale;
/*     */   }
/*     */ 
/*     */   public TimeZone getTimeZone()
/*     */   {
/* 378 */     return this.timeZone;
/*     */   }
/*     */ 
/*     */   public void changeLocale(Locale locale)
/*     */   {
/* 389 */     LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(this.request);
/* 390 */     if (localeResolver == null) {
/* 391 */       throw new IllegalStateException("Cannot change locale if no LocaleResolver configured");
/*     */     }
/* 393 */     localeResolver.setLocale(this.request, this.response, locale);
/* 394 */     this.locale = locale;
/*     */   }
/*     */ 
/*     */   public void changeLocale(Locale locale, TimeZone timeZone)
/*     */   {
/* 406 */     LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(this.request);
/* 407 */     if (!(localeResolver instanceof LocaleContextResolver)) {
/* 408 */       throw new IllegalStateException("Cannot change locale context if no LocaleContextResolver configured");
/*     */     }
/* 410 */     ((LocaleContextResolver)localeResolver).setLocaleContext(this.request, this.response, new SimpleTimeZoneAwareLocaleContext(locale, timeZone));
/*     */ 
/* 412 */     this.locale = locale;
/* 413 */     this.timeZone = timeZone;
/*     */   }
/*     */ 
/*     */   public Theme getTheme()
/*     */   {
/* 421 */     if (this.theme == null)
/*     */     {
/* 423 */       this.theme = RequestContextUtils.getTheme(this.request);
/* 424 */       if (this.theme == null)
/*     */       {
/* 426 */         this.theme = getFallbackTheme();
/*     */       }
/*     */     }
/* 429 */     return this.theme;
/*     */   }
/*     */ 
/*     */   public void changeTheme(Theme theme)
/*     */   {
/* 439 */     ThemeResolver themeResolver = RequestContextUtils.getThemeResolver(this.request);
/* 440 */     if (themeResolver == null) {
/* 441 */       throw new IllegalStateException("Cannot change theme if no ThemeResolver configured");
/*     */     }
/* 443 */     themeResolver.setThemeName(this.request, this.response, theme != null ? theme.getName() : null);
/* 444 */     this.theme = theme;
/*     */   }
/*     */ 
/*     */   public void changeTheme(String themeName)
/*     */   {
/* 454 */     ThemeResolver themeResolver = RequestContextUtils.getThemeResolver(this.request);
/* 455 */     if (themeResolver == null) {
/* 456 */       throw new IllegalStateException("Cannot change theme if no ThemeResolver configured");
/*     */     }
/* 458 */     themeResolver.setThemeName(this.request, this.response, themeName);
/*     */ 
/* 460 */     this.theme = null;
/*     */   }
/*     */ 
/*     */   public void setDefaultHtmlEscape(boolean defaultHtmlEscape)
/*     */   {
/* 469 */     this.defaultHtmlEscape = Boolean.valueOf(defaultHtmlEscape);
/*     */   }
/*     */ 
/*     */   public boolean isDefaultHtmlEscape()
/*     */   {
/* 476 */     return (this.defaultHtmlEscape != null) && (this.defaultHtmlEscape.booleanValue());
/*     */   }
/*     */ 
/*     */   public Boolean getDefaultHtmlEscape()
/*     */   {
/* 484 */     return this.defaultHtmlEscape;
/*     */   }
/*     */ 
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/* 493 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/* 494 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */ 
/*     */   public UrlPathHelper getUrlPathHelper()
/*     */   {
/* 503 */     return this.urlPathHelper;
/*     */   }
/*     */ 
/*     */   public RequestDataValueProcessor getRequestDataValueProcessor()
/*     */   {
/* 512 */     return this.requestDataValueProcessor;
/*     */   }
/*     */ 
/*     */   public String getContextPath()
/*     */   {
/* 524 */     return this.urlPathHelper.getOriginatingContextPath(this.request);
/*     */   }
/*     */ 
/*     */   public String getContextUrl(String relativeUrl)
/*     */   {
/* 533 */     String url = getContextPath() + relativeUrl;
/* 534 */     if (this.response != null) {
/* 535 */       url = this.response.encodeURL(url);
/*     */     }
/* 537 */     return url;
/*     */   }
/*     */ 
/*     */   public String getContextUrl(String relativeUrl, Map<String, ?> params)
/*     */   {
/* 549 */     String url = getContextPath() + relativeUrl;
/* 550 */     UriTemplate template = new UriTemplate(url);
/* 551 */     url = template.expand(params).toASCIIString();
/* 552 */     if (this.response != null) {
/* 553 */       url = this.response.encodeURL(url);
/*     */     }
/* 555 */     return url;
/*     */   }
/*     */ 
/*     */   public String getPathToServlet()
/*     */   {
/* 566 */     String path = this.urlPathHelper.getOriginatingContextPath(this.request);
/* 567 */     if (StringUtils.hasText(this.urlPathHelper.getPathWithinServletMapping(this.request))) {
/* 568 */       path = path + this.urlPathHelper.getOriginatingServletPath(this.request);
/*     */     }
/* 570 */     return path;
/*     */   }
/*     */ 
/*     */   public String getRequestUri()
/*     */   {
/* 583 */     return this.urlPathHelper.getOriginatingRequestUri(this.request);
/*     */   }
/*     */ 
/*     */   public String getQueryString()
/*     */   {
/* 596 */     return this.urlPathHelper.getOriginatingQueryString(this.request);
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, String defaultMessage)
/*     */   {
/* 606 */     return getMessage(code, null, defaultMessage, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, Object[] args, String defaultMessage)
/*     */   {
/* 617 */     return getMessage(code, args, defaultMessage, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, List<?> args, String defaultMessage)
/*     */   {
/* 628 */     return getMessage(code, args != null ? args.toArray() : null, defaultMessage, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, Object[] args, String defaultMessage, boolean htmlEscape)
/*     */   {
/* 640 */     String msg = this.webApplicationContext.getMessage(code, args, defaultMessage, this.locale);
/* 641 */     return htmlEscape ? HtmlUtils.htmlEscape(msg) : msg;
/*     */   }
/*     */ 
/*     */   public String getMessage(String code)
/*     */     throws NoSuchMessageException
/*     */   {
/* 651 */     return getMessage(code, null, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, Object[] args)
/*     */     throws NoSuchMessageException
/*     */   {
/* 662 */     return getMessage(code, args, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, List<?> args)
/*     */     throws NoSuchMessageException
/*     */   {
/* 673 */     return getMessage(code, args != null ? args.toArray() : null, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, Object[] args, boolean htmlEscape)
/*     */     throws NoSuchMessageException
/*     */   {
/* 685 */     String msg = this.webApplicationContext.getMessage(code, args, this.locale);
/* 686 */     return htmlEscape ? HtmlUtils.htmlEscape(msg) : msg;
/*     */   }
/*     */ 
/*     */   public String getMessage(MessageSourceResolvable resolvable)
/*     */     throws NoSuchMessageException
/*     */   {
/* 696 */     return getMessage(resolvable, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */   public String getMessage(MessageSourceResolvable resolvable, boolean htmlEscape)
/*     */     throws NoSuchMessageException
/*     */   {
/* 707 */     String msg = this.webApplicationContext.getMessage(resolvable, this.locale);
/* 708 */     return htmlEscape ? HtmlUtils.htmlEscape(msg) : msg;
/*     */   }
/*     */ 
/*     */   public String getThemeMessage(String code, String defaultMessage)
/*     */   {
/* 720 */     return getTheme().getMessageSource().getMessage(code, null, defaultMessage, this.locale);
/*     */   }
/*     */ 
/*     */   public String getThemeMessage(String code, Object[] args, String defaultMessage)
/*     */   {
/* 733 */     return getTheme().getMessageSource().getMessage(code, args, defaultMessage, this.locale);
/*     */   }
/*     */ 
/*     */   public String getThemeMessage(String code, List<?> args, String defaultMessage)
/*     */   {
/* 746 */     return getTheme().getMessageSource().getMessage(code, args != null ? args.toArray() : null, defaultMessage, this.locale);
/*     */   }
/*     */ 
/*     */   public String getThemeMessage(String code)
/*     */     throws NoSuchMessageException
/*     */   {
/* 759 */     return getTheme().getMessageSource().getMessage(code, null, this.locale);
/*     */   }
/*     */ 
/*     */   public String getThemeMessage(String code, Object[] args)
/*     */     throws NoSuchMessageException
/*     */   {
/* 772 */     return getTheme().getMessageSource().getMessage(code, args, this.locale);
/*     */   }
/*     */ 
/*     */   public String getThemeMessage(String code, List<?> args)
/*     */     throws NoSuchMessageException
/*     */   {
/* 785 */     return getTheme().getMessageSource().getMessage(code, args != null ? args.toArray() : null, this.locale);
/*     */   }
/*     */ 
/*     */   public String getThemeMessage(MessageSourceResolvable resolvable)
/*     */     throws NoSuchMessageException
/*     */   {
/* 797 */     return getTheme().getMessageSource().getMessage(resolvable, this.locale);
/*     */   }
/*     */ 
/*     */   public Errors getErrors(String name)
/*     */   {
/* 806 */     return getErrors(name, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */   public Errors getErrors(String name, boolean htmlEscape)
/*     */   {
/* 816 */     if (this.errorsMap == null) {
/* 817 */       this.errorsMap = new HashMap();
/*     */     }
/* 819 */     Errors errors = (Errors)this.errorsMap.get(name);
/* 820 */     boolean put = false;
/* 821 */     if (errors == null) {
/* 822 */       errors = (Errors)getModelObject(BindingResult.MODEL_KEY_PREFIX + name);
/*     */ 
/* 824 */       if ((errors instanceof BindException)) {
/* 825 */         errors = ((BindException)errors).getBindingResult();
/*     */       }
/* 827 */       if (errors == null) {
/* 828 */         return null;
/*     */       }
/* 830 */       put = true;
/*     */     }
/* 832 */     if ((htmlEscape) && (!(errors instanceof EscapedErrors))) {
/* 833 */       errors = new EscapedErrors(errors);
/* 834 */       put = true;
/*     */     }
/* 836 */     else if ((!htmlEscape) && ((errors instanceof EscapedErrors))) {
/* 837 */       errors = ((EscapedErrors)errors).getSource();
/* 838 */       put = true;
/*     */     }
/* 840 */     if (put) {
/* 841 */       this.errorsMap.put(name, errors);
/*     */     }
/* 843 */     return errors;
/*     */   }
/*     */ 
/*     */   protected Object getModelObject(String modelName)
/*     */   {
/* 852 */     if (this.model != null) {
/* 853 */       return this.model.get(modelName);
/*     */     }
/*     */ 
/* 856 */     return this.request.getAttribute(modelName);
/*     */   }
/*     */ 
/*     */   public BindStatus getBindStatus(String path)
/*     */     throws IllegalStateException
/*     */   {
/* 867 */     return new BindStatus(this, path, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */   public BindStatus getBindStatus(String path, boolean htmlEscape)
/*     */     throws IllegalStateException
/*     */   {
/* 878 */     return new BindStatus(this, path, htmlEscape);
/*     */   }
/*     */ 
/*     */   private static class JstlLocaleResolver
/*     */   {
/*     */     public static Locale getJstlLocale(HttpServletRequest request, ServletContext servletContext)
/*     */     {
/* 889 */       Object localeObject = Config.get(request, "javax.servlet.jsp.jstl.fmt.locale");
/* 890 */       if (localeObject == null) {
/* 891 */         HttpSession session = request.getSession(false);
/* 892 */         if (session != null) {
/* 893 */           localeObject = Config.get(session, "javax.servlet.jsp.jstl.fmt.locale");
/*     */         }
/* 895 */         if ((localeObject == null) && (servletContext != null)) {
/* 896 */           localeObject = Config.get(servletContext, "javax.servlet.jsp.jstl.fmt.locale");
/*     */         }
/*     */       }
/* 899 */       return (localeObject instanceof Locale) ? (Locale)localeObject : null;
/*     */     }
/*     */ 
/*     */     public static TimeZone getJstlTimeZone(HttpServletRequest request, ServletContext servletContext) {
/* 903 */       Object timeZoneObject = Config.get(request, "javax.servlet.jsp.jstl.fmt.timeZone");
/* 904 */       if (timeZoneObject == null) {
/* 905 */         HttpSession session = request.getSession(false);
/* 906 */         if (session != null) {
/* 907 */           timeZoneObject = Config.get(session, "javax.servlet.jsp.jstl.fmt.timeZone");
/*     */         }
/* 909 */         if ((timeZoneObject == null) && (servletContext != null)) {
/* 910 */           timeZoneObject = Config.get(servletContext, "javax.servlet.jsp.jstl.fmt.timeZone");
/*     */         }
/*     */       }
/* 913 */       return (timeZoneObject instanceof TimeZone) ? (TimeZone)timeZoneObject : null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.support.RequestContext
 * JD-Core Version:    0.6.2
 */