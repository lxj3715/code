/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.ui.context.Theme;
/*     */ import org.springframework.ui.context.ThemeSource;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.FlashMap;
/*     */ import org.springframework.web.servlet.FlashMapManager;
/*     */ import org.springframework.web.servlet.LocaleContextResolver;
/*     */ import org.springframework.web.servlet.LocaleResolver;
/*     */ import org.springframework.web.servlet.ThemeResolver;
/*     */ 
/*     */ public abstract class RequestContextUtils
/*     */ {
/*     */   public static WebApplicationContext getWebApplicationContext(ServletRequest request)
/*     */     throws IllegalStateException
/*     */   {
/*  64 */     return getWebApplicationContext(request, null);
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getWebApplicationContext(ServletRequest request, ServletContext servletContext)
/*     */     throws IllegalStateException
/*     */   {
/*  83 */     WebApplicationContext webApplicationContext = (WebApplicationContext)request.getAttribute(DispatcherServlet.WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*     */ 
/*  85 */     if (webApplicationContext == null) {
/*  86 */       if (servletContext == null) {
/*  87 */         throw new IllegalStateException("No WebApplicationContext found: not in a DispatcherServlet request?");
/*     */       }
/*  89 */       webApplicationContext = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
/*     */     }
/*  91 */     return webApplicationContext;
/*     */   }
/*     */ 
/*     */   public static LocaleResolver getLocaleResolver(HttpServletRequest request)
/*     */   {
/* 101 */     return (LocaleResolver)request.getAttribute(DispatcherServlet.LOCALE_RESOLVER_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */   public static Locale getLocale(HttpServletRequest request)
/*     */   {
/* 120 */     LocaleResolver localeResolver = getLocaleResolver(request);
/* 121 */     return localeResolver != null ? localeResolver.resolveLocale(request) : request.getLocale();
/*     */   }
/*     */ 
/*     */   public static TimeZone getTimeZone(HttpServletRequest request)
/*     */   {
/* 142 */     LocaleResolver localeResolver = getLocaleResolver(request);
/* 143 */     if ((localeResolver instanceof LocaleContextResolver)) {
/* 144 */       LocaleContext localeContext = ((LocaleContextResolver)localeResolver).resolveLocaleContext(request);
/* 145 */       if ((localeContext instanceof TimeZoneAwareLocaleContext)) {
/* 146 */         return ((TimeZoneAwareLocaleContext)localeContext).getTimeZone();
/*     */       }
/*     */     }
/* 149 */     return null;
/*     */   }
/*     */ 
/*     */   public static ThemeResolver getThemeResolver(HttpServletRequest request)
/*     */   {
/* 159 */     return (ThemeResolver)request.getAttribute(DispatcherServlet.THEME_RESOLVER_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */   public static ThemeSource getThemeSource(HttpServletRequest request)
/*     */   {
/* 169 */     return (ThemeSource)request.getAttribute(DispatcherServlet.THEME_SOURCE_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */   public static Theme getTheme(HttpServletRequest request)
/*     */   {
/* 180 */     ThemeResolver themeResolver = getThemeResolver(request);
/* 181 */     ThemeSource themeSource = getThemeSource(request);
/* 182 */     if ((themeResolver != null) && (themeSource != null)) {
/* 183 */       String themeName = themeResolver.resolveThemeName(request);
/* 184 */       return themeSource.getTheme(themeName);
/*     */     }
/*     */ 
/* 187 */     return null;
/*     */   }
/*     */ 
/*     */   public static Map<String, ?> getInputFlashMap(HttpServletRequest request)
/*     */   {
/* 200 */     return (Map)request.getAttribute(DispatcherServlet.INPUT_FLASH_MAP_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */   public static FlashMap getOutputFlashMap(HttpServletRequest request)
/*     */   {
/* 210 */     return (FlashMap)request.getAttribute(DispatcherServlet.OUTPUT_FLASH_MAP_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */   public static FlashMapManager getFlashMapManager(HttpServletRequest request)
/*     */   {
/* 220 */     return (FlashMapManager)request.getAttribute(DispatcherServlet.FLASH_MAP_MANAGER_ATTRIBUTE);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.support.RequestContextUtils
 * JD-Core Version:    0.6.2
 */