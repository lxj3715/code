package org.springframework.web.servlet.support;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public abstract interface RequestDataValueProcessor
{
  public abstract String processAction(HttpServletRequest paramHttpServletRequest, String paramString1, String paramString2);

  public abstract String processFormFieldValue(HttpServletRequest paramHttpServletRequest, String paramString1, String paramString2, String paramString3);

  public abstract Map<String, String> getExtraHiddenFields(HttpServletRequest paramHttpServletRequest);

  public abstract String processUrl(HttpServletRequest paramHttpServletRequest, String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.support.RequestDataValueProcessor
 * JD-Core Version:    0.6.2
 */