/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ServletUriComponentsBuilder extends UriComponentsBuilder
/*     */ {
/*     */   private String servletRequestURI;
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromContextPath(HttpServletRequest request)
/*     */   {
/*  59 */     ServletUriComponentsBuilder builder = fromRequest(request);
/*  60 */     builder.replacePath(request.getContextPath());
/*  61 */     builder.replaceQuery(null);
/*  62 */     return builder;
/*     */   }
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromServletMapping(HttpServletRequest request)
/*     */   {
/*  76 */     ServletUriComponentsBuilder builder = fromContextPath(request);
/*  77 */     if (StringUtils.hasText(new UrlPathHelper().getPathWithinServletMapping(request))) {
/*  78 */       builder.path(request.getServletPath());
/*     */     }
/*  80 */     return builder;
/*     */   }
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromRequestUri(HttpServletRequest request)
/*     */   {
/*  88 */     ServletUriComponentsBuilder builder = fromRequest(request);
/*  89 */     builder.pathFromRequest(request);
/*  90 */     builder.replaceQuery(null);
/*  91 */     return builder;
/*     */   }
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromRequest(HttpServletRequest request)
/*     */   {
/*  99 */     String scheme = request.getScheme();
/* 100 */     int port = request.getServerPort();
/* 101 */     String host = request.getServerName();
/*     */ 
/* 103 */     String header = request.getHeader("X-Forwarded-Host");
/*     */ 
/* 105 */     if (StringUtils.hasText(header)) {
/* 106 */       String[] hosts = StringUtils.commaDelimitedListToStringArray(header);
/* 107 */       String hostToUse = hosts[0];
/* 108 */       if (hostToUse.contains(":")) {
/* 109 */         String[] hostAndPort = StringUtils.split(hostToUse, ":");
/* 110 */         host = hostAndPort[0];
/* 111 */         port = Integer.parseInt(hostAndPort[1]);
/*     */       }
/*     */       else {
/* 114 */         host = hostToUse;
/*     */       }
/*     */     }
/*     */ 
/* 118 */     ServletUriComponentsBuilder builder = new ServletUriComponentsBuilder();
/* 119 */     builder.scheme(scheme);
/* 120 */     builder.host(host);
/* 121 */     if (((scheme.equals("http")) && (port != 80)) || ((scheme.equals("https")) && (port != 443))) {
/* 122 */       builder.port(port);
/*     */     }
/* 124 */     builder.pathFromRequest(request);
/* 125 */     builder.query(request.getQueryString());
/* 126 */     return builder;
/*     */   }
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromCurrentContextPath()
/*     */   {
/* 134 */     return fromContextPath(getCurrentRequest());
/*     */   }
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromCurrentServletMapping()
/*     */   {
/* 142 */     return fromServletMapping(getCurrentRequest());
/*     */   }
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromCurrentRequestUri()
/*     */   {
/* 150 */     return fromRequestUri(getCurrentRequest());
/*     */   }
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromCurrentRequest()
/*     */   {
/* 158 */     return fromRequest(getCurrentRequest());
/*     */   }
/*     */ 
/*     */   protected static HttpServletRequest getCurrentRequest()
/*     */   {
/* 165 */     RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/* 166 */     Assert.state(requestAttributes != null, "Could not find current request via RequestContextHolder");
/* 167 */     Assert.isInstanceOf(ServletRequestAttributes.class, requestAttributes);
/* 168 */     HttpServletRequest servletRequest = ((ServletRequestAttributes)requestAttributes).getRequest();
/* 169 */     Assert.state(servletRequest != null, "Could not find current HttpServletRequest");
/* 170 */     return servletRequest;
/*     */   }
/*     */ 
/*     */   private void pathFromRequest(HttpServletRequest request) {
/* 174 */     this.servletRequestURI = request.getRequestURI();
/* 175 */     replacePath(request.getRequestURI());
/*     */   }
/*     */ 
/*     */   public String removePathExtension()
/*     */   {
/* 195 */     String extension = null;
/* 196 */     if (this.servletRequestURI != null) {
/* 197 */       String filename = WebUtils.extractFullFilenameFromUrlPath(this.servletRequestURI);
/* 198 */       extension = StringUtils.getFilenameExtension(filename);
/* 199 */       if (!StringUtils.isEmpty(extension)) {
/* 200 */         int end = this.servletRequestURI.length() - (extension.length() + 1);
/* 201 */         replacePath(this.servletRequestURI.substring(0, end));
/*     */       }
/* 203 */       this.servletRequestURI = null;
/*     */     }
/* 205 */     return extension;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.support.ServletUriComponentsBuilder
 * JD-Core Version:    0.6.2
 */