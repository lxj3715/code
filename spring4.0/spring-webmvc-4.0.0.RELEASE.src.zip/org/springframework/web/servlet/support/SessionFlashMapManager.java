/*    */ package org.springframework.web.servlet.support;
/*    */ 
/*    */ import java.util.List;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.springframework.web.servlet.FlashMap;
/*    */ 
/*    */ public class SessionFlashMapManager extends AbstractFlashMapManager
/*    */ {
/* 35 */   private static final String FLASH_MAPS_SESSION_ATTRIBUTE = SessionFlashMapManager.class.getName() + ".FLASH_MAPS";
/*    */ 
/*    */   protected List<FlashMap> retrieveFlashMaps(HttpServletRequest request)
/*    */   {
/* 46 */     HttpSession session = request.getSession(false);
/* 47 */     return session != null ? (List)session.getAttribute(FLASH_MAPS_SESSION_ATTRIBUTE) : null;
/*    */   }
/*    */ 
/*    */   protected void updateFlashMaps(List<FlashMap> flashMaps, HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 55 */     request.getSession().setAttribute(FLASH_MAPS_SESSION_ATTRIBUTE, flashMaps);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.support.SessionFlashMapManager
 * JD-Core Version:    0.6.2
 */