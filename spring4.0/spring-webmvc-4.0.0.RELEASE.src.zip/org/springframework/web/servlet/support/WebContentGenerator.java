/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.HttpSessionRequiredException;
/*     */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*     */ 
/*     */ public abstract class WebContentGenerator extends WebApplicationObjectSupport
/*     */ {
/*     */   public static final String METHOD_GET = "GET";
/*     */   public static final String METHOD_HEAD = "HEAD";
/*     */   public static final String METHOD_POST = "POST";
/*     */   private static final String HEADER_PRAGMA = "Pragma";
/*     */   private static final String HEADER_EXPIRES = "Expires";
/*     */   private static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*     */   private Set<String> supportedMethods;
/*  70 */   private boolean requireSession = false;
/*     */ 
/*  73 */   private boolean useExpiresHeader = true;
/*     */ 
/*  76 */   private boolean useCacheControlHeader = true;
/*     */ 
/*  79 */   private boolean useCacheControlNoStore = true;
/*     */ 
/*  81 */   private int cacheSeconds = -1;
/*     */ 
/*  83 */   private boolean alwaysMustRevalidate = false;
/*     */ 
/*     */   public WebContentGenerator()
/*     */   {
/*  91 */     this(true);
/*     */   }
/*     */ 
/*     */   public WebContentGenerator(boolean restrictDefaultSupportedMethods)
/*     */   {
/* 101 */     if (restrictDefaultSupportedMethods) {
/* 102 */       this.supportedMethods = new HashSet(4);
/* 103 */       this.supportedMethods.add("GET");
/* 104 */       this.supportedMethods.add("HEAD");
/* 105 */       this.supportedMethods.add("POST");
/*     */     }
/*     */   }
/*     */ 
/*     */   public WebContentGenerator(String[] supportedMethods)
/*     */   {
/* 114 */     this.supportedMethods = new HashSet(Arrays.asList(supportedMethods));
/*     */   }
/*     */ 
/*     */   public final void setSupportedMethods(String[] methods)
/*     */   {
/* 124 */     if (methods != null) {
/* 125 */       this.supportedMethods = new HashSet(Arrays.asList(methods));
/*     */     }
/*     */     else
/* 128 */       this.supportedMethods = null;
/*     */   }
/*     */ 
/*     */   public final String[] getSupportedMethods()
/*     */   {
/* 136 */     return StringUtils.toStringArray(this.supportedMethods);
/*     */   }
/*     */ 
/*     */   public final void setRequireSession(boolean requireSession)
/*     */   {
/* 143 */     this.requireSession = requireSession;
/*     */   }
/*     */ 
/*     */   public final boolean isRequireSession()
/*     */   {
/* 150 */     return this.requireSession;
/*     */   }
/*     */ 
/*     */   public final void setUseExpiresHeader(boolean useExpiresHeader)
/*     */   {
/* 159 */     this.useExpiresHeader = useExpiresHeader;
/*     */   }
/*     */ 
/*     */   public final boolean isUseExpiresHeader()
/*     */   {
/* 166 */     return this.useExpiresHeader;
/*     */   }
/*     */ 
/*     */   public final void setUseCacheControlHeader(boolean useCacheControlHeader)
/*     */   {
/* 175 */     this.useCacheControlHeader = useCacheControlHeader;
/*     */   }
/*     */ 
/*     */   public final boolean isUseCacheControlHeader()
/*     */   {
/* 182 */     return this.useCacheControlHeader;
/*     */   }
/*     */ 
/*     */   public final void setUseCacheControlNoStore(boolean useCacheControlNoStore)
/*     */   {
/* 190 */     this.useCacheControlNoStore = useCacheControlNoStore;
/*     */   }
/*     */ 
/*     */   public final boolean isUseCacheControlNoStore()
/*     */   {
/* 197 */     return this.useCacheControlNoStore;
/*     */   }
/*     */ 
/*     */   public void setAlwaysMustRevalidate(boolean mustRevalidate)
/*     */   {
/* 209 */     this.alwaysMustRevalidate = mustRevalidate;
/*     */   }
/*     */ 
/*     */   public boolean isAlwaysMustRevalidate()
/*     */   {
/* 216 */     return this.alwaysMustRevalidate;
/*     */   }
/*     */ 
/*     */   public final void setCacheSeconds(int seconds)
/*     */   {
/* 227 */     this.cacheSeconds = seconds;
/*     */   }
/*     */ 
/*     */   public final int getCacheSeconds()
/*     */   {
/* 234 */     return this.cacheSeconds;
/*     */   }
/*     */ 
/*     */   protected final void checkAndPrepare(HttpServletRequest request, HttpServletResponse response, boolean lastModified)
/*     */     throws ServletException
/*     */   {
/* 251 */     checkAndPrepare(request, response, this.cacheSeconds, lastModified);
/*     */   }
/*     */ 
/*     */   protected final void checkAndPrepare(HttpServletRequest request, HttpServletResponse response, int cacheSeconds, boolean lastModified)
/*     */     throws ServletException
/*     */   {
/* 270 */     String method = request.getMethod();
/* 271 */     if ((this.supportedMethods != null) && (!this.supportedMethods.contains(method)))
/*     */     {
/* 273 */       throw new HttpRequestMethodNotSupportedException(method, 
/* 273 */         StringUtils.toStringArray(this.supportedMethods));
/*     */     }
/*     */ 
/* 277 */     if ((this.requireSession) && 
/* 278 */       (request.getSession(false) == null)) {
/* 279 */       throw new HttpSessionRequiredException("Pre-existing session required but none found");
/*     */     }
/*     */ 
/* 285 */     applyCacheSeconds(response, cacheSeconds, lastModified);
/*     */   }
/*     */ 
/*     */   protected final void preventCaching(HttpServletResponse response)
/*     */   {
/* 293 */     response.setHeader("Pragma", "no-cache");
/* 294 */     if (this.useExpiresHeader)
/*     */     {
/* 296 */       response.setDateHeader("Expires", 1L);
/*     */     }
/* 298 */     if (this.useCacheControlHeader)
/*     */     {
/* 301 */       response.setHeader("Cache-Control", "no-cache");
/* 302 */       if (this.useCacheControlNoStore)
/* 303 */         response.addHeader("Cache-Control", "no-store");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final void cacheForSeconds(HttpServletResponse response, int seconds)
/*     */   {
/* 317 */     cacheForSeconds(response, seconds, false);
/*     */   }
/*     */ 
/*     */   protected final void cacheForSeconds(HttpServletResponse response, int seconds, boolean mustRevalidate)
/*     */   {
/* 331 */     if (this.useExpiresHeader)
/*     */     {
/* 333 */       response.setDateHeader("Expires", System.currentTimeMillis() + seconds * 1000L);
/*     */     }
/* 335 */     if (this.useCacheControlHeader)
/*     */     {
/* 337 */       String headerValue = "max-age=" + seconds;
/* 338 */       if ((mustRevalidate) || (this.alwaysMustRevalidate)) {
/* 339 */         headerValue = headerValue + ", must-revalidate";
/*     */       }
/* 341 */       response.setHeader("Cache-Control", headerValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final void applyCacheSeconds(HttpServletResponse response, int seconds)
/*     */   {
/* 356 */     applyCacheSeconds(response, seconds, false);
/*     */   }
/*     */ 
/*     */   protected final void applyCacheSeconds(HttpServletResponse response, int seconds, boolean mustRevalidate)
/*     */   {
/* 372 */     if (seconds > 0) {
/* 373 */       cacheForSeconds(response, seconds, mustRevalidate);
/*     */     }
/* 375 */     else if (seconds == 0)
/* 376 */       preventCaching(response);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.support.WebContentGenerator
 * JD-Core Version:    0.6.2
 */