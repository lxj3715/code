package org.springframework.web.servlet.tags;

import javax.servlet.jsp.JspTagException;

public abstract interface ArgumentAware
{
  public abstract void addArgument(Object paramObject)
    throws JspTagException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.ArgumentAware
 * JD-Core Version:    0.6.2
 */