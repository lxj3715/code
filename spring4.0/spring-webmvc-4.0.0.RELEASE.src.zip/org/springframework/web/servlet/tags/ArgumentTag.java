/*    */ package org.springframework.web.servlet.tags;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.tagext.BodyContent;
/*    */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*    */ 
/*    */ public class ArgumentTag extends BodyTagSupport
/*    */ {
/*    */   private Object value;
/*    */   private boolean valueSet;
/*    */ 
/*    */   public int doEndTag()
/*    */     throws JspException
/*    */   {
/* 44 */     Object argument = null;
/* 45 */     if (this.valueSet) {
/* 46 */       argument = this.value;
/*    */     }
/* 48 */     else if (getBodyContent() != null)
/*    */     {
/* 50 */       argument = getBodyContent().getString().trim();
/*    */     }
/*    */ 
/* 54 */     ArgumentAware argumentAwareTag = (ArgumentAware)findAncestorWithClass(this, ArgumentAware.class);
/*    */ 
/* 56 */     if (argumentAwareTag == null) {
/* 57 */       throw new JspException("The argument tag must be a descendant of a tag that supports arguments");
/*    */     }
/*    */ 
/* 61 */     argumentAwareTag.addArgument(argument);
/*    */ 
/* 63 */     return 6;
/*    */   }
/*    */ 
/*    */   public void setValue(Object value)
/*    */   {
/* 77 */     this.value = value;
/* 78 */     this.valueSet = true;
/*    */   }
/*    */ 
/*    */   public void release()
/*    */   {
/* 83 */     super.release();
/* 84 */     this.value = null;
/* 85 */     this.valueSet = false;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.ArgumentTag
 * JD-Core Version:    0.6.2
 */