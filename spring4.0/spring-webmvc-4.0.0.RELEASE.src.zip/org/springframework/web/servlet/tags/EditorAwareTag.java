package org.springframework.web.servlet.tags;

import java.beans.PropertyEditor;
import javax.servlet.jsp.JspException;

public abstract interface EditorAwareTag
{
  public abstract PropertyEditor getEditor()
    throws JspException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.EditorAwareTag
 * JD-Core Version:    0.6.2
 */