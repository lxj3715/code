/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.tagext.BodyContent;
/*     */ import javax.servlet.jsp.tagext.BodyTag;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ import org.springframework.web.util.JavaScriptUtils;
/*     */ 
/*     */ public class EscapeBodyTag extends HtmlEscapingAwareTag
/*     */   implements BodyTag
/*     */ {
/*  47 */   private boolean javaScriptEscape = false;
/*     */   private BodyContent bodyContent;
/*     */ 
/*     */   public void setJavaScriptEscape(boolean javaScriptEscape)
/*     */     throws JspException
/*     */   {
/*  57 */     this.javaScriptEscape = javaScriptEscape;
/*     */   }
/*     */ 
/*     */   protected int doStartTagInternal()
/*     */   {
/*  64 */     return 2;
/*     */   }
/*     */ 
/*     */   public void doInitBody()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setBodyContent(BodyContent bodyContent)
/*     */   {
/*  74 */     this.bodyContent = bodyContent;
/*     */   }
/*     */ 
/*     */   public int doAfterBody() throws JspException
/*     */   {
/*     */     try {
/*  80 */       String content = readBodyContent();
/*     */ 
/*  82 */       content = isHtmlEscape() ? HtmlUtils.htmlEscape(content) : content;
/*  83 */       content = this.javaScriptEscape ? JavaScriptUtils.javaScriptEscape(content) : content;
/*  84 */       writeBodyContent(content);
/*     */     }
/*     */     catch (IOException ex) {
/*  87 */       throw new JspException("Could not write escaped body", ex);
/*     */     }
/*  89 */     return 0;
/*     */   }
/*     */ 
/*     */   protected String readBodyContent()
/*     */     throws IOException
/*     */   {
/*  98 */     return this.bodyContent.getString();
/*     */   }
/*     */ 
/*     */   protected void writeBodyContent(String content)
/*     */     throws IOException
/*     */   {
/* 108 */     this.bodyContent.getEnclosingWriter().print(content);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.EscapeBodyTag
 * JD-Core Version:    0.6.2
 */