/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.el.VariableResolver;
/*     */ import org.springframework.context.expression.BeanFactoryResolver;
/*     */ import org.springframework.context.expression.EnvironmentAccessor;
/*     */ import org.springframework.context.expression.MapAccessor;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.expression.spel.support.StandardTypeConverter;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ import org.springframework.web.util.JavaScriptUtils;
/*     */ import org.springframework.web.util.TagUtils;
/*     */ 
/*     */ public class EvalTag extends HtmlEscapingAwareTag
/*     */ {
/*     */   private static final String EVALUATION_CONTEXT_PAGE_ATTRIBUTE = "org.springframework.web.servlet.tags.EVALUATION_CONTEXT";
/*     */   private final ExpressionParser expressionParser;
/*     */   private Expression expression;
/*     */   private String var;
/*     */   private int scope;
/*     */   private boolean javaScriptEscape;
/*     */ 
/*     */   public EvalTag()
/*     */   {
/*  61 */     this.expressionParser = new SpelExpressionParser();
/*     */ 
/*  67 */     this.scope = 1;
/*     */ 
/*  69 */     this.javaScriptEscape = false;
/*     */   }
/*     */ 
/*     */   public void setExpression(String expression)
/*     */   {
/*  76 */     this.expression = this.expressionParser.parseExpression(expression);
/*     */   }
/*     */ 
/*     */   public void setVar(String var)
/*     */   {
/*  84 */     this.var = var;
/*     */   }
/*     */ 
/*     */   public void setScope(String scope)
/*     */   {
/*  92 */     this.scope = TagUtils.getScope(scope);
/*     */   }
/*     */ 
/*     */   public void setJavaScriptEscape(boolean javaScriptEscape)
/*     */     throws JspException
/*     */   {
/* 100 */     this.javaScriptEscape = javaScriptEscape;
/*     */   }
/*     */ 
/*     */   public int doStartTagInternal()
/*     */     throws JspException
/*     */   {
/* 106 */     return 1;
/*     */   }
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/* 112 */     EvaluationContext evaluationContext = (EvaluationContext)this.pageContext
/* 112 */       .getAttribute("org.springframework.web.servlet.tags.EVALUATION_CONTEXT");
/*     */ 
/* 113 */     if (evaluationContext == null) {
/* 114 */       evaluationContext = createEvaluationContext(this.pageContext);
/* 115 */       this.pageContext.setAttribute("org.springframework.web.servlet.tags.EVALUATION_CONTEXT", evaluationContext);
/*     */     }
/* 117 */     if (this.var != null) {
/* 118 */       Object result = this.expression.getValue(evaluationContext);
/* 119 */       this.pageContext.setAttribute(this.var, result, this.scope);
/*     */     }
/*     */     else {
/*     */       try {
/* 123 */         String result = (String)this.expression.getValue(evaluationContext, String.class);
/* 124 */         result = ObjectUtils.getDisplayString(result);
/* 125 */         result = isHtmlEscape() ? HtmlUtils.htmlEscape(result) : result;
/* 126 */         result = this.javaScriptEscape ? JavaScriptUtils.javaScriptEscape(result) : result;
/* 127 */         this.pageContext.getOut().print(result);
/*     */       }
/*     */       catch (IOException ex) {
/* 130 */         throw new JspException(ex);
/*     */       }
/*     */     }
/* 133 */     return 6;
/*     */   }
/*     */ 
/*     */   private EvaluationContext createEvaluationContext(PageContext pageContext) {
/* 137 */     StandardEvaluationContext context = new StandardEvaluationContext();
/* 138 */     context.addPropertyAccessor(new JspPropertyAccessor(pageContext));
/* 139 */     context.addPropertyAccessor(new MapAccessor());
/* 140 */     context.addPropertyAccessor(new EnvironmentAccessor());
/* 141 */     context.setBeanResolver(new BeanFactoryResolver(getRequestContext().getWebApplicationContext()));
/* 142 */     ConversionService conversionService = getConversionService(pageContext);
/* 143 */     if (conversionService != null) {
/* 144 */       context.setTypeConverter(new StandardTypeConverter(conversionService));
/*     */     }
/* 146 */     return context;
/*     */   }
/*     */ 
/*     */   private ConversionService getConversionService(PageContext pageContext) {
/* 150 */     return (ConversionService)pageContext.getRequest().getAttribute(ConversionService.class.getName());
/*     */   }
/*     */ 
/*     */   private static class JspPropertyAccessor
/*     */     implements PropertyAccessor
/*     */   {
/*     */     private final PageContext pageContext;
/*     */     private final VariableResolver variableResolver;
/*     */ 
/*     */     public JspPropertyAccessor(PageContext pageContext)
/*     */     {
/* 162 */       this.pageContext = pageContext;
/* 163 */       this.variableResolver = pageContext.getVariableResolver();
/*     */     }
/*     */ 
/*     */     public Class<?>[] getSpecificTargetClasses()
/*     */     {
/* 168 */       return null;
/*     */     }
/*     */ 
/*     */     public boolean canRead(EvaluationContext context, Object target, String name)
/*     */       throws AccessException
/*     */     {
/* 174 */       return (target == null) && (
/* 174 */         (resolveImplicitVariable(name) != null) || 
/* 174 */         (this.pageContext.findAttribute(name) != null));
/*     */     }
/*     */ 
/*     */     public TypedValue read(EvaluationContext context, Object target, String name) throws AccessException
/*     */     {
/* 179 */       Object implicitVar = resolveImplicitVariable(name);
/* 180 */       if (implicitVar != null) {
/* 181 */         return new TypedValue(implicitVar);
/*     */       }
/* 183 */       return new TypedValue(this.pageContext.findAttribute(name));
/*     */     }
/*     */ 
/*     */     public boolean canWrite(EvaluationContext context, Object target, String name)
/*     */     {
/* 188 */       return false;
/*     */     }
/*     */ 
/*     */     public void write(EvaluationContext context, Object target, String name, Object newValue)
/*     */     {
/* 193 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     private Object resolveImplicitVariable(String name) throws AccessException {
/* 197 */       if (this.variableResolver == null)
/* 198 */         return null;
/*     */       try
/*     */       {
/* 201 */         return this.variableResolver.resolveVariable(name);
/*     */       }
/*     */       catch (Exception ex) {
/* 204 */         throw new AccessException("Unexpected exception occurred accessing '" + name + "' as an implicit variable", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.EvalTag
 * JD-Core Version:    0.6.2
 */