/*    */ package org.springframework.web.servlet.tags;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import org.springframework.web.servlet.support.RequestContext;
/*    */ 
/*    */ public class HtmlEscapeTag extends RequestContextAwareTag
/*    */ {
/*    */   private boolean defaultHtmlEscape;
/*    */ 
/*    */   public void setDefaultHtmlEscape(boolean defaultHtmlEscape)
/*    */   {
/* 43 */     this.defaultHtmlEscape = defaultHtmlEscape;
/*    */   }
/*    */ 
/*    */   protected int doStartTagInternal()
/*    */     throws JspException
/*    */   {
/* 49 */     getRequestContext().setDefaultHtmlEscape(this.defaultHtmlEscape);
/* 50 */     return 1;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.HtmlEscapeTag
 * JD-Core Version:    0.6.2
 */