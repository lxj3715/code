/*    */ package org.springframework.web.servlet.tags;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import org.springframework.web.servlet.support.RequestContext;
/*    */ 
/*    */ public abstract class HtmlEscapingAwareTag extends RequestContextAwareTag
/*    */ {
/*    */   private Boolean htmlEscape;
/*    */ 
/*    */   public void setHtmlEscape(boolean htmlEscape)
/*    */     throws JspException
/*    */   {
/* 48 */     this.htmlEscape = Boolean.valueOf(htmlEscape);
/*    */   }
/*    */ 
/*    */   protected boolean isHtmlEscape()
/*    */   {
/* 57 */     if (this.htmlEscape != null) {
/* 58 */       return this.htmlEscape.booleanValue();
/*    */     }
/*    */ 
/* 61 */     return isDefaultHtmlEscape();
/*    */   }
/*    */ 
/*    */   protected boolean isDefaultHtmlEscape()
/*    */   {
/* 72 */     return getRequestContext().isDefaultHtmlEscape();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.HtmlEscapingAwareTag
 * JD-Core Version:    0.6.2
 */