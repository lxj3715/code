/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceResolvable;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ import org.springframework.web.util.JavaScriptUtils;
/*     */ import org.springframework.web.util.TagUtils;
/*     */ 
/*     */ public class MessageTag extends HtmlEscapingAwareTag
/*     */   implements ArgumentAware
/*     */ {
/*     */   public static final String DEFAULT_ARGUMENT_SEPARATOR = ",";
/*     */   private MessageSourceResolvable message;
/*     */   private String code;
/*     */   private Object arguments;
/*  75 */   private String argumentSeparator = ",";
/*     */   private List<Object> nestedArguments;
/*     */   private String text;
/*     */   private String var;
/*  83 */   private String scope = "page";
/*     */ 
/*  85 */   private boolean javaScriptEscape = false;
/*     */ 
/*     */   public void setMessage(MessageSourceResolvable message)
/*     */   {
/*  94 */     this.message = message;
/*     */   }
/*     */ 
/*     */   public void setCode(String code)
/*     */   {
/* 101 */     this.code = code;
/*     */   }
/*     */ 
/*     */   public void setArguments(Object arguments)
/*     */   {
/* 110 */     this.arguments = arguments;
/*     */   }
/*     */ 
/*     */   public void setArgumentSeparator(String argumentSeparator)
/*     */   {
/* 119 */     this.argumentSeparator = argumentSeparator;
/*     */   }
/*     */ 
/*     */   public void addArgument(Object argument) throws JspTagException
/*     */   {
/* 124 */     this.nestedArguments.add(argument);
/*     */   }
/*     */ 
/*     */   public void setText(String text)
/*     */   {
/* 131 */     this.text = text;
/*     */   }
/*     */ 
/*     */   public void setVar(String var)
/*     */   {
/* 141 */     this.var = var;
/*     */   }
/*     */ 
/*     */   public void setScope(String scope)
/*     */   {
/* 152 */     this.scope = scope;
/*     */   }
/*     */ 
/*     */   public void setJavaScriptEscape(boolean javaScriptEscape)
/*     */     throws JspException
/*     */   {
/* 160 */     this.javaScriptEscape = javaScriptEscape;
/*     */   }
/*     */ 
/*     */   protected final int doStartTagInternal()
/*     */     throws JspException, IOException
/*     */   {
/* 166 */     this.nestedArguments = new LinkedList();
/* 167 */     return 1;
/*     */   }
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/*     */     try
/*     */     {
/* 182 */       String msg = resolveMessage();
/*     */ 
/* 185 */       msg = isHtmlEscape() ? HtmlUtils.htmlEscape(msg) : msg;
/* 186 */       msg = this.javaScriptEscape ? JavaScriptUtils.javaScriptEscape(msg) : msg;
/*     */ 
/* 189 */       if (this.var != null) {
/* 190 */         this.pageContext.setAttribute(this.var, msg, TagUtils.getScope(this.scope));
/*     */       }
/*     */       else {
/* 193 */         writeMessage(msg);
/*     */       }
/*     */ 
/* 196 */       return 6;
/*     */     }
/*     */     catch (IOException ex) {
/* 199 */       throw new JspTagException(ex.getMessage(), ex);
/*     */     }
/*     */     catch (NoSuchMessageException ex) {
/* 202 */       throw new JspTagException(getNoSuchMessageExceptionDescription(ex));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void release()
/*     */   {
/* 208 */     super.release();
/* 209 */     this.arguments = null;
/*     */   }
/*     */ 
/*     */   protected String resolveMessage()
/*     */     throws JspException, NoSuchMessageException
/*     */   {
/* 217 */     MessageSource messageSource = getMessageSource();
/* 218 */     if (messageSource == null) {
/* 219 */       throw new JspTagException("No corresponding MessageSource found");
/*     */     }
/*     */ 
/* 223 */     if (this.message != null)
/*     */     {
/* 225 */       return messageSource.getMessage(this.message, getRequestContext().getLocale());
/*     */     }
/*     */ 
/* 228 */     if ((this.code != null) || (this.text != null))
/*     */     {
/* 230 */       Object[] argumentsArray = resolveArguments(this.arguments);
/* 231 */       if (!this.nestedArguments.isEmpty()) {
/* 232 */         argumentsArray = appendArguments(argumentsArray, this.nestedArguments
/* 233 */           .toArray());
/*     */       }
/*     */ 
/* 236 */       if (this.text != null)
/*     */       {
/* 238 */         return messageSource.getMessage(this.code, argumentsArray, this.text, 
/* 239 */           getRequestContext().getLocale());
/*     */       }
/*     */ 
/* 243 */       return messageSource.getMessage(this.code, argumentsArray, 
/* 244 */         getRequestContext().getLocale());
/*     */     }
/*     */ 
/* 249 */     return this.text;
/*     */   }
/*     */ 
/*     */   private Object[] appendArguments(Object[] sourceArguments, Object[] additionalArguments) {
/* 253 */     if (ObjectUtils.isEmpty(sourceArguments)) {
/* 254 */       return additionalArguments;
/*     */     }
/* 256 */     Object[] arguments = new Object[sourceArguments.length + additionalArguments.length];
/* 257 */     System.arraycopy(sourceArguments, 0, arguments, 0, sourceArguments.length);
/* 258 */     System.arraycopy(additionalArguments, 0, arguments, sourceArguments.length, additionalArguments.length);
/* 259 */     return arguments;
/*     */   }
/*     */ 
/*     */   protected Object[] resolveArguments(Object arguments)
/*     */     throws JspException
/*     */   {
/* 270 */     if ((arguments instanceof String))
/*     */     {
/* 272 */       String[] stringArray = StringUtils.delimitedListToStringArray((String)arguments, this.argumentSeparator);
/*     */ 
/* 273 */       if (stringArray.length == 1) {
/* 274 */         Object argument = stringArray[0];
/* 275 */         if ((argument != null) && (argument.getClass().isArray())) {
/* 276 */           return ObjectUtils.toObjectArray(argument);
/*     */         }
/*     */ 
/* 279 */         return new Object[] { argument };
/*     */       }
/*     */ 
/* 283 */       return stringArray;
/*     */     }
/*     */ 
/* 286 */     if ((arguments instanceof Object[])) {
/* 287 */       return (Object[])arguments;
/*     */     }
/* 289 */     if ((arguments instanceof Collection)) {
/* 290 */       return ((Collection)arguments).toArray();
/*     */     }
/* 292 */     if (arguments != null)
/*     */     {
/* 294 */       return new Object[] { arguments };
/*     */     }
/*     */ 
/* 297 */     return null;
/*     */   }
/*     */ 
/*     */   protected void writeMessage(String msg)
/*     */     throws IOException
/*     */   {
/* 308 */     this.pageContext.getOut().write(String.valueOf(msg));
/*     */   }
/*     */ 
/*     */   protected MessageSource getMessageSource()
/*     */   {
/* 315 */     return getRequestContext().getMessageSource();
/*     */   }
/*     */ 
/*     */   protected String getNoSuchMessageExceptionDescription(NoSuchMessageException ex)
/*     */   {
/* 322 */     return ex.getMessage();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.MessageTag
 * JD-Core Version:    0.6.2
 */