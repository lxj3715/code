/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import javax.servlet.jsp.tagext.TryCatchFinally;
/*     */ 
/*     */ public class NestedPathTag extends TagSupport
/*     */   implements TryCatchFinally
/*     */ {
/*     */   public static final String NESTED_PATH_VARIABLE_NAME = "nestedPath";
/*     */   private String path;
/*     */   private String previousNestedPath;
/*     */ 
/*     */   public void setPath(String path)
/*     */   {
/*  64 */     if (path == null) {
/*  65 */       path = "";
/*     */     }
/*  67 */     if ((path.length() > 0) && (!path.endsWith("."))) {
/*  68 */       path = path + ".";
/*     */     }
/*  70 */     this.path = path;
/*     */   }
/*     */ 
/*     */   public String getPath()
/*     */   {
/*  77 */     return this.path;
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/*  85 */     this.previousNestedPath = 
/*  86 */       ((String)this.pageContext
/*  86 */       .getAttribute("nestedPath", 2));
/*     */ 
/*  88 */     String nestedPath = this.previousNestedPath != null ? this.previousNestedPath + 
/*  88 */       getPath() : getPath();
/*  89 */     this.pageContext.setAttribute("nestedPath", nestedPath, 2);
/*     */ 
/*  91 */     return 1;
/*     */   }
/*     */ 
/*     */   public int doEndTag()
/*     */   {
/*  99 */     if (this.previousNestedPath != null)
/*     */     {
/* 101 */       this.pageContext.setAttribute("nestedPath", this.previousNestedPath, 2);
/*     */     }
/*     */     else
/*     */     {
/* 105 */       this.pageContext.removeAttribute("nestedPath", 2);
/*     */     }
/*     */ 
/* 108 */     return 6;
/*     */   }
/*     */ 
/*     */   public void doCatch(Throwable throwable) throws Throwable
/*     */   {
/* 113 */     throw throwable;
/*     */   }
/*     */ 
/*     */   public void doFinally()
/*     */   {
/* 118 */     this.previousNestedPath = null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.NestedPathTag
 * JD-Core Version:    0.6.2
 */