/*    */ package org.springframework.web.servlet.tags;
/*    */ 
/*    */ public class Param
/*    */ {
/*    */   private String name;
/*    */   private String value;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 40 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name)
/*    */   {
/* 47 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 54 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(String value)
/*    */   {
/* 61 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 66 */     return "JSP Tag Param: name '" + this.name + "', value '" + this.value + "'";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.Param
 * JD-Core Version:    0.6.2
 */