package org.springframework.web.servlet.tags;

public abstract interface ParamAware
{
  public abstract void addParam(Param paramParam);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.ParamAware
 * JD-Core Version:    0.6.2
 */