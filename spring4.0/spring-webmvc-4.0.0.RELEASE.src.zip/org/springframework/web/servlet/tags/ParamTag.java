/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.BodyContent;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ 
/*     */ public class ParamTag extends BodyTagSupport
/*     */ {
/*     */   private String name;
/*     */   private String value;
/*     */   private boolean valueSet;
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/*  47 */     Param param = new Param();
/*  48 */     param.setName(this.name);
/*  49 */     if (this.valueSet) {
/*  50 */       param.setValue(this.value);
/*     */     }
/*  52 */     else if (getBodyContent() != null)
/*     */     {
/*  54 */       param.setValue(getBodyContent().getString().trim());
/*     */     }
/*     */ 
/*  58 */     ParamAware paramAwareTag = (ParamAware)findAncestorWithClass(this, ParamAware.class);
/*     */ 
/*  60 */     if (paramAwareTag == null) {
/*  61 */       throw new JspException("The param tag must be a descendant of a tag that supports parameters");
/*     */     }
/*     */ 
/*  65 */     paramAwareTag.addParam(param);
/*     */ 
/*  67 */     return 6;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  81 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void setValue(String value)
/*     */   {
/*  93 */     this.value = value;
/*  94 */     this.valueSet = true;
/*     */   }
/*     */ 
/*     */   public void release()
/*     */   {
/*  99 */     super.release();
/* 100 */     this.name = null;
/* 101 */     this.value = null;
/* 102 */     this.valueSet = false;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.ParamTag
 * JD-Core Version:    0.6.2
 */