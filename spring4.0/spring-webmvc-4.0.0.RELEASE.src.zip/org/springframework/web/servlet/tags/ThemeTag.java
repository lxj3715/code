/*    */ package org.springframework.web.servlet.tags;
/*    */ 
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.NoSuchMessageException;
/*    */ import org.springframework.ui.context.Theme;
/*    */ import org.springframework.web.servlet.support.RequestContext;
/*    */ 
/*    */ public class ThemeTag extends MessageTag
/*    */ {
/*    */   protected MessageSource getMessageSource()
/*    */   {
/* 55 */     return getRequestContext().getTheme().getMessageSource();
/*    */   }
/*    */ 
/*    */   protected String getNoSuchMessageExceptionDescription(NoSuchMessageException ex)
/*    */   {
/* 63 */     return "Theme '" + getRequestContext().getTheme().getName() + "': " + ex.getMessage();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.ThemeTag
 * JD-Core Version:    0.6.2
 */