/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.io.IOException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ import org.springframework.web.util.TagUtils;
/*     */ 
/*     */ public class TransformTag extends HtmlEscapingAwareTag
/*     */ {
/*     */   private Object value;
/*     */   private String var;
/*  51 */   private String scope = "page";
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/*  62 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public void setVar(String var)
/*     */   {
/*  72 */     this.var = var;
/*     */   }
/*     */ 
/*     */   public void setScope(String scope)
/*     */   {
/*  83 */     this.scope = scope;
/*     */   }
/*     */ 
/*     */   protected final int doStartTagInternal()
/*     */     throws JspException
/*     */   {
/*  89 */     if (this.value != null)
/*     */     {
/*  91 */       EditorAwareTag tag = (EditorAwareTag)TagSupport.findAncestorWithClass(this, EditorAwareTag.class);
/*  92 */       if (tag == null) {
/*  93 */         throw new JspException("TransformTag can only be used within EditorAwareTag (e.g. BindTag)");
/*     */       }
/*     */ 
/*  97 */       String result = null;
/*  98 */       PropertyEditor editor = tag.getEditor();
/*  99 */       if (editor != null)
/*     */       {
/* 101 */         editor.setValue(this.value);
/* 102 */         result = editor.getAsText();
/*     */       }
/*     */       else
/*     */       {
/* 106 */         result = this.value.toString();
/*     */       }
/* 108 */       result = isHtmlEscape() ? HtmlUtils.htmlEscape(result) : result;
/* 109 */       if (this.var != null) {
/* 110 */         this.pageContext.setAttribute(this.var, result, TagUtils.getScope(this.scope));
/*     */       }
/*     */       else {
/*     */         try
/*     */         {
/* 115 */           this.pageContext.getOut().print(result);
/*     */         }
/*     */         catch (IOException ex) {
/* 118 */           throw new JspException(ex);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 123 */     return 0;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.TransformTag
 * JD-Core Version:    0.6.2
 */