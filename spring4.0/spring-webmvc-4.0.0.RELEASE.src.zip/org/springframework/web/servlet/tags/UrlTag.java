/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.servlet.support.RequestDataValueProcessor;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ import org.springframework.web.util.JavaScriptUtils;
/*     */ import org.springframework.web.util.TagUtils;
/*     */ import org.springframework.web.util.UriUtils;
/*     */ 
/*     */ public class UrlTag extends HtmlEscapingAwareTag
/*     */   implements ParamAware
/*     */ {
/*     */   private static final String URL_TEMPLATE_DELIMITER_PREFIX = "{";
/*     */   private static final String URL_TEMPLATE_DELIMITER_SUFFIX = "}";
/*     */   private static final String URL_TYPE_ABSOLUTE = "://";
/*     */   private List<Param> params;
/*     */   private Set<String> templateParams;
/*     */   private UrlType type;
/*     */   private String value;
/*     */   private String context;
/*     */   private String var;
/*     */   private int scope;
/*     */   private boolean javaScriptEscape;
/*     */ 
/*     */   public UrlTag()
/*     */   {
/*  98 */     this.scope = 1;
/*     */ 
/* 100 */     this.javaScriptEscape = false;
/*     */   }
/*     */ 
/*     */   public void setValue(String value)
/*     */   {
/* 107 */     if (value.contains("://")) {
/* 108 */       this.type = UrlType.ABSOLUTE;
/* 109 */       this.value = value;
/*     */     }
/* 111 */     else if (value.startsWith("/")) {
/* 112 */       this.type = UrlType.CONTEXT_RELATIVE;
/* 113 */       this.value = value;
/*     */     }
/*     */     else {
/* 116 */       this.type = UrlType.RELATIVE;
/* 117 */       this.value = value;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setContext(String context)
/*     */   {
/* 125 */     if (context.startsWith("/")) {
/* 126 */       this.context = context;
/*     */     }
/*     */     else
/* 129 */       this.context = new StringBuilder().append("/").append(context).toString();
/*     */   }
/*     */ 
/*     */   public void setVar(String var)
/*     */   {
/* 138 */     this.var = var;
/*     */   }
/*     */ 
/*     */   public void setScope(String scope)
/*     */   {
/* 146 */     this.scope = TagUtils.getScope(scope);
/*     */   }
/*     */ 
/*     */   public void setJavaScriptEscape(boolean javaScriptEscape)
/*     */     throws JspException
/*     */   {
/* 154 */     this.javaScriptEscape = javaScriptEscape;
/*     */   }
/*     */ 
/*     */   public void addParam(Param param)
/*     */   {
/* 159 */     this.params.add(param);
/*     */   }
/*     */ 
/*     */   public int doStartTagInternal()
/*     */     throws JspException
/*     */   {
/* 165 */     this.params = new LinkedList();
/* 166 */     this.templateParams = new HashSet();
/* 167 */     return 1;
/*     */   }
/*     */ 
/*     */   public int doEndTag() throws JspException
/*     */   {
/* 172 */     String url = createUrl();
/*     */ 
/* 174 */     RequestDataValueProcessor processor = getRequestContext().getRequestDataValueProcessor();
/* 175 */     ServletRequest request = this.pageContext.getRequest();
/* 176 */     if ((processor != null) && ((request instanceof HttpServletRequest))) {
/* 177 */       url = processor.processUrl((HttpServletRequest)request, url);
/*     */     }
/*     */ 
/* 180 */     if (this.var == null) {
/*     */       try
/*     */       {
/* 183 */         this.pageContext.getOut().print(url);
/*     */       }
/*     */       catch (IOException e) {
/* 186 */         throw new JspException(e);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 191 */       this.pageContext.setAttribute(this.var, url, this.scope);
/*     */     }
/* 193 */     return 6;
/*     */   }
/*     */ 
/*     */   private String createUrl()
/*     */     throws JspException
/*     */   {
/* 203 */     HttpServletRequest request = (HttpServletRequest)this.pageContext.getRequest();
/* 204 */     HttpServletResponse response = (HttpServletResponse)this.pageContext.getResponse();
/* 205 */     StringBuilder url = new StringBuilder();
/* 206 */     if (this.type == UrlType.CONTEXT_RELATIVE)
/*     */     {
/* 208 */       if (this.context == null) {
/* 209 */         url.append(request.getContextPath());
/*     */       }
/*     */       else {
/* 212 */         url.append(this.context);
/*     */       }
/*     */     }
/* 215 */     if ((this.type != UrlType.RELATIVE) && (this.type != UrlType.ABSOLUTE) && (!this.value.startsWith("/"))) {
/* 216 */       url.append("/");
/*     */     }
/* 218 */     url.append(replaceUriTemplateParams(this.value, this.params, this.templateParams));
/* 219 */     url.append(createQueryString(this.params, this.templateParams, url.indexOf("?") == -1));
/*     */ 
/* 221 */     String urlStr = url.toString();
/* 222 */     if (this.type != UrlType.ABSOLUTE)
/*     */     {
/* 225 */       urlStr = response.encodeURL(urlStr);
/*     */     }
/*     */ 
/* 229 */     urlStr = isHtmlEscape() ? HtmlUtils.htmlEscape(urlStr) : urlStr;
/* 230 */     urlStr = this.javaScriptEscape ? JavaScriptUtils.javaScriptEscape(urlStr) : urlStr;
/*     */ 
/* 232 */     return urlStr;
/*     */   }
/*     */ 
/*     */   protected String createQueryString(List<Param> params, Set<String> usedParams, boolean includeQueryStringDelimiter)
/*     */     throws JspException
/*     */   {
/* 249 */     String encoding = this.pageContext.getResponse().getCharacterEncoding();
/* 250 */     StringBuilder qs = new StringBuilder();
/* 251 */     for (Param param : params) {
/* 252 */       if ((!usedParams.contains(param.getName())) && (StringUtils.hasLength(param.getName()))) {
/* 253 */         if ((includeQueryStringDelimiter) && (qs.length() == 0)) {
/* 254 */           qs.append("?");
/*     */         }
/*     */         else
/* 257 */           qs.append("&");
/*     */         try
/*     */         {
/* 260 */           qs.append(UriUtils.encodeQueryParam(param.getName(), encoding));
/* 261 */           if (param.getValue() != null) {
/* 262 */             qs.append("=");
/* 263 */             qs.append(UriUtils.encodeQueryParam(param.getValue(), encoding));
/*     */           }
/*     */         }
/*     */         catch (UnsupportedEncodingException ex) {
/* 267 */           throw new JspException(ex);
/*     */         }
/*     */       }
/*     */     }
/* 271 */     return qs.toString();
/*     */   }
/*     */ 
/*     */   protected String replaceUriTemplateParams(String uri, List<Param> params, Set<String> usedParams)
/*     */     throws JspException
/*     */   {
/* 286 */     String encoding = this.pageContext.getResponse().getCharacterEncoding();
/* 287 */     for (Param param : params) {
/* 288 */       String template = new StringBuilder().append("{").append(param.getName()).append("}").toString();
/* 289 */       if (uri.contains(template)) {
/* 290 */         usedParams.add(param.getName());
/*     */         try {
/* 292 */           uri = uri.replace(template, UriUtils.encodePath(param.getValue(), encoding));
/*     */         }
/*     */         catch (UnsupportedEncodingException ex) {
/* 295 */           throw new JspException(ex);
/*     */         }
/*     */       }
/*     */     }
/* 299 */     return uri;
/*     */   }
/*     */ 
/*     */   private static enum UrlType
/*     */   {
/* 306 */     CONTEXT_RELATIVE, RELATIVE, ABSOLUTE;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.UrlTag
 * JD-Core Version:    0.6.2
 */