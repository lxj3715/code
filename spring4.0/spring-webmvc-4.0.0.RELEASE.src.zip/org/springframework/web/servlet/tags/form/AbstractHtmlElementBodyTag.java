/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.BodyContent;
/*     */ import javax.servlet.jsp.tagext.BodyTag;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractHtmlElementBodyTag extends AbstractHtmlElementTag
/*     */   implements BodyTag
/*     */ {
/*     */   private BodyContent bodyContent;
/*     */   private TagWriter tagWriter;
/*     */ 
/*     */   protected int writeTagContent(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/*  46 */     onWriteTagContent();
/*  47 */     this.tagWriter = tagWriter;
/*  48 */     if (shouldRender()) {
/*  49 */       exposeAttributes();
/*  50 */       return 2;
/*     */     }
/*     */ 
/*  53 */     return 0;
/*     */   }
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/*  65 */     if (shouldRender()) {
/*  66 */       if ((this.bodyContent != null) && (StringUtils.hasText(this.bodyContent.getString()))) {
/*  67 */         renderFromBodyContent(this.bodyContent, this.tagWriter);
/*     */       }
/*     */       else {
/*  70 */         renderDefaultContent(this.tagWriter);
/*     */       }
/*     */     }
/*  73 */     return 6;
/*     */   }
/*     */ 
/*     */   protected void renderFromBodyContent(BodyContent bodyContent, TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/*  83 */     flushBufferedBodyContent(this.bodyContent);
/*     */   }
/*     */ 
/*     */   public void doFinally()
/*     */   {
/*  91 */     super.doFinally();
/*  92 */     removeAttributes();
/*  93 */     this.tagWriter = null;
/*  94 */     this.bodyContent = null;
/*     */   }
/*     */ 
/*     */   protected void onWriteTagContent()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected boolean shouldRender()
/*     */     throws JspException
/*     */   {
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */   protected void exposeAttributes()
/*     */     throws JspException
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void removeAttributes()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void flushBufferedBodyContent(BodyContent bodyContent)
/*     */     throws JspException
/*     */   {
/*     */     try
/*     */     {
/* 138 */       bodyContent.writeOut(bodyContent.getEnclosingWriter());
/*     */     }
/*     */     catch (IOException e) {
/* 141 */       throw new JspException("Unable to write buffered body content.", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract void renderDefaultContent(TagWriter paramTagWriter)
/*     */     throws JspException;
/*     */ 
/*     */   public void doInitBody()
/*     */     throws JspException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setBodyContent(BodyContent bodyContent)
/*     */   {
/* 159 */     this.bodyContent = bodyContent;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.form.AbstractHtmlElementBodyTag
 * JD-Core Version:    0.6.2
 */