/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ 
/*     */ public abstract class AbstractMultiCheckedElementTag extends AbstractCheckedElementTag
/*     */ {
/*     */   private static final String SPAN_TAG = "span";
/*     */   private Object items;
/*     */   private String itemValue;
/*     */   private String itemLabel;
/*  70 */   private String element = "span";
/*     */   private String delimiter;
/*     */ 
/*     */   public void setItems(Object items)
/*     */   {
/*  85 */     Assert.notNull(items, "'items' must not be null");
/*  86 */     this.items = items;
/*     */   }
/*     */ 
/*     */   protected Object getItems()
/*     */   {
/*  94 */     return this.items;
/*     */   }
/*     */ 
/*     */   public void setItemValue(String itemValue)
/*     */   {
/* 103 */     Assert.hasText(itemValue, "'itemValue' must not be empty");
/* 104 */     this.itemValue = itemValue;
/*     */   }
/*     */ 
/*     */   protected String getItemValue()
/*     */   {
/* 112 */     return this.itemValue;
/*     */   }
/*     */ 
/*     */   public void setItemLabel(String itemLabel)
/*     */   {
/* 121 */     Assert.hasText(itemLabel, "'itemLabel' must not be empty");
/* 122 */     this.itemLabel = itemLabel;
/*     */   }
/*     */ 
/*     */   protected String getItemLabel()
/*     */   {
/* 130 */     return this.itemLabel;
/*     */   }
/*     */ 
/*     */   public void setDelimiter(String delimiter)
/*     */   {
/* 139 */     this.delimiter = delimiter;
/*     */   }
/*     */ 
/*     */   public String getDelimiter()
/*     */   {
/* 147 */     return this.delimiter;
/*     */   }
/*     */ 
/*     */   public void setElement(String element)
/*     */   {
/* 156 */     Assert.hasText(element, "'element' cannot be null or blank");
/* 157 */     this.element = element;
/*     */   }
/*     */ 
/*     */   public String getElement()
/*     */   {
/* 165 */     return this.element;
/*     */   }
/*     */ 
/*     */   protected String resolveId()
/*     */     throws JspException
/*     */   {
/* 175 */     Object id = evaluate("id", getId());
/* 176 */     if (id != null) {
/* 177 */       String idString = id.toString();
/* 178 */       return StringUtils.hasText(idString) ? TagIdGenerator.nextId(idString, this.pageContext) : null;
/*     */     }
/* 180 */     return autogenerateId();
/*     */   }
/*     */ 
/*     */   protected int writeTagContent(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 191 */     Object items = getItems();
/* 192 */     Object itemsObject = (items instanceof String) ? evaluate("items", items) : items;
/*     */ 
/* 194 */     String itemValue = getItemValue();
/* 195 */     String itemLabel = getItemLabel();
/*     */ 
/* 197 */     String valueProperty = itemValue != null ? 
/* 197 */       ObjectUtils.getDisplayString(evaluate("itemValue", itemValue)) : 
/* 197 */       null;
/*     */ 
/* 199 */     String labelProperty = itemLabel != null ? 
/* 199 */       ObjectUtils.getDisplayString(evaluate("itemLabel", itemLabel)) : 
/* 199 */       null;
/*     */ 
/* 201 */     Class boundType = getBindStatus().getValueType();
/* 202 */     if ((itemsObject == null) && (boundType != null) && (boundType.isEnum())) {
/* 203 */       itemsObject = boundType.getEnumConstants();
/*     */     }
/*     */ 
/* 206 */     if (itemsObject == null) {
/* 207 */       throw new IllegalArgumentException("Attribute 'items' is required and must be a Collection, an Array or a Map");
/*     */     }
/*     */ 
/* 210 */     if (itemsObject.getClass().isArray()) {
/* 211 */       Object[] itemsArray = (Object[])itemsObject;
/* 212 */       for (int i = 0; i < itemsArray.length; i++) {
/* 213 */         Object item = itemsArray[i];
/* 214 */         writeObjectEntry(tagWriter, valueProperty, labelProperty, item, i);
/*     */       }
/*     */     }
/* 217 */     else if ((itemsObject instanceof Collection)) {
/* 218 */       Collection optionCollection = (Collection)itemsObject;
/* 219 */       int itemIndex = 0;
/* 220 */       for (Iterator it = optionCollection.iterator(); it.hasNext(); itemIndex++) {
/* 221 */         Object item = it.next();
/* 222 */         writeObjectEntry(tagWriter, valueProperty, labelProperty, item, itemIndex);
/*     */       }
/*     */     }
/* 225 */     else if ((itemsObject instanceof Map)) {
/* 226 */       Map optionMap = (Map)itemsObject;
/* 227 */       int itemIndex = 0;
/* 228 */       for (Iterator it = optionMap.entrySet().iterator(); it.hasNext(); itemIndex++) {
/* 229 */         Map.Entry entry = (Map.Entry)it.next();
/* 230 */         writeMapEntry(tagWriter, valueProperty, labelProperty, entry, itemIndex);
/*     */       }
/*     */     }
/*     */     else {
/* 234 */       throw new IllegalArgumentException("Attribute 'items' must be an array, a Collection or a Map");
/*     */     }
/*     */ 
/* 237 */     return 0;
/*     */   }
/*     */ 
/*     */   private void writeObjectEntry(TagWriter tagWriter, String valueProperty, String labelProperty, Object item, int itemIndex)
/*     */     throws JspException
/*     */   {
/* 243 */     BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(item);
/*     */     Object renderValue;
/*     */     Object renderValue;
/* 245 */     if (valueProperty != null) {
/* 246 */       renderValue = wrapper.getPropertyValue(valueProperty);
/*     */     }
/*     */     else
/*     */     {
/*     */       Object renderValue;
/* 248 */       if ((item instanceof Enum)) {
/* 249 */         renderValue = ((Enum)item).name();
/*     */       }
/*     */       else
/* 252 */         renderValue = item;
/*     */     }
/* 254 */     Object renderLabel = labelProperty != null ? wrapper.getPropertyValue(labelProperty) : item;
/* 255 */     writeElementTag(tagWriter, item, renderValue, renderLabel, itemIndex);
/*     */   }
/*     */ 
/*     */   private void writeMapEntry(TagWriter tagWriter, String valueProperty, String labelProperty, Map.Entry<?, ?> entry, int itemIndex)
/*     */     throws JspException
/*     */   {
/* 261 */     Object mapKey = entry.getKey();
/* 262 */     Object mapValue = entry.getValue();
/* 263 */     BeanWrapper mapKeyWrapper = PropertyAccessorFactory.forBeanPropertyAccess(mapKey);
/* 264 */     BeanWrapper mapValueWrapper = PropertyAccessorFactory.forBeanPropertyAccess(mapValue);
/*     */ 
/* 266 */     Object renderValue = valueProperty != null ? mapKeyWrapper
/* 266 */       .getPropertyValue(valueProperty) : 
/* 266 */       mapKey.toString();
/*     */ 
/* 268 */     Object renderLabel = labelProperty != null ? mapValueWrapper
/* 268 */       .getPropertyValue(labelProperty) : 
/* 268 */       mapValue.toString();
/* 269 */     writeElementTag(tagWriter, mapKey, renderValue, renderLabel, itemIndex);
/*     */   }
/*     */ 
/*     */   private void writeElementTag(TagWriter tagWriter, Object item, Object value, Object label, int itemIndex)
/*     */     throws JspException
/*     */   {
/* 275 */     tagWriter.startTag(getElement());
/* 276 */     if (itemIndex > 0) {
/* 277 */       Object resolvedDelimiter = evaluate("delimiter", getDelimiter());
/* 278 */       if (resolvedDelimiter != null) {
/* 279 */         tagWriter.appendValue(resolvedDelimiter.toString());
/*     */       }
/*     */     }
/* 282 */     tagWriter.startTag("input");
/* 283 */     String id = resolveId();
/* 284 */     writeOptionalAttribute(tagWriter, "id", id);
/* 285 */     writeOptionalAttribute(tagWriter, "name", getName());
/* 286 */     writeOptionalAttributes(tagWriter);
/* 287 */     tagWriter.writeAttribute("type", getInputType());
/* 288 */     renderFromValue(item, value, tagWriter);
/* 289 */     tagWriter.endTag();
/* 290 */     tagWriter.startTag("label");
/* 291 */     tagWriter.writeAttribute("for", id);
/* 292 */     tagWriter.appendValue(convertToDisplayString(label));
/* 293 */     tagWriter.endTag();
/* 294 */     tagWriter.endTag();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.form.AbstractMultiCheckedElementTag
 * JD-Core Version:    0.6.2
 */