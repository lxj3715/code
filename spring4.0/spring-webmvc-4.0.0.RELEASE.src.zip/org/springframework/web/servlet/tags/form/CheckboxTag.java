/*    */ package org.springframework.web.servlet.tags.form;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import org.springframework.web.servlet.support.BindStatus;
/*    */ 
/*    */ public class CheckboxTag extends AbstractSingleCheckedElementTag
/*    */ {
/*    */   protected int writeTagContent(TagWriter tagWriter)
/*    */     throws JspException
/*    */   {
/* 53 */     super.writeTagContent(tagWriter);
/*    */ 
/* 55 */     if (!isDisabled())
/*    */     {
/* 57 */       tagWriter.startTag("input");
/* 58 */       tagWriter.writeAttribute("type", "hidden");
/* 59 */       String name = "_" + getName();
/* 60 */       tagWriter.writeAttribute("name", name);
/* 61 */       tagWriter.writeAttribute("value", processFieldValue(name, "on", getInputType()));
/* 62 */       tagWriter.endTag();
/*    */     }
/*    */ 
/* 65 */     return 0;
/*    */   }
/*    */ 
/*    */   protected void writeTagDetails(TagWriter tagWriter) throws JspException
/*    */   {
/* 70 */     tagWriter.writeAttribute("type", getInputType());
/*    */ 
/* 72 */     Object boundValue = getBoundValue();
/* 73 */     Class valueType = getBindStatus().getValueType();
/*    */ 
/* 75 */     if ((Boolean.class.equals(valueType)) || (Boolean.TYPE.equals(valueType)))
/*    */     {
/* 77 */       if ((boundValue instanceof String)) {
/* 78 */         boundValue = Boolean.valueOf((String)boundValue);
/*    */       }
/* 80 */       Boolean booleanValue = boundValue != null ? (Boolean)boundValue : Boolean.FALSE;
/* 81 */       renderFromBoolean(booleanValue, tagWriter);
/*    */     }
/*    */     else
/*    */     {
/* 85 */       Object value = getValue();
/* 86 */       if (value == null) {
/* 87 */         throw new IllegalArgumentException("Attribute 'value' is required when binding to non-boolean values");
/*    */       }
/* 89 */       Object resolvedValue = (value instanceof String) ? evaluate("value", value) : value;
/* 90 */       renderFromValue(resolvedValue, tagWriter);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected String getInputType()
/*    */   {
/* 96 */     return "checkbox";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.form.CheckboxTag
 * JD-Core Version:    0.6.2
 */