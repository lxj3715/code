/*    */ package org.springframework.web.servlet.tags.form;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ 
/*    */ public class CheckboxesTag extends AbstractMultiCheckedElementTag
/*    */ {
/*    */   protected int writeTagContent(TagWriter tagWriter)
/*    */     throws JspException
/*    */   {
/* 39 */     super.writeTagContent(tagWriter);
/*    */ 
/* 41 */     if (!isDisabled())
/*    */     {
/* 43 */       tagWriter.startTag("input");
/* 44 */       tagWriter.writeAttribute("type", "hidden");
/* 45 */       String name = "_" + getName();
/* 46 */       tagWriter.writeAttribute("name", name);
/* 47 */       tagWriter.writeAttribute("value", processFieldValue(name, "on", getInputType()));
/* 48 */       tagWriter.endTag();
/*    */     }
/*    */ 
/* 51 */     return 0;
/*    */   }
/*    */ 
/*    */   protected String getInputType()
/*    */   {
/* 56 */     return "checkbox";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.form.CheckboxesTag
 * JD-Core Version:    0.6.2
 */