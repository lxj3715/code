/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.servlet.support.RequestDataValueProcessor;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ 
/*     */ public class FormTag extends AbstractHtmlElementTag
/*     */ {
/*     */   private static final String DEFAULT_METHOD = "post";
/*     */   public static final String DEFAULT_COMMAND_NAME = "command";
/*     */   private static final String MODEL_ATTRIBUTE = "modelAttribute";
/*  68 */   public static final String MODEL_ATTRIBUTE_VARIABLE_NAME = Conventions.getQualifiedAttributeName(AbstractFormTag.class, "modelAttribute")
/*  68 */     ;
/*     */   private static final String DEFAULT_METHOD_PARAM = "_method";
/*     */   private static final String FORM_TAG = "form";
/*     */   private static final String INPUT_TAG = "input";
/*     */   private static final String ACTION_ATTRIBUTE = "action";
/*     */   private static final String METHOD_ATTRIBUTE = "method";
/*     */   private static final String TARGET_ATTRIBUTE = "target";
/*     */   private static final String ENCTYPE_ATTRIBUTE = "enctype";
/*     */   private static final String ACCEPT_CHARSET_ATTRIBUTE = "accept-charset";
/*     */   private static final String ONSUBMIT_ATTRIBUTE = "onsubmit";
/*     */   private static final String ONRESET_ATTRIBUTE = "onreset";
/*     */   private static final String AUTOCOMPLETE_ATTRIBUTE = "autocomplete";
/*     */   private static final String NAME_ATTRIBUTE = "name";
/*     */   private static final String VALUE_ATTRIBUTE = "value";
/*     */   private static final String TYPE_ATTRIBUTE = "type";
/*     */   private TagWriter tagWriter;
/* 102 */   private String modelAttribute = "command";
/*     */   private String name;
/*     */   private String action;
/*     */   private String servletRelativeAction;
/* 110 */   private String method = "post";
/*     */   private String target;
/*     */   private String enctype;
/*     */   private String acceptCharset;
/*     */   private String onsubmit;
/*     */   private String onreset;
/*     */   private String autocomplete;
/* 124 */   private String methodParam = "_method";
/*     */   private String previousNestedPath;
/*     */ 
/*     */   public void setModelAttribute(String modelAttribute)
/*     */   {
/* 135 */     this.modelAttribute = modelAttribute;
/*     */   }
/*     */ 
/*     */   protected String getModelAttribute()
/*     */   {
/* 142 */     return this.modelAttribute;
/*     */   }
/*     */ 
/*     */   public void setCommandName(String commandName)
/*     */   {
/* 151 */     this.modelAttribute = commandName;
/*     */   }
/*     */ 
/*     */   protected String getCommandName()
/*     */   {
/* 159 */     return this.modelAttribute;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 169 */     this.name = name;
/*     */   }
/*     */ 
/*     */   protected String getName()
/*     */     throws JspException
/*     */   {
/* 177 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setAction(String action)
/*     */   {
/* 185 */     this.action = (action != null ? action : "");
/*     */   }
/*     */ 
/*     */   protected String getAction()
/*     */   {
/* 192 */     return this.action;
/*     */   }
/*     */ 
/*     */   public void setServletRelativeAction(String servletRelativeaction)
/*     */   {
/* 200 */     this.servletRelativeAction = (servletRelativeaction != null ? servletRelativeaction : "");
/*     */   }
/*     */ 
/*     */   protected String getServletRelativeAction()
/*     */   {
/* 207 */     return this.servletRelativeAction;
/*     */   }
/*     */ 
/*     */   public void setMethod(String method)
/*     */   {
/* 215 */     this.method = method;
/*     */   }
/*     */ 
/*     */   protected String getMethod()
/*     */   {
/* 222 */     return this.method;
/*     */   }
/*     */ 
/*     */   public void setTarget(String target)
/*     */   {
/* 230 */     this.target = target;
/*     */   }
/*     */ 
/*     */   public String getTarget()
/*     */   {
/* 237 */     return this.target;
/*     */   }
/*     */ 
/*     */   public void setEnctype(String enctype)
/*     */   {
/* 245 */     this.enctype = enctype;
/*     */   }
/*     */ 
/*     */   protected String getEnctype()
/*     */   {
/* 252 */     return this.enctype;
/*     */   }
/*     */ 
/*     */   public void setAcceptCharset(String acceptCharset)
/*     */   {
/* 260 */     this.acceptCharset = acceptCharset;
/*     */   }
/*     */ 
/*     */   protected String getAcceptCharset()
/*     */   {
/* 267 */     return this.acceptCharset;
/*     */   }
/*     */ 
/*     */   public void setOnsubmit(String onsubmit)
/*     */   {
/* 275 */     this.onsubmit = onsubmit;
/*     */   }
/*     */ 
/*     */   protected String getOnsubmit()
/*     */   {
/* 282 */     return this.onsubmit;
/*     */   }
/*     */ 
/*     */   public void setOnreset(String onreset)
/*     */   {
/* 290 */     this.onreset = onreset;
/*     */   }
/*     */ 
/*     */   protected String getOnreset()
/*     */   {
/* 297 */     return this.onreset;
/*     */   }
/*     */ 
/*     */   public void setAutocomplete(String autocomplete)
/*     */   {
/* 305 */     this.autocomplete = autocomplete;
/*     */   }
/*     */ 
/*     */   protected String getAutocomplete()
/*     */   {
/* 312 */     return this.autocomplete;
/*     */   }
/*     */ 
/*     */   public void setMethodParam(String methodParam)
/*     */   {
/* 319 */     this.methodParam = methodParam;
/*     */   }
/*     */ 
/*     */   protected String getMethodParameter()
/*     */   {
/* 326 */     return this.methodParam;
/*     */   }
/*     */ 
/*     */   protected boolean isMethodBrowserSupported(String method)
/*     */   {
/* 333 */     return ("get".equalsIgnoreCase(method)) || ("post".equalsIgnoreCase(method));
/*     */   }
/*     */ 
/*     */   protected int writeTagContent(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 344 */     this.tagWriter = tagWriter;
/*     */ 
/* 346 */     tagWriter.startTag("form");
/* 347 */     writeDefaultAttributes(tagWriter);
/* 348 */     tagWriter.writeAttribute("action", resolveAction());
/* 349 */     writeOptionalAttribute(tagWriter, "method", getHttpMethod());
/* 350 */     writeOptionalAttribute(tagWriter, "target", getTarget());
/* 351 */     writeOptionalAttribute(tagWriter, "enctype", getEnctype());
/* 352 */     writeOptionalAttribute(tagWriter, "accept-charset", getAcceptCharset());
/* 353 */     writeOptionalAttribute(tagWriter, "onsubmit", getOnsubmit());
/* 354 */     writeOptionalAttribute(tagWriter, "onreset", getOnreset());
/* 355 */     writeOptionalAttribute(tagWriter, "autocomplete", getAutocomplete());
/*     */ 
/* 357 */     tagWriter.forceBlock();
/*     */ 
/* 359 */     if (!isMethodBrowserSupported(getMethod())) {
/* 360 */       assertHttpMethod(getMethod());
/* 361 */       String inputName = getMethodParameter();
/* 362 */       String inputType = "hidden";
/* 363 */       tagWriter.startTag("input");
/* 364 */       writeOptionalAttribute(tagWriter, "type", inputType);
/* 365 */       writeOptionalAttribute(tagWriter, "name", inputName);
/* 366 */       writeOptionalAttribute(tagWriter, "value", processFieldValue(inputName, getMethod(), inputType));
/* 367 */       tagWriter.endTag();
/*     */     }
/*     */ 
/* 371 */     String modelAttribute = resolveModelAttribute();
/* 372 */     this.pageContext.setAttribute(MODEL_ATTRIBUTE_VARIABLE_NAME, modelAttribute, 2);
/*     */ 
/* 376 */     this.previousNestedPath = 
/* 377 */       ((String)this.pageContext
/* 377 */       .getAttribute("nestedPath", 2));
/*     */ 
/* 378 */     this.pageContext.setAttribute("nestedPath", modelAttribute + ".", 2);
/*     */ 
/* 381 */     return 1;
/*     */   }
/*     */ 
/*     */   private String getHttpMethod() {
/* 385 */     return isMethodBrowserSupported(getMethod()) ? getMethod() : "post";
/*     */   }
/*     */ 
/*     */   private void assertHttpMethod(String method) {
/* 389 */     for (HttpMethod httpMethod : HttpMethod.values()) {
/* 390 */       if (httpMethod.name().equalsIgnoreCase(method)) {
/* 391 */         return;
/*     */       }
/*     */     }
/* 394 */     throw new IllegalArgumentException("Invalid HTTP method: " + method);
/*     */   }
/*     */ 
/*     */   protected String autogenerateId()
/*     */     throws JspException
/*     */   {
/* 402 */     return resolveModelAttribute();
/*     */   }
/*     */ 
/*     */   protected String resolveModelAttribute()
/*     */     throws JspException
/*     */   {
/* 410 */     Object resolvedModelAttribute = evaluate("modelAttribute", getModelAttribute());
/* 411 */     if (resolvedModelAttribute == null) {
/* 412 */       throw new IllegalArgumentException("modelAttribute must not be null");
/*     */     }
/* 414 */     return (String)resolvedModelAttribute;
/*     */   }
/*     */ 
/*     */   protected String resolveAction()
/*     */     throws JspException
/*     */   {
/* 429 */     String action = getAction();
/* 430 */     String servletRelativeAction = getServletRelativeAction();
/* 431 */     if (StringUtils.hasText(action)) {
/* 432 */       action = getDisplayString(evaluate("action", action));
/* 433 */       return processAction(action);
/*     */     }
/* 435 */     if (StringUtils.hasText(servletRelativeAction)) {
/* 436 */       String pathToServlet = getRequestContext().getPathToServlet();
/* 437 */       if ((servletRelativeAction.startsWith("/")) && (!servletRelativeAction.startsWith(getRequestContext().getContextPath()))) {
/* 438 */         servletRelativeAction = pathToServlet + servletRelativeAction;
/*     */       }
/* 440 */       servletRelativeAction = getDisplayString(evaluate("action", servletRelativeAction));
/* 441 */       return processAction(servletRelativeAction);
/*     */     }
/*     */ 
/* 444 */     String requestUri = getRequestContext().getRequestUri();
/* 445 */     ServletResponse response = this.pageContext.getResponse();
/* 446 */     if ((response instanceof HttpServletResponse)) {
/* 447 */       requestUri = ((HttpServletResponse)response).encodeURL(requestUri);
/* 448 */       String queryString = getRequestContext().getQueryString();
/* 449 */       if (StringUtils.hasText(queryString)) {
/* 450 */         requestUri = requestUri + "?" + HtmlUtils.htmlEscape(queryString);
/*     */       }
/*     */     }
/* 453 */     if (StringUtils.hasText(requestUri)) {
/* 454 */       return processAction(requestUri);
/*     */     }
/*     */ 
/* 457 */     throw new IllegalArgumentException("Attribute 'action' is required. Attempted to resolve against current request URI but request URI was null.");
/*     */   }
/*     */ 
/*     */   private String processAction(String action)
/*     */   {
/* 468 */     RequestDataValueProcessor processor = getRequestContext().getRequestDataValueProcessor();
/* 469 */     ServletRequest request = this.pageContext.getRequest();
/* 470 */     if ((processor != null) && ((request instanceof HttpServletRequest))) {
/* 471 */       action = processor.processAction((HttpServletRequest)request, action, getHttpMethod());
/*     */     }
/* 473 */     return action;
/*     */   }
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/* 482 */     RequestDataValueProcessor processor = getRequestContext().getRequestDataValueProcessor();
/* 483 */     ServletRequest request = this.pageContext.getRequest();
/* 484 */     if ((processor != null) && ((request instanceof HttpServletRequest))) {
/* 485 */       writeHiddenFields(processor.getExtraHiddenFields((HttpServletRequest)request));
/*     */     }
/* 487 */     this.tagWriter.endTag();
/* 488 */     return 6;
/*     */   }
/*     */ 
/*     */   private void writeHiddenFields(Map<String, String> hiddenFields)
/*     */     throws JspException
/*     */   {
/* 495 */     if (hiddenFields != null) {
/* 496 */       this.tagWriter.appendValue("<div>\n");
/* 497 */       for (String name : hiddenFields.keySet()) {
/* 498 */         this.tagWriter.appendValue("<input type=\"hidden\" ");
/* 499 */         this.tagWriter.appendValue("name=\"" + name + "\" value=\"" + (String)hiddenFields.get(name) + "\" ");
/* 500 */         this.tagWriter.appendValue("/>\n");
/*     */       }
/* 502 */       this.tagWriter.appendValue("</div>");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void doFinally()
/*     */   {
/* 511 */     super.doFinally();
/* 512 */     this.pageContext.removeAttribute(MODEL_ATTRIBUTE_VARIABLE_NAME, 2);
/* 513 */     if (this.previousNestedPath != null)
/*     */     {
/* 515 */       this.pageContext.setAttribute("nestedPath", this.previousNestedPath, 2);
/*     */     }
/*     */     else
/*     */     {
/* 519 */       this.pageContext.removeAttribute("nestedPath", 2);
/*     */     }
/* 521 */     this.tagWriter = null;
/* 522 */     this.previousNestedPath = null;
/*     */   }
/*     */ 
/*     */   protected String resolveCssClass()
/*     */     throws JspException
/*     */   {
/* 531 */     return ObjectUtils.getDisplayString(evaluate("cssClass", getCssClass()));
/*     */   }
/*     */ 
/*     */   public void setPath(String path)
/*     */   {
/* 540 */     throw new UnsupportedOperationException("The 'path' attribute is not supported for forms");
/*     */   }
/*     */ 
/*     */   public void setCssErrorClass(String cssErrorClass)
/*     */   {
/* 549 */     throw new UnsupportedOperationException("The 'cssErrorClass' attribute is not supported for forms");
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.form.FormTag
 * JD-Core Version:    0.6.2
 */