/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class LabelTag extends AbstractHtmlElementTag
/*     */ {
/*     */   private static final String LABEL_TAG = "label";
/*     */   private static final String FOR_ATTRIBUTE = "for";
/*     */   private TagWriter tagWriter;
/*     */   private String forId;
/*     */ 
/*     */   public void setFor(String forId)
/*     */   {
/*  69 */     Assert.notNull(forId, "'forId' must not be null");
/*  70 */     this.forId = forId;
/*     */   }
/*     */ 
/*     */   public String getFor()
/*     */   {
/*  78 */     return this.forId;
/*     */   }
/*     */ 
/*     */   protected int writeTagContent(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/*  89 */     tagWriter.startTag("label");
/*  90 */     tagWriter.writeAttribute("for", resolveFor());
/*  91 */     writeDefaultAttributes(tagWriter);
/*  92 */     tagWriter.forceBlock();
/*  93 */     this.tagWriter = tagWriter;
/*  94 */     return 1;
/*     */   }
/*     */ 
/*     */   protected String getName()
/*     */     throws JspException
/*     */   {
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */   protected String resolveFor()
/*     */     throws JspException
/*     */   {
/* 116 */     if (StringUtils.hasText(this.forId)) {
/* 117 */       return getDisplayString(evaluate("for", this.forId));
/*     */     }
/*     */ 
/* 120 */     return autogenerateFor();
/*     */   }
/*     */ 
/*     */   protected String autogenerateFor()
/*     */     throws JspException
/*     */   {
/* 130 */     return StringUtils.deleteAny(getPropertyPath(), "[]");
/*     */   }
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/* 138 */     this.tagWriter.endTag();
/* 139 */     return 6;
/*     */   }
/*     */ 
/*     */   public void doFinally()
/*     */   {
/* 147 */     super.doFinally();
/* 148 */     this.tagWriter = null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.form.LabelTag
 * JD-Core Version:    0.6.2
 */