/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ import org.springframework.web.util.TagUtils;
/*     */ 
/*     */ public class OptionsTag extends AbstractHtmlElementTag
/*     */ {
/*     */   private Object items;
/*     */   private String itemValue;
/*     */   private String itemLabel;
/*     */   private boolean disabled;
/*     */ 
/*     */   public void setItems(Object items)
/*     */   {
/*  70 */     this.items = items;
/*     */   }
/*     */ 
/*     */   protected Object getItems()
/*     */   {
/*  79 */     return this.items;
/*     */   }
/*     */ 
/*     */   public void setItemValue(String itemValue)
/*     */   {
/*  89 */     Assert.hasText(itemValue, "'itemValue' must not be empty");
/*  90 */     this.itemValue = itemValue;
/*     */   }
/*     */ 
/*     */   protected String getItemValue()
/*     */   {
/*  98 */     return this.itemValue;
/*     */   }
/*     */ 
/*     */   public void setItemLabel(String itemLabel)
/*     */   {
/* 106 */     Assert.hasText(itemLabel, "'itemLabel' must not be empty");
/* 107 */     this.itemLabel = itemLabel;
/*     */   }
/*     */ 
/*     */   protected String getItemLabel()
/*     */   {
/* 115 */     return this.itemLabel;
/*     */   }
/*     */ 
/*     */   public void setDisabled(boolean disabled)
/*     */   {
/* 122 */     this.disabled = disabled;
/*     */   }
/*     */ 
/*     */   protected boolean isDisabled()
/*     */   {
/* 129 */     return this.disabled;
/*     */   }
/*     */ 
/*     */   protected int writeTagContent(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 135 */     SelectTag selectTag = getSelectTag();
/* 136 */     Object items = getItems();
/* 137 */     Object itemsObject = null;
/* 138 */     if (items != null) {
/* 139 */       itemsObject = (items instanceof String) ? evaluate("items", items) : items;
/*     */     } else {
/* 141 */       Class selectTagBoundType = selectTag.getBindStatus().getValueType();
/* 142 */       if ((selectTagBoundType != null) && (selectTagBoundType.isEnum())) {
/* 143 */         itemsObject = selectTagBoundType.getEnumConstants();
/*     */       }
/*     */     }
/* 146 */     if (itemsObject != null) {
/* 147 */       String selectName = selectTag.getName();
/* 148 */       String itemValue = getItemValue();
/* 149 */       String itemLabel = getItemLabel();
/*     */ 
/* 151 */       String valueProperty = itemValue != null ? 
/* 151 */         ObjectUtils.getDisplayString(evaluate("itemValue", itemValue)) : 
/* 151 */         null;
/*     */ 
/* 153 */       String labelProperty = itemLabel != null ? 
/* 153 */         ObjectUtils.getDisplayString(evaluate("itemLabel", itemLabel)) : 
/* 153 */         null;
/* 154 */       OptionsWriter optionWriter = new OptionsWriter(selectName, itemsObject, valueProperty, labelProperty);
/* 155 */       optionWriter.writeOptions(tagWriter);
/*     */     }
/* 157 */     return 0;
/*     */   }
/*     */ 
/*     */   protected String resolveId()
/*     */     throws JspException
/*     */   {
/* 166 */     Object id = evaluate("id", getId());
/* 167 */     if (id != null) {
/* 168 */       String idString = id.toString();
/* 169 */       return StringUtils.hasText(idString) ? TagIdGenerator.nextId(idString, this.pageContext) : null;
/*     */     }
/* 171 */     return null;
/*     */   }
/*     */ 
/*     */   private SelectTag getSelectTag() {
/* 175 */     TagUtils.assertHasAncestorOfType(this, SelectTag.class, "options", "select");
/* 176 */     return (SelectTag)findAncestorWithClass(this, SelectTag.class);
/*     */   }
/*     */ 
/*     */   protected BindStatus getBindStatus()
/*     */   {
/* 181 */     return (BindStatus)this.pageContext.getAttribute("org.springframework.web.servlet.tags.form.SelectTag.listValue");
/*     */   }
/*     */ 
/*     */   private class OptionsWriter extends OptionWriter
/*     */   {
/*     */     private final String selectName;
/*     */ 
/*     */     public OptionsWriter(String selectName, Object optionSource, String valueProperty, String labelProperty)
/*     */     {
/* 193 */       super(OptionsTag.this.getBindStatus(), valueProperty, labelProperty, OptionsTag.this.isHtmlEscape());
/* 194 */       this.selectName = selectName;
/*     */     }
/*     */ 
/*     */     protected boolean isOptionDisabled() throws JspException
/*     */     {
/* 199 */       return OptionsTag.this.isDisabled();
/*     */     }
/*     */ 
/*     */     protected void writeCommonAttributes(TagWriter tagWriter) throws JspException
/*     */     {
/* 204 */       OptionsTag.this.writeOptionalAttribute(tagWriter, "id", OptionsTag.this.resolveId());
/* 205 */       OptionsTag.this.writeOptionalAttributes(tagWriter);
/*     */     }
/*     */ 
/*     */     protected String processOptionValue(String value)
/*     */     {
/* 210 */       return OptionsTag.this.processFieldValue(this.selectName, value, "option");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.form.OptionsTag
 * JD-Core Version:    0.6.2
 */