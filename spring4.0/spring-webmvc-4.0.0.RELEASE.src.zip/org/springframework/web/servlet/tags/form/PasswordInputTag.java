/*    */ package org.springframework.web.servlet.tags.form;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ 
/*    */ public class PasswordInputTag extends InputTag
/*    */ {
/* 33 */   private boolean showPassword = false;
/*    */ 
/*    */   public boolean isShowPassword()
/*    */   {
/* 41 */     return this.showPassword;
/*    */   }
/*    */ 
/*    */   public void setShowPassword(boolean showPassword)
/*    */   {
/* 49 */     this.showPassword = showPassword;
/*    */   }
/*    */ 
/*    */   protected boolean isValidDynamicAttribute(String localName, Object value)
/*    */   {
/* 57 */     return !"type".equals(localName);
/*    */   }
/*    */ 
/*    */   protected String getType()
/*    */   {
/* 66 */     return "password";
/*    */   }
/*    */ 
/*    */   protected void writeValue(TagWriter tagWriter)
/*    */     throws JspException
/*    */   {
/* 76 */     if (this.showPassword)
/* 77 */       super.writeValue(tagWriter);
/*    */     else
/* 79 */       tagWriter.writeAttribute("value", processFieldValue(getName(), "", getType()));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.form.PasswordInputTag
 * JD-Core Version:    0.6.2
 */