/*    */ package org.springframework.web.servlet.tags.form;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ 
/*    */ public class RadioButtonTag extends AbstractSingleCheckedElementTag
/*    */ {
/*    */   protected void writeTagDetails(TagWriter tagWriter)
/*    */     throws JspException
/*    */   {
/* 40 */     tagWriter.writeAttribute("type", getInputType());
/* 41 */     Object resolvedValue = evaluate("value", getValue());
/* 42 */     renderFromValue(resolvedValue, tagWriter);
/*    */   }
/*    */ 
/*    */   protected String getInputType()
/*    */   {
/* 47 */     return "radio";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.form.RadioButtonTag
 * JD-Core Version:    0.6.2
 */