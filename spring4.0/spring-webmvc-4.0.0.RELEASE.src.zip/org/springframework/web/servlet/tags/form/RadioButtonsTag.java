/*    */ package org.springframework.web.servlet.tags.form;
/*    */ 
/*    */ public class RadioButtonsTag extends AbstractMultiCheckedElementTag
/*    */ {
/*    */   protected String getInputType()
/*    */   {
/* 35 */     return "radio";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.form.RadioButtonsTag
 * JD-Core Version:    0.6.2
 */