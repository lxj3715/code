/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Stack;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class TagWriter
/*     */ {
/*     */   private final SafeWriter writer;
/*  48 */   private final Stack<TagStateEntry> tagState = new Stack();
/*     */ 
/*     */   public TagWriter(PageContext pageContext)
/*     */   {
/*  57 */     Assert.notNull(pageContext, "PageContext must not be null");
/*  58 */     this.writer = new SafeWriter(pageContext);
/*     */   }
/*     */ 
/*     */   public TagWriter(Writer writer)
/*     */   {
/*  67 */     Assert.notNull(writer, "Writer must not be null");
/*  68 */     this.writer = new SafeWriter(writer);
/*     */   }
/*     */ 
/*     */   public void startTag(String tagName)
/*     */     throws JspException
/*     */   {
/*  78 */     if (inTag()) {
/*  79 */       closeTagAndMarkAsBlock();
/*     */     }
/*  81 */     push(tagName);
/*  82 */     this.writer.append("<").append(tagName);
/*     */   }
/*     */ 
/*     */   public void writeAttribute(String attributeName, String attributeValue)
/*     */     throws JspException
/*     */   {
/*  92 */     if (currentState().isBlockTag()) {
/*  93 */       throw new IllegalStateException("Cannot write attributes after opening tag is closed.");
/*     */     }
/*  95 */     this.writer.append(" ").append(attributeName).append("=\"")
/*  96 */       .append(attributeValue)
/*  96 */       .append("\"");
/*     */   }
/*     */ 
/*     */   public void writeOptionalAttributeValue(String attributeName, String attributeValue)
/*     */     throws JspException
/*     */   {
/* 105 */     if (StringUtils.hasText(attributeValue))
/* 106 */       writeAttribute(attributeName, attributeValue);
/*     */   }
/*     */ 
/*     */   public void appendValue(String value)
/*     */     throws JspException
/*     */   {
/* 116 */     if (!inTag()) {
/* 117 */       throw new IllegalStateException("Cannot write tag value. No open tag available.");
/*     */     }
/* 119 */     closeTagAndMarkAsBlock();
/* 120 */     this.writer.append(value);
/*     */   }
/*     */ 
/*     */   public void forceBlock()
/*     */     throws JspException
/*     */   {
/* 131 */     if (currentState().isBlockTag()) {
/* 132 */       return;
/*     */     }
/* 134 */     closeTagAndMarkAsBlock();
/*     */   }
/*     */ 
/*     */   public void endTag()
/*     */     throws JspException
/*     */   {
/* 143 */     endTag(false);
/*     */   }
/*     */ 
/*     */   public void endTag(boolean enforceClosingTag)
/*     */     throws JspException
/*     */   {
/* 154 */     if (!inTag()) {
/* 155 */       throw new IllegalStateException("Cannot write end of tag. No open tag available.");
/*     */     }
/* 157 */     boolean renderClosingTag = true;
/* 158 */     if (!currentState().isBlockTag())
/*     */     {
/* 160 */       if (enforceClosingTag) {
/* 161 */         this.writer.append(">");
/*     */       }
/*     */       else {
/* 164 */         this.writer.append("/>");
/* 165 */         renderClosingTag = false;
/*     */       }
/*     */     }
/* 168 */     if (renderClosingTag) {
/* 169 */       this.writer.append("</").append(currentState().getTagName()).append(">");
/*     */     }
/* 171 */     this.tagState.pop();
/*     */   }
/*     */ 
/*     */   private void push(String tagName)
/*     */   {
/* 179 */     this.tagState.push(new TagStateEntry(tagName));
/*     */   }
/*     */ 
/*     */   private void closeTagAndMarkAsBlock()
/*     */     throws JspException
/*     */   {
/* 186 */     if (!currentState().isBlockTag()) {
/* 187 */       currentState().markAsBlockTag();
/* 188 */       this.writer.append(">");
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean inTag() {
/* 193 */     return this.tagState.size() > 0;
/*     */   }
/*     */ 
/*     */   private TagStateEntry currentState() {
/* 197 */     return (TagStateEntry)this.tagState.peek();
/*     */   }
/*     */ 
/*     */   private static final class SafeWriter
/*     */   {
/*     */     private PageContext pageContext;
/*     */     private Writer writer;
/*     */ 
/*     */     public SafeWriter(PageContext pageContext)
/*     */     {
/* 239 */       this.pageContext = pageContext;
/*     */     }
/*     */ 
/*     */     public SafeWriter(Writer writer) {
/* 243 */       this.writer = writer;
/*     */     }
/*     */ 
/*     */     public SafeWriter append(String value) throws JspException {
/*     */       try {
/* 248 */         getWriterToUse().write(String.valueOf(value));
/* 249 */         return this;
/*     */       }
/*     */       catch (IOException ex) {
/* 252 */         throw new JspException("Unable to write to JspWriter", ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     private Writer getWriterToUse() {
/* 257 */       return this.pageContext != null ? this.pageContext.getOut() : this.writer;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TagStateEntry
/*     */   {
/*     */     private final String tagName;
/*     */     private boolean blockTag;
/*     */ 
/*     */     public TagStateEntry(String tagName)
/*     */     {
/* 211 */       this.tagName = tagName;
/*     */     }
/*     */ 
/*     */     public String getTagName() {
/* 215 */       return this.tagName;
/*     */     }
/*     */ 
/*     */     public void markAsBlockTag() {
/* 219 */       this.blockTag = true;
/*     */     }
/*     */ 
/*     */     public boolean isBlockTag() {
/* 223 */       return this.blockTag;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.form.TagWriter
 * JD-Core Version:    0.6.2
 */