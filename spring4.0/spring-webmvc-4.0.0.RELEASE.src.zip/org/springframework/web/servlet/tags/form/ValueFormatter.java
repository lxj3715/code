/*    */ package org.springframework.web.servlet.tags.form;
/*    */ 
/*    */ import java.beans.PropertyEditor;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ import org.springframework.web.util.HtmlUtils;
/*    */ 
/*    */ abstract class ValueFormatter
/*    */ {
/*    */   public static String getDisplayString(Object value, boolean htmlEscape)
/*    */   {
/* 47 */     String displayValue = ObjectUtils.getDisplayString(value);
/* 48 */     return htmlEscape ? HtmlUtils.htmlEscape(displayValue) : displayValue;
/*    */   }
/*    */ 
/*    */   public static String getDisplayString(Object value, PropertyEditor propertyEditor, boolean htmlEscape)
/*    */   {
/* 59 */     if ((propertyEditor != null) && (!(value instanceof String))) {
/*    */       try {
/* 61 */         propertyEditor.setValue(value);
/* 62 */         String text = propertyEditor.getAsText();
/* 63 */         if (text != null) {
/* 64 */           return getDisplayString(text, htmlEscape);
/*    */         }
/*    */       }
/*    */       catch (Throwable ex)
/*    */       {
/*    */       }
/*    */     }
/* 71 */     return getDisplayString(value, htmlEscape);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.tags.form.ValueFormatter
 * JD-Core Version:    0.6.2
 */