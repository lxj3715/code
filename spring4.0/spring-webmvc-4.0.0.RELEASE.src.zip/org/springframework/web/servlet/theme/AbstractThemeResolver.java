/*    */ package org.springframework.web.servlet.theme;
/*    */ 
/*    */ import org.springframework.web.servlet.ThemeResolver;
/*    */ 
/*    */ public abstract class AbstractThemeResolver
/*    */   implements ThemeResolver
/*    */ {
/*    */   public static final String ORIGINAL_DEFAULT_THEME_NAME = "theme";
/* 36 */   private String defaultThemeName = "theme";
/*    */ 
/*    */   public void setDefaultThemeName(String defaultThemeName)
/*    */   {
/* 44 */     this.defaultThemeName = defaultThemeName;
/*    */   }
/*    */ 
/*    */   public String getDefaultThemeName()
/*    */   {
/* 51 */     return this.defaultThemeName;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.theme.AbstractThemeResolver
 * JD-Core Version:    0.6.2
 */