/*    */ package org.springframework.web.servlet.theme;
/*    */ 
/*    */ import javax.servlet.http.Cookie;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.web.servlet.ThemeResolver;
/*    */ import org.springframework.web.util.CookieGenerator;
/*    */ import org.springframework.web.util.WebUtils;
/*    */ 
/*    */ public class CookieThemeResolver extends CookieGenerator
/*    */   implements ThemeResolver
/*    */ {
/*    */   public static final String ORIGINAL_DEFAULT_THEME_NAME = "theme";
/* 51 */   public static final String THEME_REQUEST_ATTRIBUTE_NAME = CookieThemeResolver.class.getName() + ".THEME";
/*    */ 
/* 53 */   public static final String DEFAULT_COOKIE_NAME = CookieThemeResolver.class.getName() + ".THEME";
/*    */ 
/* 56 */   private String defaultThemeName = "theme";
/*    */ 
/*    */   public CookieThemeResolver()
/*    */   {
/* 60 */     setCookieName(DEFAULT_COOKIE_NAME);
/*    */   }
/*    */ 
/*    */   public void setDefaultThemeName(String defaultThemeName)
/*    */   {
/* 68 */     this.defaultThemeName = defaultThemeName;
/*    */   }
/*    */ 
/*    */   public String getDefaultThemeName()
/*    */   {
/* 75 */     return this.defaultThemeName;
/*    */   }
/*    */ 
/*    */   public String resolveThemeName(HttpServletRequest request)
/*    */   {
/* 82 */     String theme = (String)request.getAttribute(THEME_REQUEST_ATTRIBUTE_NAME);
/* 83 */     if (theme != null) {
/* 84 */       return theme;
/*    */     }
/*    */ 
/* 88 */     Cookie cookie = WebUtils.getCookie(request, getCookieName());
/* 89 */     if (cookie != null) {
/* 90 */       return cookie.getValue();
/*    */     }
/*    */ 
/* 94 */     return getDefaultThemeName();
/*    */   }
/*    */ 
/*    */   public void setThemeName(HttpServletRequest request, HttpServletResponse response, String themeName)
/*    */   {
/* 99 */     if (themeName != null)
/*    */     {
/* 101 */       request.setAttribute(THEME_REQUEST_ATTRIBUTE_NAME, themeName);
/* 102 */       addCookie(response, themeName);
/*    */     }
/*    */     else
/*    */     {
/* 107 */       request.setAttribute(THEME_REQUEST_ATTRIBUTE_NAME, getDefaultThemeName());
/* 108 */       removeCookie(response);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.theme.CookieThemeResolver
 * JD-Core Version:    0.6.2
 */