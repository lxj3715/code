/*    */ package org.springframework.web.servlet.theme;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class FixedThemeResolver extends AbstractThemeResolver
/*    */ {
/*    */   public String resolveThemeName(HttpServletRequest request)
/*    */   {
/* 38 */     return getDefaultThemeName();
/*    */   }
/*    */ 
/*    */   public void setThemeName(HttpServletRequest request, HttpServletResponse response, String themeName)
/*    */   {
/* 43 */     throw new UnsupportedOperationException("Cannot change theme - use a different theme resolution strategy");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.theme.FixedThemeResolver
 * JD-Core Version:    0.6.2
 */