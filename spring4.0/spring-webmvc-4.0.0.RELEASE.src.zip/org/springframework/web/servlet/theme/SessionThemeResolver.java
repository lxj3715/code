/*    */ package org.springframework.web.servlet.theme;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.web.util.WebUtils;
/*    */ 
/*    */ public class SessionThemeResolver extends AbstractThemeResolver
/*    */ {
/* 47 */   public static final String THEME_SESSION_ATTRIBUTE_NAME = SessionThemeResolver.class.getName() + ".THEME";
/*    */ 
/*    */   public String resolveThemeName(HttpServletRequest request)
/*    */   {
/* 51 */     String theme = (String)WebUtils.getSessionAttribute(request, THEME_SESSION_ATTRIBUTE_NAME);
/*    */ 
/* 53 */     return theme != null ? theme : getDefaultThemeName();
/*    */   }
/*    */ 
/*    */   public void setThemeName(HttpServletRequest request, HttpServletResponse response, String themeName)
/*    */   {
/* 58 */     WebUtils.setSessionAttribute(request, THEME_SESSION_ATTRIBUTE_NAME, themeName);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.theme.SessionThemeResolver
 * JD-Core Version:    0.6.2
 */