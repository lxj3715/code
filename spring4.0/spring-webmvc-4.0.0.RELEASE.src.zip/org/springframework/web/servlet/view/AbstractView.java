/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ 
/*     */ public abstract class AbstractView extends WebApplicationObjectSupport
/*     */   implements View, BeanNameAware
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "text/html;charset=ISO-8859-1";
/*     */   private static final int OUTPUT_BYTE_ARRAY_INITIAL_SIZE = 4096;
/*     */   private String beanName;
/*  67 */   private String contentType = "text/html;charset=ISO-8859-1";
/*     */   private String requestContextAttribute;
/*  72 */   private final Map<String, Object> staticAttributes = new LinkedHashMap();
/*     */ 
/*  75 */   private boolean exposePathVariables = true;
/*     */ 
/*     */   public void setBeanName(String beanName)
/*     */   {
/*  83 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public String getBeanName()
/*     */   {
/*  91 */     return this.beanName;
/*     */   }
/*     */ 
/*     */   public void setContentType(String contentType)
/*     */   {
/* 101 */     this.contentType = contentType;
/*     */   }
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 109 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   public void setRequestContextAttribute(String requestContextAttribute)
/*     */   {
/* 117 */     this.requestContextAttribute = requestContextAttribute;
/*     */   }
/*     */ 
/*     */   public String getRequestContextAttribute()
/*     */   {
/* 124 */     return this.requestContextAttribute;
/*     */   }
/*     */ 
/*     */   public void setAttributesCSV(String propString)
/*     */     throws IllegalArgumentException
/*     */   {
/* 135 */     if (propString != null) {
/* 136 */       StringTokenizer st = new StringTokenizer(propString, ",");
/* 137 */       while (st.hasMoreTokens()) {
/* 138 */         String tok = st.nextToken();
/* 139 */         int eqIdx = tok.indexOf("=");
/* 140 */         if (eqIdx == -1) {
/* 141 */           throw new IllegalArgumentException(new StringBuilder().append("Expected = in attributes CSV string '").append(propString).append("'").toString());
/*     */         }
/* 143 */         if (eqIdx >= tok.length() - 2) {
/* 144 */           throw new IllegalArgumentException(new StringBuilder().append("At least 2 characters ([]) required in attributes CSV string '").append(propString).append("'").toString());
/*     */         }
/*     */ 
/* 147 */         String name = tok.substring(0, eqIdx);
/* 148 */         String value = tok.substring(eqIdx + 1);
/*     */ 
/* 151 */         value = value.substring(1);
/* 152 */         value = value.substring(0, value.length() - 1);
/*     */ 
/* 154 */         addStaticAttribute(name, value);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setAttributes(Properties attributes)
/*     */   {
/* 173 */     CollectionUtils.mergePropertiesIntoMap(attributes, this.staticAttributes);
/*     */   }
/*     */ 
/*     */   public void setAttributesMap(Map<String, ?> attributes)
/*     */   {
/* 186 */     if (attributes != null)
/* 187 */       for (Map.Entry entry : attributes.entrySet())
/* 188 */         addStaticAttribute((String)entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getAttributesMap()
/*     */   {
/* 201 */     return this.staticAttributes;
/*     */   }
/*     */ 
/*     */   public void addStaticAttribute(String name, Object value)
/*     */   {
/* 215 */     this.staticAttributes.put(name, value);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getStaticAttributes()
/*     */   {
/* 225 */     return Collections.unmodifiableMap(this.staticAttributes);
/*     */   }
/*     */ 
/*     */   public void setExposePathVariables(boolean exposePathVariables)
/*     */   {
/* 240 */     this.exposePathVariables = exposePathVariables;
/*     */   }
/*     */ 
/*     */   public boolean isExposePathVariables()
/*     */   {
/* 247 */     return this.exposePathVariables;
/*     */   }
/*     */ 
/*     */   public void render(Map<String, ?> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 258 */     if (this.logger.isTraceEnabled()) {
/* 259 */       this.logger.trace(new StringBuilder().append("Rendering view with name '").append(this.beanName).append("' with model ").append(model).append(" and static attributes ").append(this.staticAttributes).toString());
/*     */     }
/*     */ 
/* 263 */     Map mergedModel = createMergedOutputModel(model, request, response);
/*     */ 
/* 265 */     prepareResponse(request, response);
/* 266 */     renderMergedOutputModel(mergedModel, request, response);
/*     */   }
/*     */ 
/*     */   protected Map<String, Object> createMergedOutputModel(Map<String, ?> model, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 278 */     Map pathVars = this.exposePathVariables ? 
/* 278 */       (Map)request
/* 278 */       .getAttribute(BeanNameAware.PATH_VARIABLES) : 
/* 278 */       null;
/*     */ 
/* 281 */     int size = this.staticAttributes.size();
/* 282 */     size += (model != null ? model.size() : 0);
/* 283 */     size += (pathVars != null ? pathVars.size() : 0);
/* 284 */     Map mergedModel = new LinkedHashMap(size);
/* 285 */     mergedModel.putAll(this.staticAttributes);
/* 286 */     if (pathVars != null) {
/* 287 */       mergedModel.putAll(pathVars);
/*     */     }
/* 289 */     if (model != null) {
/* 290 */       mergedModel.putAll(model);
/*     */     }
/*     */ 
/* 294 */     if (this.requestContextAttribute != null) {
/* 295 */       mergedModel.put(this.requestContextAttribute, createRequestContext(request, response, mergedModel));
/*     */     }
/*     */ 
/* 298 */     return mergedModel;
/*     */   }
/*     */ 
/*     */   protected RequestContext createRequestContext(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model)
/*     */   {
/* 315 */     return new RequestContext(request, response, getServletContext(), model);
/*     */   }
/*     */ 
/*     */   protected void prepareResponse(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 326 */     if (generatesDownloadContent()) {
/* 327 */       response.setHeader("Pragma", "private");
/* 328 */       response.setHeader("Cache-Control", "private, must-revalidate");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean generatesDownloadContent()
/*     */   {
/* 343 */     return false;
/*     */   }
/*     */ 
/*     */   protected abstract void renderMergedOutputModel(Map<String, Object> paramMap, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*     */     throws Exception;
/*     */ 
/*     */   protected void exposeModelAsRequestAttributes(Map<String, Object> model, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 370 */     for (Map.Entry entry : model.entrySet()) {
/* 371 */       String modelName = (String)entry.getKey();
/* 372 */       Object modelValue = entry.getValue();
/* 373 */       if (modelValue != null) {
/* 374 */         request.setAttribute(modelName, modelValue);
/* 375 */         if (this.logger.isDebugEnabled())
/* 376 */           this.logger.debug(new StringBuilder().append("Added model object '").append(modelName).append("' of type [").append(modelValue.getClass().getName()).append("] to request in view with name '")
/* 377 */             .append(getBeanName()).append("'").toString());
/*     */       }
/*     */       else
/*     */       {
/* 381 */         request.removeAttribute(modelName);
/* 382 */         if (this.logger.isDebugEnabled())
/* 383 */           this.logger.debug(new StringBuilder().append("Removed model object '").append(modelName).append("' from request in view with name '")
/* 384 */             .append(getBeanName()).append("'").toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ByteArrayOutputStream createTemporaryOutputStream()
/*     */   {
/* 396 */     return new ByteArrayOutputStream(4096);
/*     */   }
/*     */ 
/*     */   protected void writeToResponse(HttpServletResponse response, ByteArrayOutputStream baos)
/*     */     throws IOException
/*     */   {
/* 407 */     response.setContentType(getContentType());
/* 408 */     response.setContentLength(baos.size());
/*     */ 
/* 411 */     ServletOutputStream out = response.getOutputStream();
/* 412 */     baos.writeTo(out);
/* 413 */     out.flush();
/*     */   }
/*     */ 
/*     */   protected void setResponseContentType(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 423 */     MediaType mediaType = (MediaType)request.getAttribute(BeanNameAware.SELECTED_CONTENT_TYPE);
/* 424 */     if ((mediaType != null) && (mediaType.isConcrete())) {
/* 425 */       response.setContentType(mediaType.toString());
/*     */     }
/*     */     else
/* 428 */       response.setContentType(getContentType());
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 434 */     StringBuilder sb = new StringBuilder(getClass().getName());
/* 435 */     if (getBeanName() != null) {
/* 436 */       sb.append(": name '").append(getBeanName()).append("'");
/*     */     }
/*     */     else {
/* 439 */       sb.append(": unnamed");
/*     */     }
/* 441 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.AbstractView
 * JD-Core Version:    0.6.2
 */