/*    */ package org.springframework.web.servlet.view;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*    */ import org.springframework.web.servlet.View;
/*    */ import org.springframework.web.servlet.ViewResolver;
/*    */ 
/*    */ public class BeanNameViewResolver extends WebApplicationObjectSupport
/*    */   implements ViewResolver, Ordered
/*    */ {
/* 57 */   private int order = 2147483647;
/*    */ 
/*    */   public void setOrder(int order)
/*    */   {
/* 61 */     this.order = order;
/*    */   }
/*    */ 
/*    */   public int getOrder()
/*    */   {
/* 66 */     return this.order;
/*    */   }
/*    */ 
/*    */   public View resolveViewName(String viewName, Locale locale)
/*    */     throws BeansException
/*    */   {
/* 72 */     ApplicationContext context = getApplicationContext();
/* 73 */     if (!context.containsBean(viewName))
/*    */     {
/* 75 */       return null;
/*    */     }
/* 77 */     return (View)context.getBean(viewName, View.class);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.BeanNameViewResolver
 * JD-Core Version:    0.6.2
 */