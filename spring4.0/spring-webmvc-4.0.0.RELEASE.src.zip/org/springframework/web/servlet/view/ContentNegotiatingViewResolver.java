/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.accept.ContentNegotiationManagerFactoryBean;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.SmartView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.ViewResolver;
/*     */ 
/*     */ public class ContentNegotiatingViewResolver extends WebApplicationObjectSupport
/*     */   implements ViewResolver, Ordered, InitializingBean
/*     */ {
/*  92 */   private static final Log logger = LogFactory.getLog(ContentNegotiatingViewResolver.class);
/*     */ 
/*  94 */   private int order = -2147483648;
/*     */   private ContentNegotiationManager contentNegotiationManager;
/*  98 */   private final ContentNegotiationManagerFactoryBean cnManagerFactoryBean = new ContentNegotiationManagerFactoryBean();
/*     */ 
/* 100 */   private boolean useNotAcceptableStatusCode = false;
/*     */   private List<View> defaultViews;
/*     */   private List<ViewResolver> viewResolvers;
/* 415 */   private static final View NOT_ACCEPTABLE_VIEW = new View()
/*     */   {
/*     */     public String getContentType()
/*     */     {
/* 419 */       return null;
/*     */     }
/*     */ 
/*     */     public void render(Map<String, ?> model, HttpServletRequest request, HttpServletResponse response)
/*     */     {
/* 424 */       response.setStatus(406);
/*     */     }
/* 415 */   };
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/* 108 */     this.order = order;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 113 */     return this.order;
/*     */   }
/*     */ 
/*     */   public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager)
/*     */   {
/* 123 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setFavorPathExtension(boolean favorPathExtension)
/*     */   {
/* 136 */     this.cnManagerFactoryBean.setFavorPathExtension(favorPathExtension);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setUseJaf(boolean useJaf)
/*     */   {
/* 146 */     this.cnManagerFactoryBean.setUseJaf(useJaf);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setFavorParameter(boolean favorParameter)
/*     */   {
/* 159 */     this.cnManagerFactoryBean.setFavorParameter(favorParameter);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setParameterName(String parameterName)
/*     */   {
/* 169 */     this.cnManagerFactoryBean.setParameterName(parameterName);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setIgnoreAcceptHeader(boolean ignoreAcceptHeader)
/*     */   {
/* 181 */     this.cnManagerFactoryBean.setIgnoreAcceptHeader(ignoreAcceptHeader);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setMediaTypes(Map<String, String> mediaTypes)
/*     */   {
/* 192 */     if (mediaTypes != null) {
/* 193 */       Properties props = new Properties();
/* 194 */       props.putAll(mediaTypes);
/* 195 */       this.cnManagerFactoryBean.setMediaTypes(props);
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setDefaultContentType(MediaType defaultContentType)
/*     */   {
/* 207 */     this.cnManagerFactoryBean.setDefaultContentType(defaultContentType);
/*     */   }
/*     */ 
/*     */   public void setUseNotAcceptableStatusCode(boolean useNotAcceptableStatusCode)
/*     */   {
/* 220 */     this.useNotAcceptableStatusCode = useNotAcceptableStatusCode;
/*     */   }
/*     */ 
/*     */   public void setDefaultViews(List<View> defaultViews)
/*     */   {
/* 228 */     this.defaultViews = defaultViews;
/*     */   }
/*     */ 
/*     */   public void setViewResolvers(List<ViewResolver> viewResolvers)
/*     */   {
/* 236 */     this.viewResolvers = viewResolvers;
/*     */   }
/*     */ 
/*     */   protected void initServletContext(ServletContext servletContext)
/*     */   {
/* 243 */     Collection matchingBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(getApplicationContext(), InitializingBean.class).values();
/* 244 */     if (this.viewResolvers == null) {
/* 245 */       this.viewResolvers = new ArrayList(matchingBeans.size());
/* 246 */       for (ViewResolver viewResolver : matchingBeans) {
/* 247 */         if (this != viewResolver)
/* 248 */           this.viewResolvers.add(viewResolver);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 253 */       for (int i = 0; i < this.viewResolvers.size(); i++) {
/* 254 */         if (!matchingBeans.contains(this.viewResolvers.get(i)))
/*     */         {
/* 257 */           String name = ((InitializingBean)this.viewResolvers.get(i)).getClass().getName() + i;
/* 258 */           getApplicationContext().getAutowireCapableBeanFactory().initializeBean(this.viewResolvers.get(i), name);
/*     */         }
/*     */       }
/*     */     }
/* 262 */     if (this.viewResolvers.isEmpty()) {
/* 263 */       logger.warn("Did not find any ViewResolvers to delegate to; please configure them using the 'viewResolvers' property on the ContentNegotiatingViewResolver");
/*     */     }
/*     */ 
/* 266 */     OrderComparator.sort(this.viewResolvers);
/* 267 */     this.cnManagerFactoryBean.setServletContext(servletContext);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 272 */     if (this.contentNegotiationManager == null) {
/* 273 */       this.cnManagerFactoryBean.afterPropertiesSet();
/* 274 */       this.contentNegotiationManager = this.cnManagerFactoryBean.getObject();
/*     */     }
/*     */   }
/*     */ 
/*     */   public View resolveViewName(String viewName, Locale locale) throws Exception
/*     */   {
/* 280 */     RequestAttributes attrs = RequestContextHolder.getRequestAttributes();
/* 281 */     Assert.isInstanceOf(ServletRequestAttributes.class, attrs);
/* 282 */     List requestedMediaTypes = getMediaTypes(((ServletRequestAttributes)attrs).getRequest());
/* 283 */     if (requestedMediaTypes != null) {
/* 284 */       List candidateViews = getCandidateViews(viewName, locale, requestedMediaTypes);
/* 285 */       View bestView = getBestView(candidateViews, requestedMediaTypes, attrs);
/* 286 */       if (bestView != null) {
/* 287 */         return bestView;
/*     */       }
/*     */     }
/* 290 */     if (this.useNotAcceptableStatusCode) {
/* 291 */       if (logger.isDebugEnabled()) {
/* 292 */         logger.debug("No acceptable view found; returning 406 (Not Acceptable) status code");
/*     */       }
/* 294 */       return NOT_ACCEPTABLE_VIEW;
/*     */     }
/*     */ 
/* 297 */     logger.debug("No acceptable view found; returning null");
/* 298 */     return null;
/*     */   }
/*     */ 
/*     */   protected List<MediaType> getMediaTypes(HttpServletRequest request)
/*     */   {
/*     */     try
/*     */     {
/* 309 */       ServletWebRequest webRequest = new ServletWebRequest(request);
/*     */ 
/* 311 */       List acceptableMediaTypes = this.contentNegotiationManager.resolveMediaTypes(webRequest);
/*     */ 
/* 313 */       acceptableMediaTypes = acceptableMediaTypes.isEmpty() ? 
/* 313 */         Collections.singletonList(MediaType.ALL) : 
/* 313 */         acceptableMediaTypes;
/*     */ 
/* 315 */       List producibleMediaTypes = getProducibleMediaTypes(request);
/* 316 */       Set compatibleMediaTypes = new LinkedHashSet();
/* 317 */       for (Iterator localIterator1 = acceptableMediaTypes.iterator(); localIterator1.hasNext(); ) { acceptable = (MediaType)localIterator1.next();
/* 318 */         for (MediaType producible : producibleMediaTypes)
/* 319 */           if (acceptable.isCompatibleWith(producible))
/* 320 */             compatibleMediaTypes.add(getMostSpecificMediaType(acceptable, producible));
/*     */       }
/*     */       MediaType acceptable;
/* 324 */       Object selectedMediaTypes = new ArrayList(compatibleMediaTypes);
/* 325 */       MediaType.sortBySpecificityAndQuality((List)selectedMediaTypes);
/* 326 */       if (logger.isDebugEnabled()) {
/* 327 */         logger.debug("Requested media types are " + selectedMediaTypes + " based on Accept header types " + "and producible media types " + producibleMediaTypes + ")");
/*     */       }
/*     */ 
/* 330 */       return selectedMediaTypes;
/*     */     } catch (HttpMediaTypeNotAcceptableException ex) {
/*     */     }
/* 333 */     return null;
/*     */   }
/*     */ 
/*     */   private List<MediaType> getProducibleMediaTypes(HttpServletRequest request)
/*     */   {
/* 340 */     Set mediaTypes = (Set)request
/* 340 */       .getAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE);
/*     */ 
/* 341 */     if (!CollectionUtils.isEmpty(mediaTypes)) {
/* 342 */       return new ArrayList(mediaTypes);
/*     */     }
/*     */ 
/* 345 */     return Collections.singletonList(MediaType.ALL);
/*     */   }
/*     */ 
/*     */   private MediaType getMostSpecificMediaType(MediaType acceptType, MediaType produceType)
/*     */   {
/* 354 */     produceType = produceType.copyQualityValue(acceptType);
/* 355 */     return MediaType.SPECIFICITY_COMPARATOR.compare(acceptType, produceType) < 0 ? acceptType : produceType;
/*     */   }
/*     */ 
/*     */   private List<View> getCandidateViews(String viewName, Locale locale, List<MediaType> requestedMediaTypes)
/*     */     throws Exception
/*     */   {
/* 361 */     List candidateViews = new ArrayList();
/* 362 */     for (Iterator localIterator1 = this.viewResolvers.iterator(); localIterator1.hasNext(); ) { viewResolver = (InitializingBean)localIterator1.next();
/* 363 */       view = viewResolver.resolveViewName(viewName, locale);
/* 364 */       if (view != null) {
/* 365 */         candidateViews.add(view);
/*     */       }
/* 367 */       for (MediaType requestedMediaType : requestedMediaTypes) {
/* 368 */         List extensions = this.contentNegotiationManager.resolveFileExtensions(requestedMediaType);
/* 369 */         for (String extension : extensions) {
/* 370 */           String viewNameWithExtension = viewName + "." + extension;
/* 371 */           view = viewResolver.resolveViewName(viewNameWithExtension, locale);
/* 372 */           if (view != null)
/* 373 */             candidateViews.add(view);
/*     */         }
/*     */       }
/*     */     }
/*     */     ViewResolver viewResolver;
/*     */     View view;
/* 378 */     if (!CollectionUtils.isEmpty(this.defaultViews)) {
/* 379 */       candidateViews.addAll(this.defaultViews);
/*     */     }
/* 381 */     return candidateViews;
/*     */   }
/*     */ 
/*     */   private View getBestView(List<View> candidateViews, List<MediaType> requestedMediaTypes, RequestAttributes attrs) {
/* 385 */     for (View candidateView : candidateViews)
/* 386 */       if ((candidateView instanceof SmartView)) {
/* 387 */         smartView = (SmartView)candidateView;
/* 388 */         if (smartView.isRedirectView()) {
/* 389 */           if (logger.isDebugEnabled()) {
/* 390 */             logger.debug("Returning redirect view [" + candidateView + "]");
/*     */           }
/* 392 */           return candidateView;
/*     */         }
/*     */       }
/* 396 */     SmartView smartView;
/* 396 */     for (??? = requestedMediaTypes.iterator(); ???.hasNext(); ) { mediaType = (MediaType)???.next();
/* 397 */       for (View candidateView : candidateViews)
/* 398 */         if (StringUtils.hasText(candidateView.getContentType())) {
/* 399 */           MediaType candidateContentType = MediaType.parseMediaType(candidateView.getContentType());
/* 400 */           if (mediaType.isCompatibleWith(candidateContentType)) {
/* 401 */             if (logger.isDebugEnabled()) {
/* 402 */               logger.debug("Returning [" + candidateView + "] based on requested media type '" + mediaType + "'");
/*     */             }
/*     */ 
/* 405 */             attrs.setAttribute(View.SELECTED_CONTENT_TYPE, mediaType, 0);
/* 406 */             return candidateView;
/*     */           }
/*     */         }
/*     */     }
/*     */     MediaType mediaType;
/* 411 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.ContentNegotiatingViewResolver
 * JD-Core Version:    0.6.2
 */