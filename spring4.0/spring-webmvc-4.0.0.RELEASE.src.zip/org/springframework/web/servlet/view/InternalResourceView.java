/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.support.ContextExposingHttpServletRequest;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class InternalResourceView extends AbstractUrlBasedView
/*     */ {
/*  69 */   private boolean alwaysInclude = false;
/*     */ 
/*  71 */   private boolean exposeContextBeansAsAttributes = false;
/*     */   private Set<String> exposedContextBeanNames;
/*  75 */   private boolean preventDispatchLoop = false;
/*     */ 
/*     */   public InternalResourceView()
/*     */   {
/*     */   }
/*     */ 
/*     */   public InternalResourceView(String url)
/*     */   {
/*  92 */     super(url);
/*     */   }
/*     */ 
/*     */   public InternalResourceView(String url, boolean alwaysInclude)
/*     */   {
/* 101 */     super(url);
/* 102 */     this.alwaysInclude = alwaysInclude;
/*     */   }
/*     */ 
/*     */   public void setAlwaysInclude(boolean alwaysInclude)
/*     */   {
/* 115 */     this.alwaysInclude = alwaysInclude;
/*     */   }
/*     */ 
/*     */   public void setExposeContextBeansAsAttributes(boolean exposeContextBeansAsAttributes)
/*     */   {
/* 133 */     this.exposeContextBeansAsAttributes = exposeContextBeansAsAttributes;
/*     */   }
/*     */ 
/*     */   public void setExposedContextBeanNames(String[] exposedContextBeanNames)
/*     */   {
/* 145 */     this.exposedContextBeanNames = new HashSet(Arrays.asList(exposedContextBeanNames));
/*     */   }
/*     */ 
/*     */   public void setPreventDispatchLoop(boolean preventDispatchLoop)
/*     */   {
/* 156 */     this.preventDispatchLoop = preventDispatchLoop;
/*     */   }
/*     */ 
/*     */   protected boolean isContextRequired()
/*     */   {
/* 164 */     return false;
/*     */   }
/*     */ 
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 177 */     HttpServletRequest requestToExpose = getRequestToExpose(request);
/*     */ 
/* 180 */     exposeModelAsRequestAttributes(model, requestToExpose);
/*     */ 
/* 183 */     exposeHelpers(requestToExpose);
/*     */ 
/* 186 */     String dispatcherPath = prepareForRendering(requestToExpose, response);
/*     */ 
/* 189 */     RequestDispatcher rd = getRequestDispatcher(requestToExpose, dispatcherPath);
/* 190 */     if (rd == null) {
/* 191 */       throw new ServletException("Could not get RequestDispatcher for [" + getUrl() + "]: Check that the corresponding file exists within your web application archive!");
/*     */     }
/*     */ 
/* 196 */     if (useInclude(requestToExpose, response)) {
/* 197 */       response.setContentType(getContentType());
/* 198 */       if (this.logger.isDebugEnabled()) {
/* 199 */         this.logger.debug("Including resource [" + getUrl() + "] in InternalResourceView '" + getBeanName() + "'");
/*     */       }
/* 201 */       rd.include(requestToExpose, response);
/*     */     }
/*     */     else
/*     */     {
/* 206 */       if (this.logger.isDebugEnabled()) {
/* 207 */         this.logger.debug("Forwarding to resource [" + getUrl() + "] in InternalResourceView '" + getBeanName() + "'");
/*     */       }
/* 209 */       rd.forward(requestToExpose, response);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected HttpServletRequest getRequestToExpose(HttpServletRequest originalRequest)
/*     */   {
/* 223 */     if ((this.exposeContextBeansAsAttributes) || (this.exposedContextBeanNames != null))
/*     */     {
/* 225 */       return new ContextExposingHttpServletRequest(originalRequest, 
/* 225 */         getWebApplicationContext(), this.exposedContextBeanNames);
/*     */     }
/* 227 */     return originalRequest;
/*     */   }
/*     */ 
/*     */   protected void exposeHelpers(HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   protected String prepareForRendering(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 259 */     String path = getUrl();
/* 260 */     if (this.preventDispatchLoop) {
/* 261 */       String uri = request.getRequestURI();
/* 262 */       if (path.startsWith("/") ? uri.equals(path) : uri.equals(StringUtils.applyRelativePath(uri, path))) {
/* 263 */         throw new ServletException("Circular view path [" + path + "]: would dispatch back " + "to the current handler URL [" + uri + "] again. Check your ViewResolver setup! " + "(Hint: This may be the result of an unspecified view, due to default view name generation.)");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 268 */     return path;
/*     */   }
/*     */ 
/*     */   protected RequestDispatcher getRequestDispatcher(HttpServletRequest request, String path)
/*     */   {
/* 281 */     return request.getRequestDispatcher(path);
/*     */   }
/*     */ 
/*     */   protected boolean useInclude(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 299 */     return (this.alwaysInclude) || (WebUtils.isIncludeRequest(request)) || (response.isCommitted());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.InternalResourceView
 * JD-Core Version:    0.6.2
 */