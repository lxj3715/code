/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class InternalResourceViewResolver extends UrlBasedViewResolver
/*     */ {
/*  50 */   private static final boolean jstlPresent = ClassUtils.isPresent("javax.servlet.jsp.jstl.core.Config", InternalResourceViewResolver.class
/*  51 */     .getClassLoader());
/*     */   private Boolean alwaysInclude;
/*     */   private Boolean exposeContextBeansAsAttributes;
/*     */   private String[] exposedContextBeanNames;
/*     */ 
/*     */   public InternalResourceViewResolver()
/*     */   {
/*  66 */     Class viewClass = requiredViewClass();
/*  67 */     if ((viewClass.equals(InternalResourceView.class)) && (jstlPresent)) {
/*  68 */       viewClass = JstlView.class;
/*     */     }
/*  70 */     setViewClass(viewClass);
/*     */   }
/*     */ 
/*     */   protected Class<?> requiredViewClass()
/*     */   {
/*  78 */     return InternalResourceView.class;
/*     */   }
/*     */ 
/*     */   public void setAlwaysInclude(boolean alwaysInclude)
/*     */   {
/*  89 */     this.alwaysInclude = Boolean.valueOf(alwaysInclude);
/*     */   }
/*     */ 
/*     */   public void setExposeContextBeansAsAttributes(boolean exposeContextBeansAsAttributes)
/*     */   {
/* 102 */     this.exposeContextBeansAsAttributes = Boolean.valueOf(exposeContextBeansAsAttributes);
/*     */   }
/*     */ 
/*     */   public void setExposedContextBeanNames(String[] exposedContextBeanNames)
/*     */   {
/* 112 */     this.exposedContextBeanNames = exposedContextBeanNames;
/*     */   }
/*     */ 
/*     */   protected AbstractUrlBasedView buildView(String viewName)
/*     */     throws Exception
/*     */   {
/* 118 */     InternalResourceView view = (InternalResourceView)super.buildView(viewName);
/* 119 */     if (this.alwaysInclude != null) {
/* 120 */       view.setAlwaysInclude(this.alwaysInclude.booleanValue());
/*     */     }
/* 122 */     if (this.exposeContextBeansAsAttributes != null) {
/* 123 */       view.setExposeContextBeansAsAttributes(this.exposeContextBeansAsAttributes.booleanValue());
/*     */     }
/* 125 */     if (this.exposedContextBeanNames != null) {
/* 126 */       view.setExposedContextBeanNames(this.exposedContextBeanNames);
/*     */     }
/* 128 */     view.setPreventDispatchLoop(true);
/* 129 */     return view;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.InternalResourceViewResolver
 * JD-Core Version:    0.6.2
 */