/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.web.servlet.support.JstlUtils;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ 
/*     */ public class JstlView extends InternalResourceView
/*     */ {
/*     */   private MessageSource messageSource;
/*     */ 
/*     */   public JstlView()
/*     */   {
/*     */   }
/*     */ 
/*     */   public JstlView(String url)
/*     */   {
/*  94 */     super(url);
/*     */   }
/*     */ 
/*     */   public JstlView(String url, MessageSource messageSource)
/*     */   {
/* 106 */     this(url);
/* 107 */     this.messageSource = messageSource;
/*     */   }
/*     */ 
/*     */   protected void initServletContext(ServletContext servletContext)
/*     */   {
/* 119 */     if (this.messageSource != null) {
/* 120 */       this.messageSource = JstlUtils.getJstlAwareMessageSource(servletContext, this.messageSource);
/*     */     }
/* 122 */     super.initServletContext(servletContext);
/*     */   }
/*     */ 
/*     */   protected void exposeHelpers(HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 131 */     if (this.messageSource != null) {
/* 132 */       JstlUtils.exposeLocalizationContext(request, this.messageSource);
/*     */     }
/*     */     else
/* 135 */       JstlUtils.exposeLocalizationContext(new RequestContext(request, getServletContext()));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.JstlView
 * JD-Core Version:    0.6.2
 */