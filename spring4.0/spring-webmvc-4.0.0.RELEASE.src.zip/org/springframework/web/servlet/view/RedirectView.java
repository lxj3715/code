/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.ContextLoader;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.servlet.FlashMap;
/*     */ import org.springframework.web.servlet.FlashMapManager;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.SmartView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ import org.springframework.web.servlet.support.RequestDataValueProcessor;
/*     */ import org.springframework.web.util.UriComponents;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import org.springframework.web.util.UriUtils;
/*     */ 
/*     */ public class RedirectView extends AbstractUrlBasedView
/*     */   implements SmartView
/*     */ {
/*  93 */   private static final Pattern URI_TEMPLATE_VARIABLE_PATTERN = Pattern.compile("\\{([^/]+?)\\}");
/*     */ 
/*  96 */   private boolean contextRelative = false;
/*     */ 
/*  98 */   private boolean http10Compatible = true;
/*     */ 
/* 100 */   private boolean exposeModelAttributes = true;
/*     */   private String encodingScheme;
/*     */   private HttpStatus statusCode;
/* 106 */   private boolean expandUriTemplateVariables = true;
/*     */ 
/*     */   public RedirectView()
/*     */   {
/* 113 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */   public RedirectView(String url)
/*     */   {
/* 124 */     super(url);
/* 125 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */   public RedirectView(String url, boolean contextRelative)
/*     */   {
/* 135 */     super(url);
/* 136 */     this.contextRelative = contextRelative;
/* 137 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */   public RedirectView(String url, boolean contextRelative, boolean http10Compatible)
/*     */   {
/* 148 */     super(url);
/* 149 */     this.contextRelative = contextRelative;
/* 150 */     this.http10Compatible = http10Compatible;
/* 151 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */   public RedirectView(String url, boolean contextRelative, boolean http10Compatible, boolean exposeModelAttributes)
/*     */   {
/* 164 */     super(url);
/* 165 */     this.contextRelative = contextRelative;
/* 166 */     this.http10Compatible = http10Compatible;
/* 167 */     this.exposeModelAttributes = exposeModelAttributes;
/* 168 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */   public void setContextRelative(boolean contextRelative)
/*     */   {
/* 182 */     this.contextRelative = contextRelative;
/*     */   }
/*     */ 
/*     */   public void setHttp10Compatible(boolean http10Compatible)
/*     */   {
/* 197 */     this.http10Compatible = http10Compatible;
/*     */   }
/*     */ 
/*     */   public void setExposeModelAttributes(boolean exposeModelAttributes)
/*     */   {
/* 206 */     this.exposeModelAttributes = exposeModelAttributes;
/*     */   }
/*     */ 
/*     */   public void setEncodingScheme(String encodingScheme)
/*     */   {
/* 215 */     this.encodingScheme = encodingScheme;
/*     */   }
/*     */ 
/*     */   public void setStatusCode(HttpStatus statusCode)
/*     */   {
/* 224 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public void setExpandUriTemplateVariables(boolean expandUriTemplateVariables)
/*     */   {
/* 235 */     this.expandUriTemplateVariables = expandUriTemplateVariables;
/*     */   }
/*     */ 
/*     */   public boolean isRedirectView()
/*     */   {
/* 243 */     return true;
/*     */   }
/*     */ 
/*     */   protected boolean isContextRequired()
/*     */   {
/* 251 */     return false;
/*     */   }
/*     */ 
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/* 264 */     String targetUrl = createTargetUrl(model, request);
/* 265 */     targetUrl = updateTargetUrl(targetUrl, model, request, response);
/*     */ 
/* 267 */     FlashMap flashMap = RequestContextUtils.getOutputFlashMap(request);
/* 268 */     if (!CollectionUtils.isEmpty(flashMap)) {
/* 269 */       UriComponents uriComponents = UriComponentsBuilder.fromUriString(targetUrl).build();
/* 270 */       flashMap.setTargetRequestPath(uriComponents.getPath());
/* 271 */       flashMap.addTargetRequestParams(uriComponents.getQueryParams());
/* 272 */       FlashMapManager flashMapManager = RequestContextUtils.getFlashMapManager(request);
/* 273 */       if (flashMapManager == null) {
/* 274 */         throw new IllegalStateException("FlashMapManager not found despite output FlashMap having been set");
/*     */       }
/* 276 */       flashMapManager.saveOutputFlashMap(flashMap, request, response);
/*     */     }
/*     */ 
/* 279 */     sendRedirect(request, response, targetUrl, this.http10Compatible);
/*     */   }
/*     */ 
/*     */   protected final String createTargetUrl(Map<String, Object> model, HttpServletRequest request)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 291 */     StringBuilder targetUrl = new StringBuilder();
/* 292 */     if ((this.contextRelative) && (getUrl().startsWith("/")))
/*     */     {
/* 294 */       targetUrl.append(request.getContextPath());
/*     */     }
/* 296 */     targetUrl.append(getUrl());
/*     */ 
/* 298 */     String enc = this.encodingScheme;
/* 299 */     if (enc == null) {
/* 300 */       enc = request.getCharacterEncoding();
/*     */     }
/* 302 */     if (enc == null) {
/* 303 */       enc = "ISO-8859-1";
/*     */     }
/*     */ 
/* 306 */     if ((this.expandUriTemplateVariables) && (StringUtils.hasText(targetUrl))) {
/* 307 */       Map variables = getCurrentRequestUriVariables(request);
/* 308 */       targetUrl = replaceUriTemplateVariables(targetUrl.toString(), model, variables, enc);
/*     */     }
/* 310 */     if (this.exposeModelAttributes) {
/* 311 */       appendQueryProperties(targetUrl, model, enc);
/*     */     }
/*     */ 
/* 314 */     return targetUrl.toString();
/*     */   }
/*     */ 
/*     */   protected StringBuilder replaceUriTemplateVariables(String targetUrl, Map<String, Object> model, Map<String, String> currentUriVariables, String encodingScheme)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 331 */     StringBuilder result = new StringBuilder();
/* 332 */     Matcher matcher = URI_TEMPLATE_VARIABLE_PATTERN.matcher(targetUrl);
/* 333 */     int endLastMatch = 0;
/* 334 */     while (matcher.find()) {
/* 335 */       String name = matcher.group(1);
/* 336 */       Object value = model.containsKey(name) ? model.remove(name) : currentUriVariables.get(name);
/* 337 */       if (value == null) {
/* 338 */         throw new IllegalArgumentException(new StringBuilder().append("Model has no value for key '").append(name).append("'").toString());
/*     */       }
/* 340 */       result.append(targetUrl.substring(endLastMatch, matcher.start()));
/* 341 */       result.append(UriUtils.encodePathSegment(value.toString(), encodingScheme));
/* 342 */       endLastMatch = matcher.end();
/*     */     }
/* 344 */     result.append(targetUrl.substring(endLastMatch, targetUrl.length()));
/* 345 */     return result;
/*     */   }
/*     */ 
/*     */   private Map<String, String> getCurrentRequestUriVariables(HttpServletRequest request)
/*     */   {
/* 351 */     Map uriVars = (Map)request
/* 351 */       .getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
/*     */ 
/* 352 */     return uriVars != null ? uriVars : Collections.emptyMap();
/*     */   }
/*     */ 
/*     */   protected void appendQueryProperties(StringBuilder targetUrl, Map<String, Object> model, String encodingScheme)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 369 */     String fragment = null;
/* 370 */     int anchorIndex = targetUrl.indexOf("#");
/* 371 */     if (anchorIndex > -1) {
/* 372 */       fragment = targetUrl.substring(anchorIndex);
/* 373 */       targetUrl.delete(anchorIndex, targetUrl.length());
/*     */     }
/*     */ 
/* 377 */     boolean first = targetUrl.toString().indexOf(63) < 0;
/* 378 */     for (Map.Entry entry : queryProperties(model).entrySet()) {
/* 379 */       Object rawValue = entry.getValue();
/*     */       Iterator valueIter;
/*     */       Iterator valueIter;
/* 381 */       if ((rawValue != null) && (rawValue.getClass().isArray())) {
/* 382 */         valueIter = Arrays.asList(ObjectUtils.toObjectArray(rawValue)).iterator();
/*     */       }
/*     */       else
/*     */       {
/*     */         Iterator valueIter;
/* 384 */         if ((rawValue instanceof Collection)) {
/* 385 */           valueIter = ((Collection)rawValue).iterator();
/*     */         }
/*     */         else
/* 388 */           valueIter = Collections.singleton(rawValue).iterator();
/*     */       }
/* 390 */       while (valueIter.hasNext()) {
/* 391 */         Object value = valueIter.next();
/* 392 */         if (first) {
/* 393 */           targetUrl.append('?');
/* 394 */           first = false;
/*     */         }
/*     */         else {
/* 397 */           targetUrl.append('&');
/*     */         }
/* 399 */         String encodedKey = urlEncode((String)entry.getKey(), encodingScheme);
/* 400 */         String encodedValue = value != null ? urlEncode(value.toString(), encodingScheme) : "";
/* 401 */         targetUrl.append(encodedKey).append('=').append(encodedValue);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 406 */     if (fragment != null)
/* 407 */       targetUrl.append(fragment);
/*     */   }
/*     */ 
/*     */   protected Map<String, Object> queryProperties(Map<String, Object> model)
/*     */   {
/* 422 */     Map result = new LinkedHashMap();
/* 423 */     for (Map.Entry entry : model.entrySet()) {
/* 424 */       if (isEligibleProperty((String)entry.getKey(), entry.getValue())) {
/* 425 */         result.put(entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/* 428 */     return result;
/*     */   }
/*     */ 
/*     */   protected boolean isEligibleProperty(String key, Object value)
/*     */   {
/* 442 */     if (value == null) {
/* 443 */       return false;
/*     */     }
/* 445 */     if (isEligibleValue(value))
/* 446 */       return true;
/*     */     int i;
/* 448 */     if (value.getClass().isArray()) {
/* 449 */       int length = Array.getLength(value);
/* 450 */       if (length == 0) {
/* 451 */         return false;
/*     */       }
/* 453 */       for (i = 0; i < length; i++) {
/* 454 */         Object element = Array.get(value, i);
/* 455 */         if (!isEligibleValue(element)) {
/* 456 */           return false;
/*     */         }
/*     */       }
/* 459 */       return true;
/*     */     }
/* 461 */     if ((value instanceof Collection)) {
/* 462 */       Collection coll = (Collection)value;
/* 463 */       if (coll.isEmpty()) {
/* 464 */         return false;
/*     */       }
/* 466 */       for (i = coll.iterator(); i.hasNext(); ) { Object element = i.next();
/* 467 */         if (!isEligibleValue(element)) {
/* 468 */           return false;
/*     */         }
/*     */       }
/* 471 */       return true;
/*     */     }
/* 473 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean isEligibleValue(Object value)
/*     */   {
/* 485 */     return (value != null) && (BeanUtils.isSimpleValueType(value.getClass()));
/*     */   }
/*     */ 
/*     */   protected String urlEncode(String input, String encodingScheme)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 499 */     return input != null ? URLEncoder.encode(input, encodingScheme) : null;
/*     */   }
/*     */ 
/*     */   protected String updateTargetUrl(String targetUrl, Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 510 */     RequestContext requestContext = null;
/* 511 */     if (getWebApplicationContext() != null) {
/* 512 */       requestContext = createRequestContext(request, response, model);
/*     */     }
/*     */     else {
/* 515 */       WebApplicationContext wac = ContextLoader.getCurrentWebApplicationContext();
/* 516 */       if ((wac != null) && (wac.getServletContext() != null)) {
/* 517 */         requestContext = new RequestContext(request, response, wac.getServletContext(), model);
/*     */       }
/*     */     }
/* 520 */     if (requestContext != null) {
/* 521 */       RequestDataValueProcessor processor = requestContext.getRequestDataValueProcessor();
/* 522 */       if (processor != null) {
/* 523 */         targetUrl = processor.processUrl(request, targetUrl);
/*     */       }
/*     */     }
/* 526 */     return targetUrl;
/*     */   }
/*     */ 
/*     */   protected void sendRedirect(HttpServletRequest request, HttpServletResponse response, String targetUrl, boolean http10Compatible)
/*     */     throws IOException
/*     */   {
/* 540 */     String encodedRedirectURL = response.encodeRedirectURL(targetUrl);
/* 541 */     if (http10Compatible) {
/* 542 */       if (this.statusCode != null) {
/* 543 */         response.setStatus(this.statusCode.value());
/* 544 */         response.setHeader("Location", encodedRedirectURL);
/*     */       }
/*     */       else
/*     */       {
/* 548 */         response.sendRedirect(encodedRedirectURL);
/*     */       }
/*     */     }
/*     */     else {
/* 552 */       HttpStatus statusCode = getHttp11StatusCode(request, response, targetUrl);
/* 553 */       response.setStatus(statusCode.value());
/* 554 */       response.setHeader("Location", encodedRedirectURL);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected HttpStatus getHttp11StatusCode(HttpServletRequest request, HttpServletResponse response, String targetUrl)
/*     */   {
/* 571 */     if (this.statusCode != null) {
/* 572 */       return this.statusCode;
/*     */     }
/* 574 */     HttpStatus attributeStatusCode = (HttpStatus)request.getAttribute(View.RESPONSE_STATUS_ATTRIBUTE);
/* 575 */     if (attributeStatusCode != null) {
/* 576 */       return attributeStatusCode;
/*     */     }
/* 578 */     return HttpStatus.SEE_OTHER;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.RedirectView
 * JD-Core Version:    0.6.2
 */