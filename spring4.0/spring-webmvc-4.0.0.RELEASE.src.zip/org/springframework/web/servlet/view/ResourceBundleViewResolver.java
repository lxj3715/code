/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.support.PropertiesBeanDefinitionReader;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.web.context.support.GenericWebApplicationContext;
/*     */ import org.springframework.web.servlet.View;
/*     */ 
/*     */ public class ResourceBundleViewResolver extends AbstractCachingViewResolver
/*     */   implements Ordered, InitializingBean, DisposableBean
/*     */ {
/*     */   public static final String DEFAULT_BASENAME = "views";
/*  71 */   private int order = 2147483647;
/*     */ 
/*  73 */   private String[] basenames = { "views" };
/*     */ 
/*  75 */   private ClassLoader bundleClassLoader = Thread.currentThread().getContextClassLoader();
/*     */   private String defaultParentView;
/*     */   private Locale[] localesToInitialize;
/*  82 */   private final Map<Locale, BeanFactory> localeCache = new HashMap();
/*     */ 
/*  86 */   private final Map<List<ResourceBundle>, ConfigurableApplicationContext> bundleCache = new HashMap();
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/*  91 */     this.order = order;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/*  96 */     return this.order;
/*     */   }
/*     */ 
/*     */   public void setBasename(String basename)
/*     */   {
/* 113 */     setBasenames(new String[] { basename });
/*     */   }
/*     */ 
/*     */   public void setBasenames(String[] basenames)
/*     */   {
/* 134 */     this.basenames = basenames;
/*     */   }
/*     */ 
/*     */   public void setBundleClassLoader(ClassLoader classLoader)
/*     */   {
/* 142 */     this.bundleClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   protected ClassLoader getBundleClassLoader()
/*     */   {
/* 151 */     return this.bundleClassLoader;
/*     */   }
/*     */ 
/*     */   public void setDefaultParentView(String defaultParentView)
/*     */   {
/* 168 */     this.defaultParentView = defaultParentView;
/*     */   }
/*     */ 
/*     */   public void setLocalesToInitialize(Locale[] localesToInitialize)
/*     */   {
/* 177 */     this.localesToInitialize = localesToInitialize;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws BeansException
/*     */   {
/* 186 */     if (this.localesToInitialize != null)
/* 187 */       for (Locale locale : this.localesToInitialize)
/* 188 */         initFactory(locale);
/*     */   }
/*     */ 
/*     */   protected View loadView(String viewName, Locale locale)
/*     */     throws Exception
/*     */   {
/* 196 */     BeanFactory factory = initFactory(locale);
/*     */     try {
/* 198 */       return (View)factory.getBean(viewName, View.class);
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {
/*     */     }
/* 202 */     return null;
/*     */   }
/*     */ 
/*     */   protected synchronized BeanFactory initFactory(Locale locale)
/*     */     throws BeansException
/*     */   {
/* 217 */     if (isCache()) {
/* 218 */       BeanFactory cachedFactory = (BeanFactory)this.localeCache.get(locale);
/* 219 */       if (cachedFactory != null) {
/* 220 */         return cachedFactory;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 225 */     List bundles = new LinkedList();
/* 226 */     for (String basename : this.basenames) {
/* 227 */       ResourceBundle bundle = getBundle(basename, locale);
/* 228 */       bundles.add(bundle);
/*     */     }
/*     */ 
/* 233 */     if (isCache()) {
/* 234 */       BeanFactory cachedFactory = (BeanFactory)this.bundleCache.get(bundles);
/* 235 */       if (cachedFactory != null) {
/* 236 */         this.localeCache.put(locale, cachedFactory);
/* 237 */         return cachedFactory;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 242 */     GenericWebApplicationContext factory = new GenericWebApplicationContext();
/* 243 */     factory.setParent(getApplicationContext());
/* 244 */     factory.setServletContext(getServletContext());
/*     */ 
/* 247 */     PropertiesBeanDefinitionReader reader = new PropertiesBeanDefinitionReader(factory);
/* 248 */     reader.setDefaultParentBean(this.defaultParentView);
/* 249 */     for (ResourceBundle bundle : bundles) {
/* 250 */       reader.registerBeanDefinitions(bundle);
/*     */     }
/*     */ 
/* 253 */     factory.refresh();
/*     */ 
/* 256 */     if (isCache()) {
/* 257 */       this.localeCache.put(locale, factory);
/* 258 */       this.bundleCache.put(bundles, factory);
/*     */     }
/*     */ 
/* 261 */     return factory;
/*     */   }
/*     */ 
/*     */   protected ResourceBundle getBundle(String basename, Locale locale)
/*     */     throws MissingResourceException
/*     */   {
/* 273 */     return ResourceBundle.getBundle(basename, locale, getBundleClassLoader());
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws BeansException
/*     */   {
/* 282 */     for (ConfigurableApplicationContext factory : this.bundleCache.values()) {
/* 283 */       factory.close();
/*     */     }
/* 285 */     this.localeCache.clear();
/* 286 */     this.bundleCache.clear();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.ResourceBundleViewResolver
 * JD-Core Version:    0.6.2
 */