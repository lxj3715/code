/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.web.servlet.View;
/*     */ 
/*     */ public class UrlBasedViewResolver extends AbstractCachingViewResolver
/*     */   implements Ordered
/*     */ {
/*     */   public static final String REDIRECT_URL_PREFIX = "redirect:";
/*     */   public static final String FORWARD_URL_PREFIX = "forward:";
/*     */   private Class<?> viewClass;
/* 105 */   private String prefix = "";
/*     */ 
/* 107 */   private String suffix = "";
/*     */ 
/* 109 */   private String[] viewNames = null;
/*     */   private String contentType;
/* 113 */   private boolean redirectContextRelative = true;
/*     */ 
/* 115 */   private boolean redirectHttp10Compatible = true;
/*     */   private String requestContextAttribute;
/* 119 */   private int order = 2147483647;
/*     */ 
/* 122 */   private final Map<String, Object> staticAttributes = new HashMap();
/*     */   private Boolean exposePathVariables;
/*     */ 
/*     */   public void setViewClass(Class<?> viewClass)
/*     */   {
/* 133 */     if ((viewClass == null) || (!requiredViewClass().isAssignableFrom(viewClass)))
/*     */     {
/* 136 */       throw new IllegalArgumentException(new StringBuilder().append("Given view class [")
/* 135 */         .append(viewClass != null ? viewClass
/* 135 */         .getName() : null).append("] is not of type [")
/* 136 */         .append(requiredViewClass().getName()).append("]").toString());
/*     */     }
/* 138 */     this.viewClass = viewClass;
/*     */   }
/*     */ 
/*     */   protected Class<?> getViewClass()
/*     */   {
/* 145 */     return this.viewClass;
/*     */   }
/*     */ 
/*     */   protected Class<?> requiredViewClass()
/*     */   {
/* 154 */     return AbstractUrlBasedView.class;
/*     */   }
/*     */ 
/*     */   public void setPrefix(String prefix)
/*     */   {
/* 161 */     this.prefix = (prefix != null ? prefix : "");
/*     */   }
/*     */ 
/*     */   protected String getPrefix()
/*     */   {
/* 168 */     return this.prefix;
/*     */   }
/*     */ 
/*     */   public void setSuffix(String suffix)
/*     */   {
/* 175 */     this.suffix = (suffix != null ? suffix : "");
/*     */   }
/*     */ 
/*     */   protected String getSuffix()
/*     */   {
/* 182 */     return this.suffix;
/*     */   }
/*     */ 
/*     */   public void setContentType(String contentType)
/*     */   {
/* 191 */     this.contentType = contentType;
/*     */   }
/*     */ 
/*     */   protected String getContentType()
/*     */   {
/* 198 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   public void setRedirectContextRelative(boolean redirectContextRelative)
/*     */   {
/* 214 */     this.redirectContextRelative = redirectContextRelative;
/*     */   }
/*     */ 
/*     */   protected boolean isRedirectContextRelative()
/*     */   {
/* 223 */     return this.redirectContextRelative;
/*     */   }
/*     */ 
/*     */   public void setRedirectHttp10Compatible(boolean redirectHttp10Compatible)
/*     */   {
/* 241 */     this.redirectHttp10Compatible = redirectHttp10Compatible;
/*     */   }
/*     */ 
/*     */   protected boolean isRedirectHttp10Compatible()
/*     */   {
/* 248 */     return this.redirectHttp10Compatible;
/*     */   }
/*     */ 
/*     */   public void setRequestContextAttribute(String requestContextAttribute)
/*     */   {
/* 257 */     this.requestContextAttribute = requestContextAttribute;
/*     */   }
/*     */ 
/*     */   protected String getRequestContextAttribute()
/*     */   {
/* 264 */     return this.requestContextAttribute;
/*     */   }
/*     */ 
/*     */   public void setAttributes(Properties props)
/*     */   {
/* 279 */     CollectionUtils.mergePropertiesIntoMap(props, this.staticAttributes);
/*     */   }
/*     */ 
/*     */   public void setAttributesMap(Map<String, ?> attributes)
/*     */   {
/* 290 */     if (attributes != null)
/* 291 */       this.staticAttributes.putAll(attributes);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getAttributesMap()
/*     */   {
/* 303 */     return this.staticAttributes;
/*     */   }
/*     */ 
/*     */   public void setViewNames(String[] viewNames)
/*     */   {
/* 314 */     this.viewNames = viewNames;
/*     */   }
/*     */ 
/*     */   protected String[] getViewNames()
/*     */   {
/* 322 */     return this.viewNames;
/*     */   }
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/* 330 */     this.order = order;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 339 */     return this.order;
/*     */   }
/*     */ 
/*     */   public void setExposePathVariables(Boolean exposePathVariables)
/*     */   {
/* 355 */     this.exposePathVariables = exposePathVariables;
/*     */   }
/*     */ 
/*     */   protected void initApplicationContext()
/*     */   {
/* 360 */     super.initApplicationContext();
/* 361 */     if (getViewClass() == null)
/* 362 */       throw new IllegalArgumentException("Property 'viewClass' is required");
/*     */   }
/*     */ 
/*     */   protected Object getCacheKey(String viewName, Locale locale)
/*     */   {
/* 372 */     return viewName;
/*     */   }
/*     */ 
/*     */   protected View createView(String viewName, Locale locale)
/*     */     throws Exception
/*     */   {
/* 387 */     if (!canHandle(viewName, locale)) {
/* 388 */       return null;
/*     */     }
/*     */ 
/* 391 */     if (viewName.startsWith("redirect:")) {
/* 392 */       String redirectUrl = viewName.substring("redirect:".length());
/* 393 */       RedirectView view = new RedirectView(redirectUrl, isRedirectContextRelative(), isRedirectHttp10Compatible());
/* 394 */       return applyLifecycleMethods(viewName, view);
/*     */     }
/*     */ 
/* 397 */     if (viewName.startsWith("forward:")) {
/* 398 */       String forwardUrl = viewName.substring("forward:".length());
/* 399 */       return new InternalResourceView(forwardUrl);
/*     */     }
/*     */ 
/* 402 */     return super.createView(viewName, locale);
/*     */   }
/*     */ 
/*     */   protected boolean canHandle(String viewName, Locale locale)
/*     */   {
/* 416 */     String[] viewNames = getViewNames();
/* 417 */     return (viewNames == null) || (PatternMatchUtils.simpleMatch(viewNames, viewName));
/*     */   }
/*     */ 
/*     */   protected View loadView(String viewName, Locale locale)
/*     */     throws Exception
/*     */   {
/* 437 */     AbstractUrlBasedView view = buildView(viewName);
/* 438 */     View result = applyLifecycleMethods(viewName, view);
/* 439 */     return view.checkResource(locale) ? result : null;
/*     */   }
/*     */ 
/*     */   private View applyLifecycleMethods(String viewName, AbstractView view) {
/* 443 */     return (View)getApplicationContext().getAutowireCapableBeanFactory().initializeBean(view, viewName);
/*     */   }
/*     */ 
/*     */   protected AbstractUrlBasedView buildView(String viewName)
/*     */     throws Exception
/*     */   {
/* 461 */     AbstractUrlBasedView view = (AbstractUrlBasedView)BeanUtils.instantiateClass(getViewClass());
/* 462 */     view.setUrl(new StringBuilder().append(getPrefix()).append(viewName).append(getSuffix()).toString());
/* 463 */     String contentType = getContentType();
/* 464 */     if (contentType != null) {
/* 465 */       view.setContentType(contentType);
/*     */     }
/* 467 */     view.setRequestContextAttribute(getRequestContextAttribute());
/* 468 */     view.setAttributesMap(getAttributesMap());
/* 469 */     if (this.exposePathVariables != null) {
/* 470 */       view.setExposePathVariables(this.exposePathVariables.booleanValue());
/*     */     }
/* 472 */     return view;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.UrlBasedViewResolver
 * JD-Core Version:    0.6.2
 */