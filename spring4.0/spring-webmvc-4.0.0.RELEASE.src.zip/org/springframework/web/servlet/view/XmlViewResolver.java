/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.xml.ResourceEntityResolver;
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.web.context.support.GenericWebApplicationContext;
/*     */ import org.springframework.web.servlet.View;
/*     */ 
/*     */ public class XmlViewResolver extends AbstractCachingViewResolver
/*     */   implements Ordered, InitializingBean, DisposableBean
/*     */ {
/*     */   public static final String DEFAULT_LOCATION = "/WEB-INF/views.xml";
/*  61 */   private int order = 2147483647;
/*     */   private Resource location;
/*     */   private ConfigurableApplicationContext cachedFactory;
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/*  69 */     this.order = order;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/*  74 */     return this.order;
/*     */   }
/*     */ 
/*     */   public void setLocation(Resource location)
/*     */   {
/*  83 */     this.location = location;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws BeansException
/*     */   {
/*  92 */     if (isCache())
/*  93 */       initFactory();
/*     */   }
/*     */ 
/*     */   protected Object getCacheKey(String viewName, Locale locale)
/*     */   {
/* 104 */     return viewName;
/*     */   }
/*     */ 
/*     */   protected View loadView(String viewName, Locale locale) throws BeansException
/*     */   {
/* 109 */     BeanFactory factory = initFactory();
/*     */     try {
/* 111 */       return (View)factory.getBean(viewName, View.class);
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {
/*     */     }
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */   protected synchronized BeanFactory initFactory()
/*     */     throws BeansException
/*     */   {
/* 125 */     if (this.cachedFactory != null) {
/* 126 */       return this.cachedFactory;
/*     */     }
/*     */ 
/* 129 */     Resource actualLocation = this.location;
/* 130 */     if (actualLocation == null) {
/* 131 */       actualLocation = getApplicationContext().getResource("/WEB-INF/views.xml");
/*     */     }
/*     */ 
/* 135 */     GenericWebApplicationContext factory = new GenericWebApplicationContext();
/* 136 */     factory.setParent(getApplicationContext());
/* 137 */     factory.setServletContext(getServletContext());
/*     */ 
/* 140 */     XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(factory);
/* 141 */     reader.setEnvironment(getApplicationContext().getEnvironment());
/* 142 */     reader.setEntityResolver(new ResourceEntityResolver(getApplicationContext()));
/* 143 */     reader.loadBeanDefinitions(actualLocation);
/*     */ 
/* 145 */     factory.refresh();
/*     */ 
/* 147 */     if (isCache()) {
/* 148 */       this.cachedFactory = factory;
/*     */     }
/* 150 */     return factory;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws BeansException
/*     */   {
/* 159 */     if (this.cachedFactory != null)
/* 160 */       this.cachedFactory.close();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.XmlViewResolver
 * JD-Core Version:    0.6.2
 */