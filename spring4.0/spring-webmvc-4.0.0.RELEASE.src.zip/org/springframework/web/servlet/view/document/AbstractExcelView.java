/*     */ package org.springframework.web.servlet.view.document;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ import org.apache.poi.poifs.filesystem.POIFSFileSystem;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.LocalizedResourceHelper;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ import org.springframework.web.servlet.view.AbstractView;
/*     */ 
/*     */ public abstract class AbstractExcelView extends AbstractView
/*     */ {
/*     */   private static final String CONTENT_TYPE = "application/vnd.ms-excel";
/*     */   private static final String EXTENSION = ".xls";
/*     */   private String url;
/*     */ 
/*     */   public AbstractExcelView()
/*     */   {
/* 113 */     setContentType("application/vnd.ms-excel");
/*     */   }
/*     */ 
/*     */   public void setUrl(String url)
/*     */   {
/* 120 */     this.url = url;
/*     */   }
/*     */ 
/*     */   protected boolean generatesDownloadContent()
/*     */   {
/* 126 */     return true;
/*     */   }
/*     */ 
/*     */   protected final void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*     */     HSSFWorkbook workbook;
/*     */     HSSFWorkbook workbook;
/* 137 */     if (this.url != null) {
/* 138 */       workbook = getTemplateSource(this.url, request);
/*     */     }
/*     */     else {
/* 141 */       workbook = new HSSFWorkbook();
/* 142 */       this.logger.debug("Created Excel Workbook from scratch");
/*     */     }
/*     */ 
/* 145 */     buildExcelDocument(model, workbook, request, response);
/*     */ 
/* 148 */     response.setContentType(getContentType());
/*     */ 
/* 154 */     ServletOutputStream out = response.getOutputStream();
/* 155 */     workbook.write(out);
/* 156 */     out.flush();
/*     */   }
/*     */ 
/*     */   protected HSSFWorkbook getTemplateSource(String url, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 167 */     LocalizedResourceHelper helper = new LocalizedResourceHelper(getApplicationContext());
/* 168 */     Locale userLocale = RequestContextUtils.getLocale(request);
/* 169 */     Resource inputFile = helper.findLocalizedResource(url, ".xls", userLocale);
/*     */ 
/* 172 */     if (this.logger.isDebugEnabled()) {
/* 173 */       this.logger.debug("Loading Excel workbook from " + inputFile);
/*     */     }
/* 175 */     POIFSFileSystem fs = new POIFSFileSystem(inputFile.getInputStream());
/* 176 */     return new HSSFWorkbook(fs);
/*     */   }
/*     */ 
/*     */   protected abstract void buildExcelDocument(Map<String, Object> paramMap, HSSFWorkbook paramHSSFWorkbook, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*     */     throws Exception;
/*     */ 
/*     */   protected HSSFCell getCell(HSSFSheet sheet, int row, int col)
/*     */   {
/* 202 */     HSSFRow sheetRow = sheet.getRow(row);
/* 203 */     if (sheetRow == null) {
/* 204 */       sheetRow = sheet.createRow(row);
/*     */     }
/* 206 */     HSSFCell cell = sheetRow.getCell(col);
/* 207 */     if (cell == null) {
/* 208 */       cell = sheetRow.createCell(col);
/*     */     }
/* 210 */     return cell;
/*     */   }
/*     */ 
/*     */   protected void setText(HSSFCell cell, String text)
/*     */   {
/* 219 */     cell.setCellType(1);
/* 220 */     cell.setCellValue(text);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.document.AbstractExcelView
 * JD-Core Version:    0.6.2
 */