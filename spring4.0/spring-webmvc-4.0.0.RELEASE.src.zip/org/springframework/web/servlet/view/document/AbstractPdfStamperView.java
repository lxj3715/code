/*    */ package org.springframework.web.servlet.view.document;
/*    */ 
/*    */ import com.lowagie.text.pdf.PdfReader;
/*    */ import com.lowagie.text.pdf.PdfStamper;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*    */ 
/*    */ public abstract class AbstractPdfStamperView extends AbstractUrlBasedView
/*    */ {
/*    */   public AbstractPdfStamperView()
/*    */   {
/* 45 */     setContentType("application/pdf");
/*    */   }
/*    */ 
/*    */   protected boolean generatesDownloadContent()
/*    */   {
/* 51 */     return true;
/*    */   }
/*    */ 
/*    */   protected final void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*    */     throws Exception
/*    */   {
/* 59 */     ByteArrayOutputStream baos = createTemporaryOutputStream();
/*    */ 
/* 61 */     PdfReader reader = readPdfResource();
/* 62 */     PdfStamper stamper = new PdfStamper(reader, baos);
/* 63 */     mergePdfDocument(model, stamper, request, response);
/* 64 */     stamper.close();
/*    */ 
/* 67 */     writeToResponse(response, baos);
/*    */   }
/*    */ 
/*    */   protected PdfReader readPdfResource()
/*    */     throws IOException
/*    */   {
/* 79 */     return new PdfReader(getApplicationContext().getResource(getUrl()).getInputStream());
/*    */   }
/*    */ 
/*    */   protected abstract void mergePdfDocument(Map<String, Object> paramMap, PdfStamper paramPdfStamper, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*    */     throws Exception;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.document.AbstractPdfStamperView
 * JD-Core Version:    0.6.2
 */