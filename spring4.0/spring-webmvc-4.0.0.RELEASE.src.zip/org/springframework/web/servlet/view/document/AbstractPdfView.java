/*     */ package org.springframework.web.servlet.view.document;
/*     */ 
/*     */ import com.lowagie.text.Document;
/*     */ import com.lowagie.text.DocumentException;
/*     */ import com.lowagie.text.PageSize;
/*     */ import com.lowagie.text.pdf.PdfWriter;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.web.servlet.view.AbstractView;
/*     */ 
/*     */ public abstract class AbstractPdfView extends AbstractView
/*     */ {
/*     */   public AbstractPdfView()
/*     */   {
/*  54 */     setContentType("application/pdf");
/*     */   }
/*     */ 
/*     */   protected boolean generatesDownloadContent()
/*     */   {
/*  60 */     return true;
/*     */   }
/*     */ 
/*     */   protected final void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*  68 */     ByteArrayOutputStream baos = createTemporaryOutputStream();
/*     */ 
/*  71 */     Document document = newDocument();
/*  72 */     PdfWriter writer = newWriter(document, baos);
/*  73 */     prepareWriter(model, writer, request);
/*  74 */     buildPdfMetadata(model, document, request);
/*     */ 
/*  77 */     document.open();
/*  78 */     buildPdfDocument(model, document, writer, request, response);
/*  79 */     document.close();
/*     */ 
/*  82 */     writeToResponse(response, baos);
/*     */   }
/*     */ 
/*     */   protected Document newDocument()
/*     */   {
/*  93 */     return new Document(PageSize.A4);
/*     */   }
/*     */ 
/*     */   protected PdfWriter newWriter(Document document, OutputStream os)
/*     */     throws DocumentException
/*     */   {
/* 104 */     return PdfWriter.getInstance(document, os);
/*     */   }
/*     */ 
/*     */   protected void prepareWriter(Map<String, Object> model, PdfWriter writer, HttpServletRequest request)
/*     */     throws DocumentException
/*     */   {
/* 125 */     writer.setViewerPreferences(getViewerPreferences());
/*     */   }
/*     */ 
/*     */   protected int getViewerPreferences()
/*     */   {
/* 139 */     return 2053;
/*     */   }
/*     */ 
/*     */   protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected abstract void buildPdfDocument(Map<String, Object> paramMap, Document paramDocument, PdfWriter paramPdfWriter, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*     */     throws Exception;
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.document.AbstractPdfView
 * JD-Core Version:    0.6.2
 */