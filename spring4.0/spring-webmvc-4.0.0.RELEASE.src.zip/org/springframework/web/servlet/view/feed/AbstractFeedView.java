/*    */ package org.springframework.web.servlet.view.feed;
/*    */ 
/*    */ import com.sun.syndication.feed.WireFeed;
/*    */ import com.sun.syndication.io.WireFeedOutput;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletOutputStream;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.servlet.view.AbstractView;
/*    */ 
/*    */ public abstract class AbstractFeedView<T extends WireFeed> extends AbstractView
/*    */ {
/*    */   protected final void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*    */     throws Exception
/*    */   {
/* 53 */     WireFeed wireFeed = newFeed();
/* 54 */     buildFeedMetadata(model, wireFeed, request);
/* 55 */     buildFeedEntries(model, wireFeed, request, response);
/*    */ 
/* 57 */     setResponseContentType(request, response);
/* 58 */     if (!StringUtils.hasText(wireFeed.getEncoding())) {
/* 59 */       wireFeed.setEncoding("UTF-8");
/*    */     }
/*    */ 
/* 62 */     WireFeedOutput feedOutput = new WireFeedOutput();
/* 63 */     ServletOutputStream out = response.getOutputStream();
/* 64 */     feedOutput.output(wireFeed, new OutputStreamWriter(out, wireFeed.getEncoding()));
/* 65 */     out.flush();
/*    */   }
/*    */ 
/*    */   protected abstract T newFeed();
/*    */ 
/*    */   protected void buildFeedMetadata(Map<String, Object> model, T feed, HttpServletRequest request)
/*    */   {
/*    */   }
/*    */ 
/*    */   protected abstract void buildFeedEntries(Map<String, Object> paramMap, T paramT, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*    */     throws Exception;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.feed.AbstractFeedView
 * JD-Core Version:    0.6.2
 */