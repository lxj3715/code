package org.springframework.web.servlet.view.freemarker;

import freemarker.ext.jsp.TaglibFactory;
import freemarker.template.Configuration;

public abstract interface FreeMarkerConfig
{
  public abstract Configuration getConfiguration();

  public abstract TaglibFactory getTaglibFactory();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.freemarker.FreeMarkerConfig
 * JD-Core Version:    0.6.2
 */