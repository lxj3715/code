/*    */ package org.springframework.web.servlet.view.freemarker;
/*    */ 
/*    */ import org.springframework.web.servlet.view.AbstractTemplateViewResolver;
/*    */ 
/*    */ public class FreeMarkerViewResolver extends AbstractTemplateViewResolver
/*    */ {
/*    */   public FreeMarkerViewResolver()
/*    */   {
/* 44 */     setViewClass(requiredViewClass());
/*    */   }
/*    */ 
/*    */   protected Class<?> requiredViewClass()
/*    */   {
/* 52 */     return FreeMarkerView.class;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver
 * JD-Core Version:    0.6.2
 */