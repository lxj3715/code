/*     */ package org.springframework.web.servlet.view.jasperreports;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.sf.jasperreports.engine.JRExporter;
/*     */ import net.sf.jasperreports.engine.JRExporterParameter;
/*     */ import net.sf.jasperreports.engine.JasperPrint;
/*     */ import org.springframework.ui.jasperreports.JasperReportsUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public abstract class AbstractJasperReportsSingleFormatView extends AbstractJasperReportsView
/*     */ {
/*     */   protected boolean generatesDownloadContent()
/*     */   {
/*  49 */     return !useWriter();
/*     */   }
/*     */ 
/*     */   protected void renderReport(JasperPrint populatedReport, Map<String, Object> model, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*  60 */     JRExporter exporter = createExporter();
/*     */ 
/*  62 */     Map mergedExporterParameters = getConvertedExporterParameters();
/*  63 */     if (!CollectionUtils.isEmpty(mergedExporterParameters)) {
/*  64 */       exporter.setParameters(mergedExporterParameters);
/*     */     }
/*     */ 
/*  67 */     if (useWriter()) {
/*  68 */       renderReportUsingWriter(exporter, populatedReport, response);
/*     */     }
/*     */     else
/*  71 */       renderReportUsingOutputStream(exporter, populatedReport, response);
/*     */   }
/*     */ 
/*     */   protected void renderReportUsingWriter(JRExporter exporter, JasperPrint populatedReport, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*  86 */     String contentType = getContentType();
/*  87 */     String encoding = (String)exporter.getParameter(JRExporterParameter.CHARACTER_ENCODING);
/*  88 */     if (encoding != null)
/*     */     {
/*  90 */       if ((contentType != null) && (!contentType.toLowerCase().contains(";charset="))) {
/*  91 */         contentType = contentType + ";charset=" + encoding;
/*     */       }
/*     */     }
/*  94 */     response.setContentType(contentType);
/*     */ 
/*  97 */     JasperReportsUtils.render(exporter, populatedReport, response.getWriter());
/*     */   }
/*     */ 
/*     */   protected void renderReportUsingOutputStream(JRExporter exporter, JasperPrint populatedReport, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 111 */     ByteArrayOutputStream baos = createTemporaryOutputStream();
/* 112 */     JasperReportsUtils.render(exporter, populatedReport, baos);
/* 113 */     writeToResponse(response, baos);
/*     */   }
/*     */ 
/*     */   protected abstract JRExporter createExporter();
/*     */ 
/*     */   protected abstract boolean useWriter();
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.jasperreports.AbstractJasperReportsSingleFormatView
 * JD-Core Version:    0.6.2
 */