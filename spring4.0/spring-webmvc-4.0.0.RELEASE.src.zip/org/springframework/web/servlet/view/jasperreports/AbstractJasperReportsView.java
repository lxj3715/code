/*     */ package org.springframework.web.servlet.view.jasperreports;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.sql.Connection;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.sql.DataSource;
/*     */ import net.sf.jasperreports.engine.JRDataSource;
/*     */ import net.sf.jasperreports.engine.JRDataSourceProvider;
/*     */ import net.sf.jasperreports.engine.JRException;
/*     */ import net.sf.jasperreports.engine.JRExporterParameter;
/*     */ import net.sf.jasperreports.engine.JasperCompileManager;
/*     */ import net.sf.jasperreports.engine.JasperFillManager;
/*     */ import net.sf.jasperreports.engine.JasperPrint;
/*     */ import net.sf.jasperreports.engine.JasperReport;
/*     */ import net.sf.jasperreports.engine.design.JasperDesign;
/*     */ import net.sf.jasperreports.engine.util.JRLoader;
/*     */ import net.sf.jasperreports.engine.xml.JRXmlLoader;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.support.MessageSourceResourceBundle;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.ui.jasperreports.JasperReportsUtils;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*     */ 
/*     */ public abstract class AbstractJasperReportsView extends AbstractUrlBasedView
/*     */ {
/*     */   protected static final String HEADER_CONTENT_DISPOSITION = "Content-Disposition";
/*     */   protected static final String CONTENT_DISPOSITION_INLINE = "inline";
/*     */   private String reportDataKey;
/*     */   private Properties subReportUrls;
/*     */   private String[] subReportDataKeys;
/*     */   private Properties headers;
/* 155 */   private Map<?, ?> exporterParameters = new HashMap();
/*     */   private Map<JRExporterParameter, Object> convertedExporterParameters;
/*     */   private DataSource jdbcDataSource;
/*     */   private JasperReport report;
/*     */   private Map<String, JasperReport> subReports;
/*     */ 
/*     */   public void setReportDataKey(String reportDataKey)
/*     */   {
/* 195 */     this.reportDataKey = reportDataKey;
/*     */   }
/*     */ 
/*     */   public void setSubReportUrls(Properties subReports)
/*     */   {
/* 208 */     this.subReportUrls = subReports;
/*     */   }
/*     */ 
/*     */   public void setSubReportDataKeys(String[] subReportDataKeys)
/*     */   {
/* 232 */     this.subReportDataKeys = subReportDataKeys;
/*     */   }
/*     */ 
/*     */   public void setHeaders(Properties headers)
/*     */   {
/* 240 */     this.headers = headers;
/*     */   }
/*     */ 
/*     */   public void setExporterParameters(Map<?, ?> parameters)
/*     */   {
/* 251 */     this.exporterParameters = parameters;
/*     */   }
/*     */ 
/*     */   public Map<?, ?> getExporterParameters()
/*     */   {
/* 258 */     return this.exporterParameters;
/*     */   }
/*     */ 
/*     */   protected void setConvertedExporterParameters(Map<JRExporterParameter, Object> convertedExporterParameters)
/*     */   {
/* 265 */     this.convertedExporterParameters = convertedExporterParameters;
/*     */   }
/*     */ 
/*     */   protected Map<JRExporterParameter, Object> getConvertedExporterParameters()
/*     */   {
/* 272 */     return this.convertedExporterParameters;
/*     */   }
/*     */ 
/*     */   public void setJdbcDataSource(DataSource jdbcDataSource)
/*     */   {
/* 280 */     this.jdbcDataSource = jdbcDataSource;
/*     */   }
/*     */ 
/*     */   protected DataSource getJdbcDataSource()
/*     */   {
/* 287 */     return this.jdbcDataSource;
/*     */   }
/*     */ 
/*     */   protected boolean isUrlRequired()
/*     */   {
/* 297 */     return false;
/*     */   }
/*     */ 
/*     */   protected final void initApplicationContext()
/*     */     throws ApplicationContextException
/*     */   {
/* 308 */     this.report = loadReport();
/*     */     Enumeration urls;
/* 311 */     if (this.subReportUrls != null) {
/* 312 */       if ((this.subReportDataKeys != null) && (this.subReportDataKeys.length > 0) && (this.reportDataKey == null)) {
/* 313 */         throw new ApplicationContextException("'reportDataKey' for main report is required when specifying a value for 'subReportDataKeys'");
/*     */       }
/*     */ 
/* 316 */       this.subReports = new HashMap(this.subReportUrls.size());
/* 317 */       for (urls = this.subReportUrls.propertyNames(); urls.hasMoreElements(); ) {
/* 318 */         String key = (String)urls.nextElement();
/* 319 */         String path = this.subReportUrls.getProperty(key);
/* 320 */         Resource resource = getApplicationContext().getResource(path);
/* 321 */         this.subReports.put(key, loadReport(resource));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 326 */     convertExporterParameters();
/*     */ 
/* 328 */     if (this.headers == null) {
/* 329 */       this.headers = new Properties();
/*     */     }
/* 331 */     if (!this.headers.containsKey("Content-Disposition")) {
/* 332 */       this.headers.setProperty("Content-Disposition", "inline");
/*     */     }
/*     */ 
/* 335 */     onInit();
/*     */   }
/*     */ 
/*     */   protected void onInit()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected final void convertExporterParameters()
/*     */   {
/* 355 */     if (!CollectionUtils.isEmpty(this.exporterParameters)) {
/* 356 */       this.convertedExporterParameters = new HashMap(this.exporterParameters.size());
/* 357 */       for (Map.Entry entry : this.exporterParameters.entrySet()) {
/* 358 */         JRExporterParameter exporterParameter = getExporterParameter(entry.getKey());
/* 359 */         this.convertedExporterParameters.put(exporterParameter, 
/* 360 */           convertParameterValue(exporterParameter, entry
/* 360 */           .getValue()));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object convertParameterValue(JRExporterParameter parameter, Object value)
/*     */   {
/* 377 */     if ((value instanceof String)) {
/* 378 */       String str = (String)value;
/* 379 */       if ("true".equals(str)) {
/* 380 */         return Boolean.TRUE;
/*     */       }
/* 382 */       if ("false".equals(str)) {
/* 383 */         return Boolean.FALSE;
/*     */       }
/* 385 */       if ((str.length() > 0) && (Character.isDigit(str.charAt(0)))) {
/*     */         try
/*     */         {
/* 388 */           return new Integer(str);
/*     */         }
/*     */         catch (NumberFormatException ex)
/*     */         {
/* 392 */           return str;
/*     */         }
/*     */       }
/*     */     }
/* 396 */     return value;
/*     */   }
/*     */ 
/*     */   protected JRExporterParameter getExporterParameter(Object parameter)
/*     */   {
/* 407 */     if ((parameter instanceof JRExporterParameter)) {
/* 408 */       return (JRExporterParameter)parameter;
/*     */     }
/* 410 */     if ((parameter instanceof String)) {
/* 411 */       return convertToExporterParameter((String)parameter);
/*     */     }
/* 413 */     throw new IllegalArgumentException("Parameter [" + parameter + "] is invalid type. Should be either String or JRExporterParameter.");
/*     */   }
/*     */ 
/*     */   protected JRExporterParameter convertToExporterParameter(String fqFieldName)
/*     */   {
/* 426 */     int index = fqFieldName.lastIndexOf(46);
/* 427 */     if ((index == -1) || (index == fqFieldName.length())) {
/* 428 */       throw new IllegalArgumentException("Parameter name [" + fqFieldName + "] is not a valid static field. " + "The parameter name must map to a static field such as " + "[net.sf.jasperreports.engine.export.JRHtmlExporterParameter.IMAGES_URI]");
/*     */     }
/*     */ 
/* 433 */     String className = fqFieldName.substring(0, index);
/* 434 */     String fieldName = fqFieldName.substring(index + 1);
/*     */     try
/*     */     {
/* 437 */       Class cls = ClassUtils.forName(className, getApplicationContext().getClassLoader());
/* 438 */       Field field = cls.getField(fieldName);
/*     */ 
/* 440 */       if (JRExporterParameter.class.isAssignableFrom(field.getType())) {
/*     */         try {
/* 442 */           return (JRExporterParameter)field.get(null);
/*     */         }
/*     */         catch (IllegalAccessException ex) {
/* 445 */           throw new IllegalArgumentException("Unable to access field [" + fieldName + "] of class [" + className + "]. " + "Check that it is static and accessible.");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 451 */       throw new IllegalArgumentException("Field [" + fieldName + "] on class [" + className + "] is not assignable from JRExporterParameter - check the type of this field.");
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/* 456 */       throw new IllegalArgumentException("Class [" + className + "] in key [" + fqFieldName + "] could not be found.");
/*     */     }
/*     */     catch (NoSuchFieldException ex) {
/*     */     }
/* 460 */     throw new IllegalArgumentException("Field [" + fieldName + "] in key [" + fqFieldName + "] could not be found on class [" + className + "].");
/*     */   }
/*     */ 
/*     */   protected JasperReport loadReport()
/*     */   {
/* 473 */     String url = getUrl();
/* 474 */     if (url == null) {
/* 475 */       return null;
/*     */     }
/* 477 */     Resource mainReport = getApplicationContext().getResource(url);
/* 478 */     return loadReport(mainReport);
/*     */   }
/*     */ 
/*     */   protected final JasperReport loadReport(Resource resource)
/*     */   {
/*     */     try
/*     */     {
/* 490 */       String filename = resource.getFilename();
/* 491 */       if (filename != null) {
/* 492 */         if (filename.endsWith(".jasper"))
/*     */         {
/* 494 */           if (this.logger.isInfoEnabled()) {
/* 495 */             this.logger.info("Loading pre-compiled Jasper Report from " + resource);
/*     */           }
/* 497 */           InputStream is = resource.getInputStream();
/*     */           try {
/* 499 */             return (JasperReport)JRLoader.loadObject(is);
/*     */           }
/*     */           finally {
/* 502 */             is.close();
/*     */           }
/*     */         }
/* 505 */         if (filename.endsWith(".jrxml"))
/*     */         {
/* 507 */           if (this.logger.isInfoEnabled()) {
/* 508 */             this.logger.info("Compiling Jasper Report loaded from " + resource);
/*     */           }
/* 510 */           InputStream is = resource.getInputStream();
/*     */           try {
/* 512 */             JasperDesign design = JRXmlLoader.load(is);
/* 513 */             return JasperCompileManager.compileReport(design);
/*     */           }
/*     */           finally {
/* 516 */             is.close();
/*     */           }
/*     */         }
/*     */       }
/* 520 */       throw new IllegalArgumentException("Report filename [" + filename + "] must end in either .jasper or .jrxml");
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 524 */       throw new ApplicationContextException("Could not load JasperReports report from " + resource, ex);
/*     */     }
/*     */     catch (JRException ex)
/*     */     {
/* 528 */       throw new ApplicationContextException("Could not parse JasperReports report from " + resource, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 545 */     if (this.subReports != null)
/*     */     {
/* 547 */       model.putAll(this.subReports);
/*     */ 
/* 550 */       if (this.subReportDataKeys != null) {
/* 551 */         for (String key : this.subReportDataKeys) {
/* 552 */           model.put(key, convertReportData(model.get(key)));
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 558 */     exposeLocalizationContext(model, request);
/*     */ 
/* 561 */     JasperPrint filledReport = fillReport(model);
/* 562 */     postProcessReport(filledReport, model);
/*     */ 
/* 565 */     populateHeaders(response);
/* 566 */     renderReport(filledReport, model, response);
/*     */   }
/*     */ 
/*     */   protected void exposeLocalizationContext(Map<String, Object> model, HttpServletRequest request)
/*     */   {
/* 584 */     RequestContext rc = new RequestContext(request, getServletContext());
/* 585 */     Locale locale = rc.getLocale();
/* 586 */     if (!model.containsKey("REPORT_LOCALE")) {
/* 587 */       model.put("REPORT_LOCALE", locale);
/*     */     }
/* 589 */     TimeZone timeZone = rc.getTimeZone();
/* 590 */     if ((timeZone != null) && (!model.containsKey("REPORT_TIME_ZONE"))) {
/* 591 */       model.put("REPORT_TIME_ZONE", timeZone);
/*     */     }
/* 593 */     JasperReport report = getReport();
/* 594 */     if (((report == null) || (report.getResourceBundle() == null)) && 
/* 595 */       (!model
/* 595 */       .containsKey("REPORT_RESOURCE_BUNDLE")))
/*     */     {
/* 596 */       model.put("REPORT_RESOURCE_BUNDLE", new MessageSourceResourceBundle(rc
/* 597 */         .getMessageSource(), locale));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JasperPrint fillReport(Map<String, Object> model)
/*     */     throws Exception
/*     */   {
/* 627 */     JasperReport report = getReport();
/* 628 */     if (report == null) {
/* 629 */       throw new IllegalStateException("No main report defined for 'fillReport' - specify a 'url' on this view or override 'getReport()' or 'fillReport(Map)'");
/*     */     }
/*     */ 
/* 633 */     JRDataSource jrDataSource = null;
/* 634 */     DataSource jdbcDataSourceToUse = null;
/*     */ 
/* 637 */     if (this.reportDataKey != null) {
/* 638 */       Object reportDataValue = model.get(this.reportDataKey);
/* 639 */       if ((reportDataValue instanceof DataSource)) {
/* 640 */         jdbcDataSourceToUse = (DataSource)reportDataValue;
/*     */       }
/*     */       else
/* 643 */         jrDataSource = convertReportData(reportDataValue);
/*     */     }
/*     */     else
/*     */     {
/* 647 */       Collection values = model.values();
/* 648 */       jrDataSource = (JRDataSource)CollectionUtils.findValueOfType(values, JRDataSource.class);
/* 649 */       if (jrDataSource == null) {
/* 650 */         JRDataSourceProvider provider = (JRDataSourceProvider)CollectionUtils.findValueOfType(values, JRDataSourceProvider.class);
/* 651 */         if (provider != null) {
/* 652 */           jrDataSource = createReport(provider);
/*     */         }
/*     */         else {
/* 655 */           jdbcDataSourceToUse = (DataSource)CollectionUtils.findValueOfType(values, DataSource.class);
/* 656 */           if (jdbcDataSourceToUse == null) {
/* 657 */             jdbcDataSourceToUse = this.jdbcDataSource;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 663 */     if (jdbcDataSourceToUse != null) {
/* 664 */       return doFillReport(report, model, jdbcDataSourceToUse);
/*     */     }
/*     */ 
/* 668 */     if (jrDataSource == null) {
/* 669 */       jrDataSource = getReportData(model);
/*     */     }
/* 671 */     if (jrDataSource != null)
/*     */     {
/* 673 */       if (this.logger.isDebugEnabled()) {
/* 674 */         this.logger.debug("Filling report with JRDataSource [" + jrDataSource + "]");
/*     */       }
/* 676 */       return JasperFillManager.fillReport(report, model, jrDataSource);
/*     */     }
/*     */ 
/* 681 */     this.logger.debug("Filling report with plain model");
/* 682 */     return JasperFillManager.fillReport(report, model);
/*     */   }
/*     */ 
/*     */   private JasperPrint doFillReport(JasperReport report, Map<String, Object> model, DataSource ds)
/*     */     throws Exception
/*     */   {
/* 692 */     if (this.logger.isDebugEnabled()) {
/* 693 */       this.logger.debug("Filling report using JDBC DataSource [" + ds + "]");
/*     */     }
/* 695 */     Connection con = ds.getConnection();
/*     */     try {
/* 697 */       return JasperFillManager.fillReport(report, model, con);
/*     */     }
/*     */     finally {
/*     */       try {
/* 701 */         con.close();
/*     */       }
/*     */       catch (Throwable ex) {
/* 704 */         this.logger.debug("Could not close JDBC Connection", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void populateHeaders(HttpServletResponse response)
/*     */   {
/* 715 */     for (Enumeration en = this.headers.propertyNames(); en.hasMoreElements(); ) {
/* 716 */       String key = (String)en.nextElement();
/* 717 */       response.addHeader(key, this.headers.getProperty(key));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JasperReport getReport()
/*     */   {
/* 732 */     return this.report;
/*     */   }
/*     */ 
/*     */   protected JRDataSource getReportData(Map<String, Object> model)
/*     */   {
/* 747 */     Object value = CollectionUtils.findValueOfType(model.values(), getReportDataTypes());
/* 748 */     return value != null ? convertReportData(value) : null;
/*     */   }
/*     */ 
/*     */   protected JRDataSource convertReportData(Object value)
/*     */     throws IllegalArgumentException
/*     */   {
/* 771 */     if ((value instanceof JRDataSourceProvider)) {
/* 772 */       return createReport((JRDataSourceProvider)value);
/*     */     }
/*     */ 
/* 775 */     return JasperReportsUtils.convertReportData(value);
/*     */   }
/*     */ 
/*     */   protected JRDataSource createReport(JRDataSourceProvider provider)
/*     */   {
/*     */     try
/*     */     {
/* 786 */       JasperReport report = getReport();
/* 787 */       if (report == null) {
/* 788 */         throw new IllegalStateException("No main report defined for JRDataSourceProvider - specify a 'url' on this view or override 'getReport()'");
/*     */       }
/*     */ 
/* 791 */       return provider.create(report);
/*     */     }
/*     */     catch (JRException ex) {
/* 794 */       throw new IllegalArgumentException("Supplied JRDataSourceProvider is invalid", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Class<?>[] getReportDataTypes()
/*     */   {
/* 806 */     return new Class[] { Collection.class, [Ljava.lang.Object.class };
/*     */   }
/*     */ 
/*     */   protected void postProcessReport(JasperPrint populatedReport, Map<String, Object> model)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   protected abstract void renderReport(JasperPrint paramJasperPrint, Map<String, Object> paramMap, HttpServletResponse paramHttpServletResponse)
/*     */     throws Exception;
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.jasperreports.AbstractJasperReportsView
 * JD-Core Version:    0.6.2
 */