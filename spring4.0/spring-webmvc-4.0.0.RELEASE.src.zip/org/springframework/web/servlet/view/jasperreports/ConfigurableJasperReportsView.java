/*    */ package org.springframework.web.servlet.view.jasperreports;
/*    */ 
/*    */ import net.sf.jasperreports.engine.JRExporter;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class ConfigurableJasperReportsView extends AbstractJasperReportsSingleFormatView
/*    */ {
/*    */   private Class<? extends JRExporter> exporterClass;
/* 39 */   private boolean useWriter = true;
/*    */ 
/*    */   public void setExporterClass(Class<? extends JRExporter> exporterClass)
/*    */   {
/* 48 */     Assert.isAssignable(JRExporter.class, exporterClass);
/* 49 */     this.exporterClass = exporterClass;
/*    */   }
/*    */ 
/*    */   public void setUseWriter(boolean useWriter)
/*    */   {
/* 58 */     this.useWriter = useWriter;
/*    */   }
/*    */ 
/*    */   protected void onInit()
/*    */   {
/* 66 */     if (this.exporterClass == null)
/* 67 */       throw new IllegalArgumentException("exporterClass is required");
/*    */   }
/*    */ 
/*    */   protected JRExporter createExporter()
/*    */   {
/* 79 */     return (JRExporter)BeanUtils.instantiateClass(this.exporterClass);
/*    */   }
/*    */ 
/*    */   protected boolean useWriter()
/*    */   {
/* 88 */     return this.useWriter;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.jasperreports.ConfigurableJasperReportsView
 * JD-Core Version:    0.6.2
 */