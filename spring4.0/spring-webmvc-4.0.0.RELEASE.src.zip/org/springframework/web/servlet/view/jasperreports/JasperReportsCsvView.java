/*    */ package org.springframework.web.servlet.view.jasperreports;
/*    */ 
/*    */ import net.sf.jasperreports.engine.JRExporter;
/*    */ import net.sf.jasperreports.engine.export.JRCsvExporter;
/*    */ 
/*    */ public class JasperReportsCsvView extends AbstractJasperReportsSingleFormatView
/*    */ {
/*    */   public JasperReportsCsvView()
/*    */   {
/* 33 */     setContentType("text/csv");
/*    */   }
/*    */ 
/*    */   protected JRExporter createExporter()
/*    */   {
/* 38 */     return new JRCsvExporter();
/*    */   }
/*    */ 
/*    */   protected boolean useWriter()
/*    */   {
/* 43 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.jasperreports.JasperReportsCsvView
 * JD-Core Version:    0.6.2
 */