/*    */ package org.springframework.web.servlet.view.jasperreports;
/*    */ 
/*    */ import net.sf.jasperreports.engine.JRExporter;
/*    */ import net.sf.jasperreports.engine.export.JRHtmlExporter;
/*    */ 
/*    */ public class JasperReportsHtmlView extends AbstractJasperReportsSingleFormatView
/*    */ {
/*    */   public JasperReportsHtmlView()
/*    */   {
/* 33 */     setContentType("text/html");
/*    */   }
/*    */ 
/*    */   protected JRExporter createExporter()
/*    */   {
/* 38 */     return new JRHtmlExporter();
/*    */   }
/*    */ 
/*    */   protected boolean useWriter()
/*    */   {
/* 43 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.jasperreports.JasperReportsHtmlView
 * JD-Core Version:    0.6.2
 */