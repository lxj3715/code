/*     */ package org.springframework.web.servlet.view.jasperreports;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.sf.jasperreports.engine.JasperPrint;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class JasperReportsMultiFormatView extends AbstractJasperReportsView
/*     */ {
/*     */   public static final String DEFAULT_FORMAT_KEY = "format";
/*  79 */   private String formatKey = "format";
/*     */   private Map<String, Class<? extends AbstractJasperReportsView>> formatMappings;
/*     */   private Properties contentDispositionMappings;
/*     */ 
/*     */   public JasperReportsMultiFormatView()
/*     */   {
/*  98 */     this.formatMappings = new HashMap(4);
/*  99 */     this.formatMappings.put("csv", JasperReportsCsvView.class);
/* 100 */     this.formatMappings.put("html", JasperReportsHtmlView.class);
/* 101 */     this.formatMappings.put("pdf", JasperReportsPdfView.class);
/* 102 */     this.formatMappings.put("xls", JasperReportsXlsView.class);
/*     */   }
/*     */ 
/*     */   public void setFormatKey(String formatKey)
/*     */   {
/* 110 */     this.formatKey = formatKey;
/*     */   }
/*     */ 
/*     */   public void setFormatMappings(Map<String, Class<? extends AbstractJasperReportsView>> formatMappings)
/*     */   {
/* 124 */     if (CollectionUtils.isEmpty(formatMappings)) {
/* 125 */       throw new IllegalArgumentException("'formatMappings' must not be empty");
/*     */     }
/* 127 */     this.formatMappings = formatMappings;
/*     */   }
/*     */ 
/*     */   public void setContentDispositionMappings(Properties mappings)
/*     */   {
/* 137 */     this.contentDispositionMappings = mappings;
/*     */   }
/*     */ 
/*     */   public Properties getContentDispositionMappings()
/*     */   {
/* 146 */     if (this.contentDispositionMappings == null) {
/* 147 */       this.contentDispositionMappings = new Properties();
/*     */     }
/* 149 */     return this.contentDispositionMappings;
/*     */   }
/*     */ 
/*     */   protected boolean generatesDownloadContent()
/*     */   {
/* 155 */     return true;
/*     */   }
/*     */ 
/*     */   protected void renderReport(JasperPrint populatedReport, Map<String, Object> model, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 167 */     String format = (String)model.get(this.formatKey);
/* 168 */     if (format == null) {
/* 169 */       throw new IllegalArgumentException("No format format found in model");
/*     */     }
/*     */ 
/* 172 */     if (this.logger.isDebugEnabled()) {
/* 173 */       this.logger.debug("Rendering report using format mapping key [" + format + "]");
/*     */     }
/*     */ 
/* 176 */     Class viewClass = (Class)this.formatMappings.get(format);
/* 177 */     if (viewClass == null) {
/* 178 */       throw new IllegalArgumentException("Format discriminator [" + format + "] is not a configured mapping");
/*     */     }
/*     */ 
/* 181 */     if (this.logger.isDebugEnabled()) {
/* 182 */       this.logger.debug("Rendering report using view class [" + viewClass.getName() + "]");
/*     */     }
/*     */ 
/* 185 */     AbstractJasperReportsView view = (AbstractJasperReportsView)BeanUtils.instantiateClass(viewClass);
/*     */ 
/* 188 */     view.setExporterParameters(getExporterParameters());
/* 189 */     view.setConvertedExporterParameters(getConvertedExporterParameters());
/*     */ 
/* 192 */     populateContentDispositionIfNecessary(response, format);
/* 193 */     view.renderReport(populatedReport, model, response);
/*     */   }
/*     */ 
/*     */   private void populateContentDispositionIfNecessary(HttpServletResponse response, String format)
/*     */   {
/* 204 */     if (this.contentDispositionMappings != null) {
/* 205 */       String header = this.contentDispositionMappings.getProperty(format);
/* 206 */       if (header != null) {
/* 207 */         if (this.logger.isDebugEnabled()) {
/* 208 */           this.logger.debug("Setting Content-Disposition header to: [" + header + "]");
/*     */         }
/* 210 */         response.setHeader("Content-Disposition", header);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.jasperreports.JasperReportsMultiFormatView
 * JD-Core Version:    0.6.2
 */