/*    */ package org.springframework.web.servlet.view.jasperreports;
/*    */ 
/*    */ import net.sf.jasperreports.engine.JRExporter;
/*    */ import net.sf.jasperreports.engine.export.JRPdfExporter;
/*    */ 
/*    */ public class JasperReportsPdfView extends AbstractJasperReportsSingleFormatView
/*    */ {
/*    */   public JasperReportsPdfView()
/*    */   {
/* 33 */     setContentType("application/pdf");
/*    */   }
/*    */ 
/*    */   protected JRExporter createExporter()
/*    */   {
/* 38 */     return new JRPdfExporter();
/*    */   }
/*    */ 
/*    */   protected boolean useWriter()
/*    */   {
/* 43 */     return false;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.jasperreports.JasperReportsPdfView
 * JD-Core Version:    0.6.2
 */