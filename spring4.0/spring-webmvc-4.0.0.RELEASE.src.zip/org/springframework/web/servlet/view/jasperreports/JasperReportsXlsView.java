/*    */ package org.springframework.web.servlet.view.jasperreports;
/*    */ 
/*    */ import net.sf.jasperreports.engine.JRExporter;
/*    */ import net.sf.jasperreports.engine.export.JRXlsExporter;
/*    */ 
/*    */ public class JasperReportsXlsView extends AbstractJasperReportsSingleFormatView
/*    */ {
/*    */   public JasperReportsXlsView()
/*    */   {
/* 33 */     setContentType("application/vnd.ms-excel");
/*    */   }
/*    */ 
/*    */   protected JRExporter createExporter()
/*    */   {
/* 38 */     return new JRXlsExporter();
/*    */   }
/*    */ 
/*    */   protected boolean useWriter()
/*    */   {
/* 43 */     return false;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.jasperreports.JasperReportsXlsView
 * JD-Core Version:    0.6.2
 */