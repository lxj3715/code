/*     */ package org.springframework.web.servlet.view.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonEncoding;
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.servlet.view.AbstractView;
/*     */ 
/*     */ public class MappingJackson2JsonView extends AbstractView
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "application/json";
/*  63 */   private ObjectMapper objectMapper = new ObjectMapper();
/*     */ 
/*  65 */   private JsonEncoding encoding = JsonEncoding.UTF8;
/*     */   private String jsonPrefix;
/*     */   private Boolean prettyPrint;
/*     */   private Set<String> modelKeys;
/*  73 */   private boolean extractValueFromSingleKeyModel = false;
/*     */ 
/*  75 */   private boolean disableCaching = true;
/*     */ 
/*  77 */   private boolean updateContentLength = false;
/*     */ 
/*     */   public MappingJackson2JsonView()
/*     */   {
/*  84 */     setContentType("application/json");
/*  85 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/*  97 */     Assert.notNull(objectMapper, "'objectMapper' must not be null");
/*  98 */     this.objectMapper = objectMapper;
/*  99 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   public final ObjectMapper getObjectMapper()
/*     */   {
/* 106 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public void setEncoding(JsonEncoding encoding)
/*     */   {
/* 114 */     Assert.notNull(encoding, "'encoding' must not be null");
/* 115 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */   public final JsonEncoding getEncoding()
/*     */   {
/* 122 */     return this.encoding;
/*     */   }
/*     */ 
/*     */   public void setJsonPrefix(String jsonPrefix)
/*     */   {
/* 131 */     this.jsonPrefix = jsonPrefix;
/*     */   }
/*     */ 
/*     */   public void setPrefixJson(boolean prefixJson)
/*     */   {
/* 144 */     this.jsonPrefix = (prefixJson ? "{} && " : null);
/*     */   }
/*     */ 
/*     */   public void setPrettyPrint(boolean prettyPrint)
/*     */   {
/* 157 */     this.prettyPrint = Boolean.valueOf(prettyPrint);
/* 158 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   private void configurePrettyPrint() {
/* 162 */     if (this.prettyPrint != null)
/* 163 */       this.objectMapper.configure(SerializationFeature.INDENT_OUTPUT, this.prettyPrint.booleanValue());
/*     */   }
/*     */ 
/*     */   public void setModelKey(String modelKey)
/*     */   {
/* 172 */     this.modelKeys = Collections.singleton(modelKey);
/*     */   }
/*     */ 
/*     */   public void setModelKeys(Set<String> modelKeys)
/*     */   {
/* 180 */     this.modelKeys = modelKeys;
/*     */   }
/*     */ 
/*     */   public final Set<String> getModelKeys()
/*     */   {
/* 187 */     return this.modelKeys;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setRenderedAttributes(Set<String> renderedAttributes)
/*     */   {
/* 197 */     this.modelKeys = renderedAttributes;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public final Set<String> getRenderedAttributes()
/*     */   {
/* 206 */     return this.modelKeys;
/*     */   }
/*     */ 
/*     */   public void setExtractValueFromSingleKeyModel(boolean extractValueFromSingleKeyModel)
/*     */   {
/* 217 */     this.extractValueFromSingleKeyModel = extractValueFromSingleKeyModel;
/*     */   }
/*     */ 
/*     */   public void setDisableCaching(boolean disableCaching)
/*     */   {
/* 225 */     this.disableCaching = disableCaching;
/*     */   }
/*     */ 
/*     */   public void setUpdateContentLength(boolean updateContentLength)
/*     */   {
/* 235 */     this.updateContentLength = updateContentLength;
/*     */   }
/*     */ 
/*     */   protected void prepareResponse(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 241 */     setResponseContentType(request, response);
/* 242 */     response.setCharacterEncoding(this.encoding.getJavaName());
/* 243 */     if (this.disableCaching) {
/* 244 */       response.addHeader("Pragma", "no-cache");
/* 245 */       response.addHeader("Cache-Control", "no-cache, no-store, max-age=0");
/* 246 */       response.addDateHeader("Expires", 1L);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 254 */     OutputStream stream = this.updateContentLength ? createTemporaryOutputStream() : response.getOutputStream();
/* 255 */     Object value = filterModel(model);
/* 256 */     writeContent(stream, value, this.jsonPrefix);
/* 257 */     if (this.updateContentLength)
/* 258 */       writeToResponse(response, (ByteArrayOutputStream)stream);
/*     */   }
/*     */ 
/*     */   protected Object filterModel(Map<String, Object> model)
/*     */   {
/* 271 */     Map result = new HashMap(model.size());
/* 272 */     Set renderedAttributes = !CollectionUtils.isEmpty(this.modelKeys) ? this.modelKeys : model.keySet();
/* 273 */     for (Map.Entry entry : model.entrySet()) {
/* 274 */       if ((!(entry.getValue() instanceof BindingResult)) && (renderedAttributes.contains(entry.getKey()))) {
/* 275 */         result.put(entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/* 278 */     return (this.extractValueFromSingleKeyModel) && (result.size() == 1) ? result.values().iterator().next() : result;
/*     */   }
/*     */ 
/*     */   protected void writeContent(OutputStream stream, Object value, String jsonPrefix)
/*     */     throws IOException
/*     */   {
/* 293 */     JsonGenerator generator = this.objectMapper.getJsonFactory().createJsonGenerator(stream, this.encoding);
/*     */ 
/* 297 */     if (this.objectMapper.isEnabled(SerializationFeature.INDENT_OUTPUT)) {
/* 298 */       generator.useDefaultPrettyPrinter();
/*     */     }
/*     */ 
/* 301 */     if (jsonPrefix != null) {
/* 302 */       generator.writeRaw(jsonPrefix);
/*     */     }
/* 304 */     this.objectMapper.writeValue(generator, value);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.json.MappingJackson2JsonView
 * JD-Core Version:    0.6.2
 */