/*     */ package org.springframework.web.servlet.view.json;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.codehaus.jackson.JsonEncoding;
/*     */ import org.codehaus.jackson.JsonFactory;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.map.ObjectMapper;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.servlet.view.AbstractView;
/*     */ 
/*     */ @Deprecated
/*     */ public class MappingJacksonJsonView extends AbstractView
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "application/json";
/*  65 */   private ObjectMapper objectMapper = new ObjectMapper();
/*     */ 
/*  67 */   private JsonEncoding encoding = JsonEncoding.UTF8;
/*     */   private String jsonPrefix;
/*     */   private Boolean prettyPrint;
/*     */   private Set<String> modelKeys;
/*  75 */   private boolean extractValueFromSingleKeyModel = false;
/*     */ 
/*  77 */   private boolean disableCaching = true;
/*     */ 
/*  79 */   private boolean updateContentLength = false;
/*     */ 
/*     */   public MappingJacksonJsonView()
/*     */   {
/*  86 */     setContentType("application/json");
/*  87 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/*  99 */     Assert.notNull(objectMapper, "'objectMapper' must not be null");
/* 100 */     this.objectMapper = objectMapper;
/* 101 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   public final ObjectMapper getObjectMapper()
/*     */   {
/* 108 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public void setEncoding(JsonEncoding encoding)
/*     */   {
/* 116 */     Assert.notNull(encoding, "'encoding' must not be null");
/* 117 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */   public final JsonEncoding getEncoding()
/*     */   {
/* 124 */     return this.encoding;
/*     */   }
/*     */ 
/*     */   public void setJsonPrefix(String jsonPrefix)
/*     */   {
/* 133 */     this.jsonPrefix = jsonPrefix;
/*     */   }
/*     */ 
/*     */   public void setPrefixJson(boolean prefixJson)
/*     */   {
/* 146 */     this.jsonPrefix = (prefixJson ? "{} && " : null);
/*     */   }
/*     */ 
/*     */   public void setPrettyPrint(boolean prettyPrint)
/*     */   {
/* 159 */     this.prettyPrint = Boolean.valueOf(prettyPrint);
/* 160 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   private void configurePrettyPrint() {
/* 164 */     if (this.prettyPrint != null)
/* 165 */       this.objectMapper.configure(SerializationConfig.Feature.INDENT_OUTPUT, this.prettyPrint.booleanValue());
/*     */   }
/*     */ 
/*     */   public void setModelKey(String modelKey)
/*     */   {
/* 174 */     this.modelKeys = Collections.singleton(modelKey);
/*     */   }
/*     */ 
/*     */   public void setModelKeys(Set<String> modelKeys)
/*     */   {
/* 182 */     this.modelKeys = modelKeys;
/*     */   }
/*     */ 
/*     */   public final Set<String> getModelKeys()
/*     */   {
/* 189 */     return this.modelKeys;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setRenderedAttributes(Set<String> renderedAttributes)
/*     */   {
/* 199 */     this.modelKeys = renderedAttributes;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public final Set<String> getRenderedAttributes()
/*     */   {
/* 208 */     return this.modelKeys;
/*     */   }
/*     */ 
/*     */   public void setExtractValueFromSingleKeyModel(boolean extractValueFromSingleKeyModel)
/*     */   {
/* 219 */     this.extractValueFromSingleKeyModel = extractValueFromSingleKeyModel;
/*     */   }
/*     */ 
/*     */   public void setDisableCaching(boolean disableCaching)
/*     */   {
/* 227 */     this.disableCaching = disableCaching;
/*     */   }
/*     */ 
/*     */   public void setUpdateContentLength(boolean updateContentLength)
/*     */   {
/* 237 */     this.updateContentLength = updateContentLength;
/*     */   }
/*     */ 
/*     */   protected void prepareResponse(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 243 */     setResponseContentType(request, response);
/* 244 */     response.setCharacterEncoding(this.encoding.getJavaName());
/* 245 */     if (this.disableCaching) {
/* 246 */       response.addHeader("Pragma", "no-cache");
/* 247 */       response.addHeader("Cache-Control", "no-cache, no-store, max-age=0");
/* 248 */       response.addDateHeader("Expires", 1L);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 256 */     OutputStream stream = this.updateContentLength ? createTemporaryOutputStream() : response.getOutputStream();
/* 257 */     Object value = filterModel(model);
/* 258 */     writeContent(stream, value, this.jsonPrefix);
/* 259 */     if (this.updateContentLength)
/* 260 */       writeToResponse(response, (ByteArrayOutputStream)stream);
/*     */   }
/*     */ 
/*     */   protected Object filterModel(Map<String, Object> model)
/*     */   {
/* 273 */     Map result = new HashMap(model.size());
/* 274 */     Set renderedAttributes = !CollectionUtils.isEmpty(this.modelKeys) ? this.modelKeys : model.keySet();
/* 275 */     for (Map.Entry entry : model.entrySet()) {
/* 276 */       if ((!(entry.getValue() instanceof BindingResult)) && (renderedAttributes.contains(entry.getKey()))) {
/* 277 */         result.put(entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/* 280 */     return (this.extractValueFromSingleKeyModel) && (result.size() == 1) ? result.values().iterator().next() : result;
/*     */   }
/*     */ 
/*     */   protected void writeContent(OutputStream stream, Object value, String jsonPrefix)
/*     */     throws IOException
/*     */   {
/* 292 */     JsonGenerator generator = this.objectMapper.getJsonFactory().createJsonGenerator(stream, this.encoding);
/*     */ 
/* 296 */     if (this.objectMapper.getSerializationConfig().isEnabled(SerializationConfig.Feature.INDENT_OUTPUT)) {
/* 297 */       generator.useDefaultPrettyPrinter();
/*     */     }
/*     */ 
/* 300 */     if (jsonPrefix != null) {
/* 301 */       generator.writeRaw(jsonPrefix);
/*     */     }
/* 303 */     this.objectMapper.writeValue(generator, value);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.json.MappingJacksonJsonView
 * JD-Core Version:    0.6.2
 */