/*    */ package org.springframework.web.servlet.view.tiles2;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.tiles.TilesApplicationContext;
/*    */ import org.apache.tiles.TilesException;
/*    */ import org.apache.tiles.context.TilesRequestContext;
/*    */ import org.apache.tiles.preparer.PreparerFactory;
/*    */ import org.apache.tiles.preparer.ViewPreparer;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ import org.springframework.web.servlet.DispatcherServlet;
/*    */ 
/*    */ public abstract class AbstractSpringPreparerFactory
/*    */   implements PreparerFactory
/*    */ {
/*    */   public ViewPreparer getPreparer(String name, TilesRequestContext context)
/*    */     throws TilesException
/*    */   {
/* 41 */     WebApplicationContext webApplicationContext = (WebApplicationContext)context.getRequestScope().get(DispatcherServlet.WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*    */ 
/* 43 */     if (webApplicationContext == null) {
/* 44 */       webApplicationContext = (WebApplicationContext)context.getApplicationContext().getApplicationScope().get(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*    */ 
/* 46 */       if (webApplicationContext == null) {
/* 47 */         throw new IllegalStateException("No WebApplicationContext found: no ContextLoaderListener registered?");
/*    */       }
/*    */     }
/* 50 */     return getPreparer(name, webApplicationContext);
/*    */   }
/*    */ 
/*    */   protected abstract ViewPreparer getPreparer(String paramString, WebApplicationContext paramWebApplicationContext)
/*    */     throws TilesException;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles2.AbstractSpringPreparerFactory
 * JD-Core Version:    0.6.2
 */