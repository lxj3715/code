/*    */ package org.springframework.web.servlet.view.tiles2;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.apache.tiles.TilesException;
/*    */ import org.apache.tiles.preparer.NoSuchPreparerException;
/*    */ import org.apache.tiles.preparer.PreparerException;
/*    */ import org.apache.tiles.preparer.ViewPreparer;
/*    */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ 
/*    */ public class SimpleSpringPreparerFactory extends AbstractSpringPreparerFactory
/*    */ {
/* 42 */   private final Map<String, ViewPreparer> sharedPreparers = new ConcurrentHashMap(16);
/*    */ 
/*    */   protected ViewPreparer getPreparer(String name, WebApplicationContext context)
/*    */     throws TilesException
/*    */   {
/* 48 */     ViewPreparer preparer = (ViewPreparer)this.sharedPreparers.get(name);
/* 49 */     if (preparer == null) {
/* 50 */       synchronized (this.sharedPreparers) {
/* 51 */         preparer = (ViewPreparer)this.sharedPreparers.get(name);
/* 52 */         if (preparer == null) {
/*    */           try {
/* 54 */             Class beanClass = context.getClassLoader().loadClass(name);
/* 55 */             if (!ViewPreparer.class.isAssignableFrom(beanClass)) {
/* 56 */               throw new PreparerException("Invalid preparer class [" + name + "]: does not implement ViewPreparer interface");
/*    */             }
/*    */ 
/* 59 */             preparer = (ViewPreparer)context.getAutowireCapableBeanFactory().createBean(beanClass);
/* 60 */             this.sharedPreparers.put(name, preparer);
/*    */           }
/*    */           catch (ClassNotFoundException ex) {
/* 63 */             throw new NoSuchPreparerException("Preparer class [" + name + "] not found", ex);
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 68 */     return preparer;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles2.SimpleSpringPreparerFactory
 * JD-Core Version:    0.6.2
 */