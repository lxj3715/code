/*    */ package org.springframework.web.servlet.view.tiles2;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import org.apache.tiles.context.TilesRequestContext;
/*    */ import org.apache.tiles.jsp.context.JspTilesRequestContext;
/*    */ import org.apache.tiles.locale.impl.DefaultLocaleResolver;
/*    */ import org.apache.tiles.servlet.context.ServletTilesRequestContext;
/*    */ import org.springframework.web.servlet.support.RequestContextUtils;
/*    */ 
/*    */ public class SpringLocaleResolver extends DefaultLocaleResolver
/*    */ {
/*    */   public Locale resolveLocale(TilesRequestContext context)
/*    */   {
/* 47 */     if ((context instanceof JspTilesRequestContext)) {
/* 48 */       PageContext pc = ((JspTilesRequestContext)context).getPageContext();
/* 49 */       return RequestContextUtils.getLocale((HttpServletRequest)pc.getRequest());
/*    */     }
/* 51 */     if ((context instanceof ServletTilesRequestContext)) {
/* 52 */       HttpServletRequest request = ((ServletTilesRequestContext)context).getRequest();
/* 53 */       if (request != null) {
/* 54 */         return RequestContextUtils.getLocale(request);
/*    */       }
/*    */     }
/* 57 */     return super.resolveLocale(context);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles2.SpringLocaleResolver
 * JD-Core Version:    0.6.2
 */