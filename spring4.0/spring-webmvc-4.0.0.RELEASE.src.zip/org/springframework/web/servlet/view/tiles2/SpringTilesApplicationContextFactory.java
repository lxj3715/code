/*     */ package org.springframework.web.servlet.view.tiles2;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.tiles.Initializable;
/*     */ import org.apache.tiles.TilesApplicationContext;
/*     */ import org.apache.tiles.context.AbstractTilesApplicationContextFactory;
/*     */ import org.apache.tiles.servlet.context.ServletTilesApplicationContext;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.web.context.support.ServletContextResourcePatternResolver;
/*     */ 
/*     */ public class SpringTilesApplicationContextFactory extends AbstractTilesApplicationContextFactory
/*     */   implements Initializable
/*     */ {
/*     */   private Map<String, String> params;
/*     */ 
/*     */   public void init(Map<String, String> params)
/*     */   {
/*  52 */     this.params = params;
/*     */   }
/*     */ 
/*     */   public TilesApplicationContext createApplicationContext(Object context)
/*     */   {
/*  57 */     return new SpringWildcardServletTilesApplicationContext((ServletContext)context, this.params);
/*     */   }
/*     */ 
/*     */   private static class SpringWildcardServletTilesApplicationContext extends ServletTilesApplicationContext
/*     */   {
/*     */     private final Map<String, String> mergedInitParams;
/*     */     private final ResourcePatternResolver resolver;
/*     */ 
/*     */     public SpringWildcardServletTilesApplicationContext(ServletContext servletContext, Map<String, String> params)
/*     */     {
/*  72 */       super();
/*  73 */       this.mergedInitParams = new LinkedHashMap();
/*  74 */       Enumeration initParamNames = servletContext.getInitParameterNames();
/*  75 */       while (initParamNames.hasMoreElements()) {
/*  76 */         String initParamName = (String)initParamNames.nextElement();
/*  77 */         this.mergedInitParams.put(initParamName, servletContext.getInitParameter(initParamName));
/*     */       }
/*  79 */       if (params != null) {
/*  80 */         this.mergedInitParams.putAll(params);
/*     */       }
/*  82 */       this.resolver = new ServletContextResourcePatternResolver(servletContext);
/*     */     }
/*     */ 
/*     */     public Map<String, String> getInitParams()
/*     */     {
/*  87 */       return this.mergedInitParams;
/*     */     }
/*     */ 
/*     */     public URL getResource(String path) throws IOException
/*     */     {
/*  92 */       URL retValue = null;
/*  93 */       Set urlSet = getResources(path);
/*  94 */       if ((urlSet != null) && (!urlSet.isEmpty())) {
/*  95 */         retValue = (URL)urlSet.iterator().next();
/*     */       }
/*  97 */       return retValue;
/*     */     }
/*     */ 
/*     */     public Set<URL> getResources(String path) throws IOException
/*     */     {
/* 102 */       Set urlSet = null;
/* 103 */       Resource[] resources = this.resolver.getResources(path);
/* 104 */       if ((resources != null) && (resources.length > 0)) {
/* 105 */         urlSet = new HashSet();
/* 106 */         for (Resource resource : resources) {
/* 107 */           urlSet.add(resource.getURL());
/*     */         }
/*     */       }
/* 110 */       return urlSet;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles2.SpringTilesApplicationContextFactory
 * JD-Core Version:    0.6.2
 */