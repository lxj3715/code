/*     */ package org.springframework.web.servlet.view.tiles2;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.jsp.JspApplicationContext;
/*     */ import javax.servlet.jsp.JspFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.tiles.TilesApplicationContext;
/*     */ import org.apache.tiles.TilesContainer;
/*     */ import org.apache.tiles.TilesException;
/*     */ import org.apache.tiles.awareness.TilesApplicationContextAware;
/*     */ import org.apache.tiles.context.TilesRequestContextFactory;
/*     */ import org.apache.tiles.definition.DefinitionsFactory;
/*     */ import org.apache.tiles.definition.DefinitionsFactoryException;
/*     */ import org.apache.tiles.definition.DefinitionsReader;
/*     */ import org.apache.tiles.definition.Refreshable;
/*     */ import org.apache.tiles.definition.dao.BaseLocaleUrlDefinitionDAO;
/*     */ import org.apache.tiles.definition.dao.CachingLocaleUrlDefinitionDAO;
/*     */ import org.apache.tiles.definition.digester.DigesterDefinitionsReader;
/*     */ import org.apache.tiles.evaluator.AttributeEvaluator;
/*     */ import org.apache.tiles.evaluator.el.ELAttributeEvaluator;
/*     */ import org.apache.tiles.evaluator.impl.DirectAttributeEvaluator;
/*     */ import org.apache.tiles.factory.AbstractTilesContainerFactory;
/*     */ import org.apache.tiles.factory.BasicTilesContainerFactory;
/*     */ import org.apache.tiles.impl.BasicTilesContainer;
/*     */ import org.apache.tiles.impl.mgmt.CachingTilesContainer;
/*     */ import org.apache.tiles.locale.LocaleResolver;
/*     */ import org.apache.tiles.preparer.BasicPreparerFactory;
/*     */ import org.apache.tiles.preparer.PreparerFactory;
/*     */ import org.apache.tiles.renderer.RendererFactory;
/*     */ import org.apache.tiles.servlet.context.ServletUtil;
/*     */ import org.apache.tiles.startup.BasicTilesInitializer;
/*     */ import org.apache.tiles.startup.TilesInitializer;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ public class TilesConfigurer
/*     */   implements ServletContextAware, InitializingBean, DisposableBean
/*     */ {
/* 119 */   private static final boolean tilesElPresent = ClassUtils.isPresent("org.apache.tiles.evaluator.el.ELAttributeEvaluator", TilesConfigurer.class
/* 120 */     .getClassLoader());
/*     */ 
/* 122 */   private static final boolean tiles22Present = ClassUtils.isPresent("org.apache.tiles.evaluator.AttributeEvaluatorFactory", TilesConfigurer.class
/* 123 */     .getClassLoader());
/*     */ 
/* 126 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private TilesInitializer tilesInitializer;
/* 130 */   private boolean overrideLocaleResolver = false;
/*     */   private String[] definitions;
/* 134 */   private boolean checkRefresh = false;
/*     */ 
/* 136 */   private boolean validateDefinitions = true;
/*     */   private Class<? extends DefinitionsFactory> definitionsFactoryClass;
/*     */   private Class<? extends PreparerFactory> preparerFactoryClass;
/* 142 */   private boolean useMutableTilesContainer = false;
/*     */ 
/* 144 */   private final Map<String, String> tilesPropertyMap = new HashMap();
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public TilesConfigurer()
/*     */   {
/* 151 */     StringBuilder sb = new StringBuilder("org.apache.tiles.servlet.context.ServletTilesRequestContextFactory");
/* 152 */     addClassNameIfPresent(sb, "org.apache.tiles.portlet.context.PortletTilesRequestContextFactory");
/* 153 */     addClassNameIfPresent(sb, "org.apache.tiles.jsp.context.JspTilesRequestContextFactory");
/* 154 */     this.tilesPropertyMap.put("org.apache.tiles.context.ChainedTilesRequestContextFactory.FACTORY_CLASS_NAMES", sb.toString());
/*     */ 
/* 157 */     this.tilesPropertyMap.put("org.apache.tiles.context.AbstractTilesApplicationContextFactory", SpringTilesApplicationContextFactory.class
/* 158 */       .getName());
/* 159 */     this.tilesPropertyMap.put("org.apache.tiles.locale.LocaleResolver", SpringLocaleResolver.class
/* 160 */       .getName());
/* 161 */     this.tilesPropertyMap.put("org.apache.tiles.preparer.PreparerFactory", BasicPreparerFactory.class
/* 162 */       .getName());
/* 163 */     this.tilesPropertyMap.put("org.apache.tiles.factory.TilesContainerFactory.MUTABLE", 
/* 164 */       Boolean.toString(false));
/*     */   }
/*     */ 
/*     */   private static void addClassNameIfPresent(StringBuilder sb, String className)
/*     */   {
/* 168 */     if (ClassUtils.isPresent(className, TilesConfigurer.class.getClassLoader()))
/* 169 */       sb.append(',').append(className);
/*     */   }
/*     */ 
/*     */   public void setTilesInitializer(TilesInitializer tilesInitializer)
/*     */   {
/* 183 */     this.tilesInitializer = tilesInitializer;
/*     */   }
/*     */ 
/*     */   public void setCompleteAutoload(boolean completeAutoload)
/*     */   {
/* 197 */     if (completeAutoload) {
/*     */       try {
/* 199 */         Class clazz = getClass().getClassLoader().loadClass("org.apache.tiles.extras.complete.CompleteAutoloadTilesInitializer");
/*     */ 
/* 201 */         this.tilesInitializer = ((TilesInitializer)clazz.newInstance());
/*     */       }
/*     */       catch (Exception ex) {
/* 204 */         throw new IllegalStateException("Tiles-Extras 2.2 not available", ex);
/*     */       }
/*     */     }
/*     */     else {
/* 208 */       this.tilesInitializer = null;
/*     */     }
/* 210 */     this.overrideLocaleResolver = completeAutoload;
/*     */   }
/*     */ 
/*     */   public void setDefinitions(String[] definitions)
/*     */   {
/* 218 */     this.definitions = definitions;
/* 219 */     if (definitions != null) {
/* 220 */       String defs = StringUtils.arrayToCommaDelimitedString(definitions);
/* 221 */       if (this.logger.isInfoEnabled()) {
/* 222 */         this.logger.info("TilesConfigurer: adding definitions [" + defs + "]");
/*     */       }
/* 224 */       this.tilesPropertyMap.put("org.apache.tiles.definition.DefinitionsFactory.DEFINITIONS_CONFIG", defs);
/*     */     }
/*     */     else {
/* 227 */       this.tilesPropertyMap.remove("org.apache.tiles.definition.DefinitionsFactory.DEFINITIONS_CONFIG");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setCheckRefresh(boolean checkRefresh)
/*     */   {
/* 236 */     this.checkRefresh = checkRefresh;
/* 237 */     this.tilesPropertyMap.put("org.apache.tiles.definition.dao.LocaleUrlDefinitionDAO.CHECK_REFRESH", 
/* 238 */       Boolean.toString(checkRefresh));
/*     */   }
/*     */ 
/*     */   public void setValidateDefinitions(boolean validateDefinitions)
/*     */   {
/* 245 */     this.validateDefinitions = validateDefinitions;
/* 246 */     this.tilesPropertyMap.put("org.apache.tiles.definition.digester.DigesterDefinitionsReader.PARSER_VALIDATE", 
/* 247 */       Boolean.toString(validateDefinitions));
/*     */   }
/*     */ 
/*     */   public void setDefinitionsFactoryClass(Class<? extends DefinitionsFactory> definitionsFactoryClass)
/*     */   {
/* 260 */     this.definitionsFactoryClass = definitionsFactoryClass;
/* 261 */     this.tilesPropertyMap.put("org.apache.tiles.definition.DefinitionsFactory", definitionsFactoryClass
/* 262 */       .getName());
/*     */   }
/*     */ 
/*     */   public void setPreparerFactoryClass(Class<? extends PreparerFactory> preparerFactoryClass)
/*     */   {
/* 285 */     this.preparerFactoryClass = preparerFactoryClass;
/* 286 */     this.tilesPropertyMap.put("org.apache.tiles.preparer.PreparerFactory", preparerFactoryClass
/* 287 */       .getName());
/*     */   }
/*     */ 
/*     */   public void setUseMutableTilesContainer(boolean useMutableTilesContainer)
/*     */   {
/* 297 */     this.useMutableTilesContainer = useMutableTilesContainer;
/* 298 */     this.tilesPropertyMap.put("org.apache.tiles.factory.TilesContainerFactory.MUTABLE", 
/* 299 */       Boolean.toString(useMutableTilesContainer));
/*     */   }
/*     */ 
/*     */   public void setTilesProperties(Properties tilesProperties)
/*     */   {
/* 309 */     CollectionUtils.mergePropertiesIntoMap(tilesProperties, this.tilesPropertyMap);
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 314 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws TilesException
/*     */   {
/* 326 */     boolean activateEl = false;
/* 327 */     if (tilesElPresent) {
/* 328 */       activateEl = new JspExpressionChecker(null).isExpressionFactoryAvailable();
/* 329 */       if (!this.tilesPropertyMap.containsKey("org.apache.tiles.evaluator.AttributeEvaluator")) {
/* 330 */         this.tilesPropertyMap.put("org.apache.tiles.evaluator.AttributeEvaluator", activateEl ? "org.apache.tiles.evaluator.el.ELAttributeEvaluator" : DirectAttributeEvaluator.class
/* 331 */           .getName());
/*     */       }
/*     */     }
/*     */ 
/* 335 */     SpringTilesApplicationContextFactory factory = new SpringTilesApplicationContextFactory();
/* 336 */     factory.init(this.tilesPropertyMap);
/* 337 */     TilesApplicationContext preliminaryContext = factory.createApplicationContext(this.servletContext);
/* 338 */     if (this.tilesInitializer == null) {
/* 339 */       this.tilesInitializer = createTilesInitializer();
/*     */     }
/* 341 */     this.tilesInitializer.initialize(preliminaryContext);
/*     */ 
/* 343 */     if (this.overrideLocaleResolver)
/*     */     {
/* 347 */       this.logger.debug("Registering Tiles 2.2 LocaleResolver for complete-autoload setup");
/*     */       try {
/* 349 */         BasicTilesContainer container = (BasicTilesContainer)ServletUtil.getContainer(this.servletContext);
/* 350 */         DefinitionsFactory definitionsFactory = container.getDefinitionsFactory();
/* 351 */         Method setter = definitionsFactory.getClass().getMethod("setLocaleResolver", new Class[] { LocaleResolver.class });
/* 352 */         setter.invoke(definitionsFactory, new Object[] { new SpringLocaleResolver() });
/*     */       }
/*     */       catch (Exception ex) {
/* 355 */         throw new IllegalStateException("Cannot override LocaleResolver with SpringLocaleResolver", ex);
/*     */       }
/*     */     }
/*     */ 
/* 359 */     if ((activateEl) && ((this.tilesInitializer instanceof SpringTilesInitializer)))
/*     */     {
/* 363 */       BasicTilesContainer container = (BasicTilesContainer)ServletUtil.getContainer(this.servletContext);
/* 364 */       new TilesElActivator(null).registerEvaluator(container);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected TilesInitializer createTilesInitializer()
/*     */   {
/* 374 */     return tiles22Present ? new SpringTilesInitializer(null) : new BasicTilesInitializer();
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws TilesException
/*     */   {
/*     */     try
/*     */     {
/* 385 */       ReflectionUtils.invokeMethod(TilesInitializer.class.getMethod("destroy", new Class[0]), this.tilesInitializer);
/*     */     }
/*     */     catch (NoSuchMethodException ex)
/*     */     {
/* 389 */       ServletUtil.setContainer(this.servletContext, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 117 */     if (ClassUtils.isPresent("javax.servlet.jsp.JspApplicationContext", TilesConfigurer.class
/* 118 */       .getClassLoader()));
/*     */   }
/*     */ 
/*     */   private class TilesElActivator
/*     */   {
/*     */     private TilesElActivator()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void registerEvaluator(BasicTilesContainer container)
/*     */     {
/* 529 */       TilesConfigurer.this.logger.debug("Registering Tiles 2.2 AttributeEvaluatorFactory for JSP 2.1");
/*     */       try {
/* 531 */         ClassLoader cl = TilesElActivator.class.getClassLoader();
/* 532 */         Class aef = cl.loadClass("org.apache.tiles.evaluator.AttributeEvaluatorFactory");
/* 533 */         Class baef = cl.loadClass("org.apache.tiles.evaluator.BasicAttributeEvaluatorFactory");
/* 534 */         Constructor baefCtor = baef.getConstructor(new Class[] { AttributeEvaluator.class });
/* 535 */         ELAttributeEvaluator evaluator = new ELAttributeEvaluator();
/* 536 */         evaluator.setApplicationContext(container.getApplicationContext());
/* 537 */         evaluator.init(new HashMap());
/* 538 */         Object baefValue = baefCtor.newInstance(new Object[] { evaluator });
/* 539 */         Method setter = container.getClass().getMethod("setAttributeEvaluatorFactory", new Class[] { aef });
/* 540 */         setter.invoke(container, new Object[] { baefValue });
/* 541 */         Method getRequestContextFactory = BasicTilesContainer.class.getDeclaredMethod("getRequestContextFactory", new Class[0]);
/* 542 */         getRequestContextFactory.setAccessible(true);
/* 543 */         Method createRendererFactory = BasicTilesContainerFactory.class.getDeclaredMethod("createRendererFactory", new Class[] { TilesApplicationContext.class, TilesRequestContextFactory.class, TilesContainer.class, aef });
/*     */ 
/* 545 */         createRendererFactory.setAccessible(true);
/* 546 */         BasicTilesContainerFactory tcf = new BasicTilesContainerFactory();
/* 547 */         RendererFactory rendererFactory = (RendererFactory)createRendererFactory.invoke(tcf, new Object[] { container
/* 548 */           .getApplicationContext(), getRequestContextFactory.invoke(container, new Object[0]), container, baefValue });
/*     */ 
/* 550 */         container.setRendererFactory(rendererFactory);
/*     */       }
/*     */       catch (Exception ex) {
/* 553 */         throw new IllegalStateException("Cannot activate ELAttributeEvaluator", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class JspExpressionChecker
/*     */   {
/*     */     private JspExpressionChecker()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean isExpressionFactoryAvailable()
/*     */     {
/*     */       try
/*     */       {
/* 511 */         JspFactory factory = JspFactory.getDefaultFactory();
/* 512 */         if ((factory != null) && 
/* 513 */           (factory
/* 513 */           .getJspApplicationContext(TilesConfigurer.this.servletContext)
/* 513 */           .getExpressionFactory() != null)) {
/* 514 */           TilesConfigurer.this.logger.info("Found JSP 2.1 ExpressionFactory");
/* 515 */           return true;
/*     */         }
/*     */       }
/*     */       catch (Throwable ex) {
/* 519 */         TilesConfigurer.this.logger.warn("Could not obtain JSP 2.1 ExpressionFactory", ex);
/*     */       }
/* 521 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class SpringTilesContainerFactory extends BasicTilesContainerFactory
/*     */   {
/*     */     private SpringTilesContainerFactory()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected BasicTilesContainer instantiateContainer(TilesApplicationContext context)
/*     */     {
/* 407 */       return TilesConfigurer.this.useMutableTilesContainer ? new CachingTilesContainer() : new BasicTilesContainer();
/*     */     }
/*     */ 
/*     */     protected void registerRequestContextFactory(String className, List<TilesRequestContextFactory> factories, TilesRequestContextFactory parent)
/*     */     {
/* 414 */       if (ClassUtils.isPresent(className, TilesConfigurer.class.getClassLoader()))
/* 415 */         super.registerRequestContextFactory(className, factories, parent);
/*     */     }
/*     */ 
/*     */     protected List<URL> getSourceURLs(TilesApplicationContext applicationContext, TilesRequestContextFactory contextFactory)
/*     */     {
/* 422 */       if (TilesConfigurer.this.definitions != null) {
/*     */         try {
/* 424 */           List result = new LinkedList();
/* 425 */           for (String definition : TilesConfigurer.this.definitions) {
/* 426 */             result.addAll(applicationContext.getResources(definition));
/*     */           }
/* 428 */           return result;
/*     */         }
/*     */         catch (IOException ex) {
/* 431 */           throw new DefinitionsFactoryException("Cannot load definition URLs", ex);
/*     */         }
/*     */       }
/*     */ 
/* 435 */       return super.getSourceURLs(applicationContext, contextFactory);
/*     */     }
/*     */ 
/*     */     protected BaseLocaleUrlDefinitionDAO instantiateLocaleDefinitionDao(TilesApplicationContext applicationContext, TilesRequestContextFactory contextFactory, LocaleResolver resolver)
/*     */     {
/* 442 */       BaseLocaleUrlDefinitionDAO dao = super.instantiateLocaleDefinitionDao(applicationContext, contextFactory, resolver);
/*     */ 
/* 444 */       if ((TilesConfigurer.this.checkRefresh) && ((dao instanceof CachingLocaleUrlDefinitionDAO))) {
/* 445 */         ((CachingLocaleUrlDefinitionDAO)dao).setCheckRefresh(TilesConfigurer.this.checkRefresh);
/*     */       }
/* 447 */       return dao;
/*     */     }
/*     */ 
/*     */     protected DefinitionsReader createDefinitionsReader(TilesApplicationContext applicationContext, TilesRequestContextFactory contextFactory)
/*     */     {
/* 453 */       DigesterDefinitionsReader reader = new DigesterDefinitionsReader();
/* 454 */       if (!TilesConfigurer.this.validateDefinitions) {
/* 455 */         Map map = new HashMap();
/* 456 */         map.put("org.apache.tiles.definition.digester.DigesterDefinitionsReader.PARSER_VALIDATE", Boolean.FALSE.toString());
/* 457 */         reader.init(map);
/*     */       }
/* 459 */       return reader;
/*     */     }
/*     */ 
/*     */     protected DefinitionsFactory createDefinitionsFactory(TilesApplicationContext applicationContext, TilesRequestContextFactory contextFactory, LocaleResolver resolver)
/*     */     {
/* 465 */       if (TilesConfigurer.this.definitionsFactoryClass != null) {
/* 466 */         DefinitionsFactory factory = (DefinitionsFactory)BeanUtils.instantiate(TilesConfigurer.this.definitionsFactoryClass);
/* 467 */         if ((factory instanceof TilesApplicationContextAware)) {
/* 468 */           ((TilesApplicationContextAware)factory).setApplicationContext(applicationContext);
/*     */         }
/* 470 */         BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(factory);
/* 471 */         if (bw.isWritableProperty("localeResolver")) {
/* 472 */           bw.setPropertyValue("localeResolver", resolver);
/*     */         }
/* 474 */         if (bw.isWritableProperty("definitionDAO")) {
/* 475 */           bw.setPropertyValue("definitionDAO", 
/* 476 */             createLocaleDefinitionDao(applicationContext, contextFactory, resolver));
/*     */         }
/*     */ 
/* 478 */         if ((factory instanceof Refreshable)) {
/* 479 */           ((Refreshable)factory).refresh();
/*     */         }
/* 481 */         return factory;
/*     */       }
/*     */ 
/* 484 */       return super.createDefinitionsFactory(applicationContext, contextFactory, resolver);
/*     */     }
/*     */ 
/*     */     protected PreparerFactory createPreparerFactory(TilesApplicationContext applicationContext, TilesRequestContextFactory contextFactory)
/*     */     {
/* 491 */       if (TilesConfigurer.this.preparerFactoryClass != null) {
/* 492 */         return (PreparerFactory)BeanUtils.instantiate(TilesConfigurer.this.preparerFactoryClass);
/*     */       }
/*     */ 
/* 495 */       return super.createPreparerFactory(applicationContext, contextFactory);
/*     */     }
/*     */ 
/*     */     protected LocaleResolver createLocaleResolver(TilesApplicationContext applicationContext, TilesRequestContextFactory contextFactory)
/*     */     {
/* 502 */       return new SpringLocaleResolver();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class SpringTilesInitializer extends BasicTilesInitializer
/*     */   {
/*     */     private SpringTilesInitializer()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected AbstractTilesContainerFactory createContainerFactory(TilesApplicationContext context)
/*     */     {
/* 398 */       return new TilesConfigurer.SpringTilesContainerFactory(TilesConfigurer.this, null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles2.TilesConfigurer
 * JD-Core Version:    0.6.2
 */