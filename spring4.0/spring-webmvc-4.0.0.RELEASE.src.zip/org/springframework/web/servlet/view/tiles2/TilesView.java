/*    */ package org.springframework.web.servlet.view.tiles2;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.tiles.TilesApplicationContext;
/*    */ import org.apache.tiles.TilesContainer;
/*    */ import org.apache.tiles.context.TilesRequestContext;
/*    */ import org.apache.tiles.definition.DefinitionsFactory;
/*    */ import org.apache.tiles.impl.BasicTilesContainer;
/*    */ import org.apache.tiles.servlet.context.ServletTilesApplicationContext;
/*    */ import org.apache.tiles.servlet.context.ServletTilesRequestContext;
/*    */ import org.apache.tiles.servlet.context.ServletUtil;
/*    */ import org.springframework.web.servlet.support.JstlUtils;
/*    */ import org.springframework.web.servlet.support.RequestContext;
/*    */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*    */ 
/*    */ public class TilesView extends AbstractUrlBasedView
/*    */ {
/*    */   public boolean checkResource(final Locale locale)
/*    */     throws Exception
/*    */   {
/* 59 */     TilesContainer container = ServletUtil.getContainer(getServletContext());
/* 60 */     if (!(container instanceof BasicTilesContainer))
/*    */     {
/* 62 */       return true;
/*    */     }
/* 64 */     BasicTilesContainer basicContainer = (BasicTilesContainer)container;
/* 65 */     TilesApplicationContext appContext = new ServletTilesApplicationContext(getServletContext());
/* 66 */     TilesRequestContext requestContext = new ServletTilesRequestContext(appContext, null, null)
/*    */     {
/*    */       public Locale getRequestLocale() {
/* 69 */         return locale;
/*    */       }
/*    */     };
/* 72 */     return basicContainer.getDefinitionsFactory().getDefinition(getUrl(), requestContext) != null;
/*    */   }
/*    */ 
/*    */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*    */     throws Exception
/*    */   {
/* 79 */     ServletContext servletContext = getServletContext();
/* 80 */     TilesContainer container = ServletUtil.getContainer(servletContext);
/* 81 */     if (container == null) {
/* 82 */       throw new ServletException("Tiles container is not initialized. Have you added a TilesConfigurer to your web application context?");
/*    */     }
/*    */ 
/* 86 */     exposeModelAsRequestAttributes(model, request);
/* 87 */     JstlUtils.exposeLocalizationContext(new RequestContext(request, servletContext));
/* 88 */     container.render(getUrl(), new Object[] { request, response });
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles2.TilesView
 * JD-Core Version:    0.6.2
 */