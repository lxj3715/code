/*    */ package org.springframework.web.servlet.view.tiles2;
/*    */ 
/*    */ import org.springframework.web.servlet.view.UrlBasedViewResolver;
/*    */ 
/*    */ public class TilesViewResolver extends UrlBasedViewResolver
/*    */ {
/*    */   public TilesViewResolver()
/*    */   {
/* 43 */     setViewClass(requiredViewClass());
/*    */   }
/*    */ 
/*    */   protected Class<?> requiredViewClass()
/*    */   {
/* 51 */     return TilesView.class;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles2.TilesViewResolver
 * JD-Core Version:    0.6.2
 */