/*    */ package org.springframework.web.servlet.view.tiles3;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.apache.tiles.TilesException;
/*    */ import org.apache.tiles.preparer.PreparerException;
/*    */ import org.apache.tiles.preparer.ViewPreparer;
/*    */ import org.apache.tiles.preparer.factory.NoSuchPreparerException;
/*    */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ 
/*    */ public class SimpleSpringPreparerFactory extends AbstractSpringPreparerFactory
/*    */ {
/* 41 */   private final Map<String, ViewPreparer> sharedPreparers = new ConcurrentHashMap(16);
/*    */ 
/*    */   protected ViewPreparer getPreparer(String name, WebApplicationContext context)
/*    */     throws TilesException
/*    */   {
/* 47 */     ViewPreparer preparer = (ViewPreparer)this.sharedPreparers.get(name);
/* 48 */     if (preparer == null) {
/* 49 */       synchronized (this.sharedPreparers) {
/* 50 */         preparer = (ViewPreparer)this.sharedPreparers.get(name);
/* 51 */         if (preparer == null) {
/*    */           try {
/* 53 */             Class beanClass = context.getClassLoader().loadClass(name);
/* 54 */             if (!ViewPreparer.class.isAssignableFrom(beanClass)) {
/* 55 */               throw new PreparerException("Invalid preparer class [" + name + "]: does not implement ViewPreparer interface");
/*    */             }
/*    */ 
/* 58 */             preparer = (ViewPreparer)context.getAutowireCapableBeanFactory().createBean(beanClass);
/* 59 */             this.sharedPreparers.put(name, preparer);
/*    */           }
/*    */           catch (ClassNotFoundException ex) {
/* 62 */             throw new NoSuchPreparerException("Preparer class [" + name + "] not found", ex);
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 67 */     return preparer;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles3.SimpleSpringPreparerFactory
 * JD-Core Version:    0.6.2
 */