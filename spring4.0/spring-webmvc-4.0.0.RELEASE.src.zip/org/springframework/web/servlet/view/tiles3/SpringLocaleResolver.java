/*    */ package org.springframework.web.servlet.view.tiles3;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.tiles.locale.impl.DefaultLocaleResolver;
/*    */ import org.apache.tiles.request.Request;
/*    */ import org.apache.tiles.request.servlet.NotAServletEnvironmentException;
/*    */ import org.apache.tiles.request.servlet.ServletRequest;
/*    */ import org.apache.tiles.request.servlet.ServletUtil;
/*    */ import org.springframework.web.servlet.support.RequestContextUtils;
/*    */ 
/*    */ public class SpringLocaleResolver extends DefaultLocaleResolver
/*    */ {
/*    */   public Locale resolveLocale(Request request)
/*    */   {
/*    */     try
/*    */     {
/* 42 */       HttpServletRequest servletRequest = ServletUtil.getServletRequest(request).getRequest();
/* 43 */       if (servletRequest != null) {
/* 44 */         return RequestContextUtils.getLocale(servletRequest);
/*    */       }
/*    */     }
/*    */     catch (NotAServletEnvironmentException e)
/*    */     {
/*    */     }
/* 50 */     return super.resolveLocale(request);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles3.SpringLocaleResolver
 * JD-Core Version:    0.6.2
 */