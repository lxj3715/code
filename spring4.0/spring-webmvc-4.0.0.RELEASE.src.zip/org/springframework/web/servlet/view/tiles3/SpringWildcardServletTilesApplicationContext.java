/*    */ package org.springframework.web.servlet.view.tiles3;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.Locale;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.apache.tiles.request.ApplicationResource;
/*    */ import org.apache.tiles.request.locale.URLApplicationResource;
/*    */ import org.apache.tiles.request.servlet.ServletApplicationContext;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.support.ResourcePatternResolver;
/*    */ import org.springframework.web.context.support.ServletContextResourcePatternResolver;
/*    */ 
/*    */ public class SpringWildcardServletTilesApplicationContext extends ServletApplicationContext
/*    */ {
/*    */   protected ResourcePatternResolver resolver;
/*    */ 
/*    */   public SpringWildcardServletTilesApplicationContext(ServletContext servletContext)
/*    */   {
/* 53 */     super(servletContext);
/* 54 */     this.resolver = new ServletContextResourcePatternResolver(servletContext);
/*    */   }
/*    */ 
/*    */   public ApplicationResource getResource(String localePath)
/*    */   {
/* 59 */     ApplicationResource retValue = null;
/* 60 */     Collection urlSet = getResources(localePath);
/* 61 */     if ((urlSet != null) && (!urlSet.isEmpty())) {
/* 62 */       retValue = (ApplicationResource)urlSet.iterator().next();
/*    */     }
/* 64 */     return retValue;
/*    */   }
/*    */ 
/*    */   public ApplicationResource getResource(ApplicationResource base, Locale locale)
/*    */   {
/* 69 */     ApplicationResource retValue = null;
/* 70 */     Collection urlSet = getResources(base.getLocalePath(locale));
/* 71 */     if ((urlSet != null) && (!urlSet.isEmpty())) {
/* 72 */       retValue = (ApplicationResource)urlSet.iterator().next();
/*    */     }
/* 74 */     return retValue;
/*    */   }
/*    */ 
/*    */   public Collection<ApplicationResource> getResources(String path)
/*    */   {
/*    */     try
/*    */     {
/* 81 */       resources = this.resolver.getResources(path);
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/*    */       Resource[] resources;
/* 83 */       return Collections.emptyList();
/*    */     }
/*    */     Resource[] resources;
/* 85 */     Collection resourceList = new ArrayList();
/* 86 */     if ((resources != null) && (resources.length > 0)) {
/* 87 */       for (int i = 0; i < resources.length; i++) {
/*    */         try
/*    */         {
/* 90 */           URL url = resources[i].getURL();
/* 91 */           resourceList.add(new URLApplicationResource(url.toExternalForm(), url));
/*    */         }
/*    */         catch (IOException e) {
/* 94 */           throw new IllegalArgumentException("no URL for " + resources[i].toString(), e);
/*    */         }
/*    */       }
/*    */     }
/* 98 */     return resourceList;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles3.SpringWildcardServletTilesApplicationContext
 * JD-Core Version:    0.6.2
 */