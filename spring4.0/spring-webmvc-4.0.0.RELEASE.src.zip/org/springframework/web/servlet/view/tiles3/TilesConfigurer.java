/*     */ package org.springframework.web.servlet.view.tiles3;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.el.ArrayELResolver;
/*     */ import javax.el.BeanELResolver;
/*     */ import javax.el.CompositeELResolver;
/*     */ import javax.el.ListELResolver;
/*     */ import javax.el.MapELResolver;
/*     */ import javax.el.ResourceBundleELResolver;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.jsp.JspApplicationContext;
/*     */ import javax.servlet.jsp.JspFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.tiles.TilesContainer;
/*     */ import org.apache.tiles.TilesException;
/*     */ import org.apache.tiles.definition.DefinitionsFactory;
/*     */ import org.apache.tiles.definition.DefinitionsReader;
/*     */ import org.apache.tiles.definition.dao.BaseLocaleUrlDefinitionDAO;
/*     */ import org.apache.tiles.definition.dao.CachingLocaleUrlDefinitionDAO;
/*     */ import org.apache.tiles.definition.digester.DigesterDefinitionsReader;
/*     */ import org.apache.tiles.el.ELAttributeEvaluator;
/*     */ import org.apache.tiles.el.ScopeELResolver;
/*     */ import org.apache.tiles.el.TilesContextBeanELResolver;
/*     */ import org.apache.tiles.el.TilesContextELResolver;
/*     */ import org.apache.tiles.evaluator.AttributeEvaluator;
/*     */ import org.apache.tiles.evaluator.AttributeEvaluatorFactory;
/*     */ import org.apache.tiles.evaluator.BasicAttributeEvaluatorFactory;
/*     */ import org.apache.tiles.evaluator.impl.DirectAttributeEvaluator;
/*     */ import org.apache.tiles.extras.complete.CompleteAutoloadTilesContainerFactory;
/*     */ import org.apache.tiles.extras.complete.CompleteAutoloadTilesInitializer;
/*     */ import org.apache.tiles.factory.AbstractTilesContainerFactory;
/*     */ import org.apache.tiles.factory.BasicTilesContainerFactory;
/*     */ import org.apache.tiles.impl.BasicTilesContainer;
/*     */ import org.apache.tiles.impl.mgmt.CachingTilesContainer;
/*     */ import org.apache.tiles.locale.LocaleResolver;
/*     */ import org.apache.tiles.preparer.factory.PreparerFactory;
/*     */ import org.apache.tiles.request.ApplicationContext;
/*     */ import org.apache.tiles.request.ApplicationContextAware;
/*     */ import org.apache.tiles.request.ApplicationResource;
/*     */ import org.apache.tiles.startup.DefaultTilesInitializer;
/*     */ import org.apache.tiles.startup.TilesInitializer;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ public class TilesConfigurer
/*     */   implements ServletContextAware, InitializingBean, DisposableBean
/*     */ {
/* 110 */   private static final boolean tilesElPresent = (ClassUtils.isPresent("javax.servlet.jsp.JspApplicationContext", TilesConfigurer.class
/* 110 */     .getClassLoader())) && 
/* 111 */     (ClassUtils.isPresent("org.apache.tiles.el.ELAttributeEvaluator", TilesConfigurer.class
/* 111 */     .getClassLoader()));
/*     */ 
/* 113 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private TilesInitializer tilesInitializer;
/*     */   private String[] definitions;
/* 119 */   private boolean checkRefresh = false;
/*     */ 
/* 121 */   private boolean validateDefinitions = true;
/*     */   private Class<? extends DefinitionsFactory> definitionsFactoryClass;
/*     */   private Class<? extends PreparerFactory> preparerFactoryClass;
/* 127 */   private boolean useMutableTilesContainer = false;
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public void setTilesInitializer(TilesInitializer tilesInitializer)
/*     */   {
/* 143 */     this.tilesInitializer = tilesInitializer;
/*     */   }
/*     */ 
/*     */   public void setCompleteAutoload(boolean completeAutoload)
/*     */   {
/* 157 */     if (completeAutoload)
/*     */       try {
/* 159 */         this.tilesInitializer = new SpringCompleteAutoloadTilesInitializer(null);
/*     */       }
/*     */       catch (Exception ex) {
/* 162 */         throw new IllegalStateException("tiles-extras 3.x not available", ex);
/*     */       }
/*     */     else
/* 165 */       this.tilesInitializer = null;
/*     */   }
/*     */ 
/*     */   public void setDefinitions(String[] definitions)
/*     */   {
/* 174 */     this.definitions = definitions;
/*     */   }
/*     */ 
/*     */   public void setCheckRefresh(boolean checkRefresh)
/*     */   {
/* 182 */     this.checkRefresh = checkRefresh;
/*     */   }
/*     */ 
/*     */   public void setValidateDefinitions(boolean validateDefinitions)
/*     */   {
/* 189 */     this.validateDefinitions = validateDefinitions;
/*     */   }
/*     */ 
/*     */   public void setDefinitionsFactoryClass(Class<? extends DefinitionsFactory> definitionsFactoryClass)
/*     */   {
/* 202 */     this.definitionsFactoryClass = definitionsFactoryClass;
/*     */   }
/*     */ 
/*     */   public void setPreparerFactoryClass(Class<? extends PreparerFactory> preparerFactoryClass)
/*     */   {
/* 225 */     this.preparerFactoryClass = preparerFactoryClass;
/*     */   }
/*     */ 
/*     */   public void setUseMutableTilesContainer(boolean useMutableTilesContainer)
/*     */   {
/* 235 */     this.useMutableTilesContainer = useMutableTilesContainer;
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 240 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws TilesException
/*     */   {
/* 250 */     ApplicationContext preliminaryContext = new SpringWildcardServletTilesApplicationContext(this.servletContext);
/* 251 */     if (this.tilesInitializer == null) {
/* 252 */       this.tilesInitializer = new SpringTilesInitializer(null);
/*     */     }
/* 254 */     this.tilesInitializer.initialize(preliminaryContext);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws TilesException
/*     */   {
/* 263 */     this.tilesInitializer.destroy();
/*     */   }
/*     */ 
/*     */   private static class CompositeELResolverImpl extends CompositeELResolver
/*     */   {
/*     */     public CompositeELResolverImpl()
/*     */     {
/* 416 */       add(new ScopeELResolver());
/* 417 */       add(new TilesContextELResolver(new TilesContextBeanELResolver()));
/* 418 */       add(new TilesContextBeanELResolver());
/* 419 */       add(new ArrayELResolver(false));
/* 420 */       add(new ListELResolver(false));
/* 421 */       add(new MapELResolver(false));
/* 422 */       add(new ResourceBundleELResolver());
/* 423 */       add(new BeanELResolver(false));
/*     */     }
/*     */   }
/*     */ 
/*     */   private class TilesElActivator
/*     */   {
/*     */     private TilesElActivator()
/*     */     {
/*     */     }
/*     */ 
/*     */     public AttributeEvaluator createEvaluator()
/*     */     {
/*     */       try
/*     */       {
/* 397 */         JspFactory factory = JspFactory.getDefaultFactory();
/* 398 */         if ((factory != null) && (factory.getJspApplicationContext(TilesConfigurer.this.servletContext).getExpressionFactory() != null)) {
/* 399 */           TilesConfigurer.this.logger.info("Found JSP 2.1 ExpressionFactory");
/* 400 */           ELAttributeEvaluator evaluator = new ELAttributeEvaluator();
/* 401 */           evaluator.setExpressionFactory(factory.getJspApplicationContext(TilesConfigurer.this.servletContext).getExpressionFactory());
/* 402 */           evaluator.setResolver(new TilesConfigurer.CompositeELResolverImpl());
/* 403 */           return evaluator;
/*     */         }
/*     */       }
/*     */       catch (Throwable ex) {
/* 407 */         TilesConfigurer.this.logger.warn("Could not obtain JSP 2.1 ExpressionFactory", ex);
/*     */       }
/* 409 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class SpringCompleteAutoloadTilesContainerFactory extends CompleteAutoloadTilesContainerFactory
/*     */   {
/*     */     private SpringCompleteAutoloadTilesContainerFactory()
/*     */     {
/*     */     }
/*     */ 
/*     */     public TilesContainer createContainer(ApplicationContext applicationContext)
/*     */     {
/* 381 */       CachingTilesContainer cachingContainer = (CachingTilesContainer)super.createContainer(applicationContext);
/* 382 */       BasicTilesContainer tilesContainer = (BasicTilesContainer)cachingContainer.getWrappedContainer();
/* 383 */       BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(tilesContainer.getDefinitionsFactory());
/* 384 */       if (bw.isWritableProperty("localeResolver")) {
/* 385 */         bw.setPropertyValue("localeResolver", new SpringLocaleResolver());
/*     */       }
/* 387 */       return tilesContainer;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class SpringCompleteAutoloadTilesInitializer extends CompleteAutoloadTilesInitializer
/*     */   {
/*     */     private SpringCompleteAutoloadTilesInitializer()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected AbstractTilesContainerFactory createContainerFactory(ApplicationContext context)
/*     */     {
/* 373 */       return new TilesConfigurer.SpringCompleteAutoloadTilesContainerFactory(TilesConfigurer.this, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class SpringTilesContainerFactory extends BasicTilesContainerFactory
/*     */   {
/*     */     private SpringTilesContainerFactory()
/*     */     {
/*     */     }
/*     */ 
/*     */     public TilesContainer createContainer(ApplicationContext context)
/*     */     {
/* 280 */       TilesContainer container = super.createContainer(context);
/* 281 */       return TilesConfigurer.this.useMutableTilesContainer ? new CachingTilesContainer(container) : container;
/*     */     }
/*     */ 
/*     */     protected List<ApplicationResource> getSources(ApplicationContext applicationContext)
/*     */     {
/* 286 */       if (TilesConfigurer.this.definitions != null) {
/* 287 */         List result = new LinkedList();
/* 288 */         for (String definition : TilesConfigurer.this.definitions) {
/* 289 */           result.addAll(applicationContext.getResources(definition));
/*     */         }
/* 291 */         return result;
/*     */       }
/*     */ 
/* 294 */       return super.getSources(applicationContext);
/*     */     }
/*     */ 
/*     */     protected BaseLocaleUrlDefinitionDAO instantiateLocaleDefinitionDao(ApplicationContext applicationContext, LocaleResolver resolver)
/*     */     {
/* 301 */       BaseLocaleUrlDefinitionDAO dao = super.instantiateLocaleDefinitionDao(applicationContext, resolver);
/* 302 */       if ((TilesConfigurer.this.checkRefresh) && ((dao instanceof CachingLocaleUrlDefinitionDAO))) {
/* 303 */         ((CachingLocaleUrlDefinitionDAO)dao).setCheckRefresh(TilesConfigurer.this.checkRefresh);
/*     */       }
/* 305 */       return dao;
/*     */     }
/*     */ 
/*     */     protected DefinitionsReader createDefinitionsReader(ApplicationContext context)
/*     */     {
/* 310 */       DigesterDefinitionsReader reader = (DigesterDefinitionsReader)super.createDefinitionsReader(context);
/* 311 */       reader.setValidating(TilesConfigurer.this.validateDefinitions);
/* 312 */       return reader;
/*     */     }
/*     */ 
/*     */     protected DefinitionsFactory createDefinitionsFactory(ApplicationContext applicationContext, LocaleResolver resolver)
/*     */     {
/* 319 */       if (TilesConfigurer.this.definitionsFactoryClass != null) {
/* 320 */         DefinitionsFactory factory = (DefinitionsFactory)BeanUtils.instantiate(TilesConfigurer.this.definitionsFactoryClass);
/* 321 */         if ((factory instanceof ApplicationContextAware)) {
/* 322 */           ((ApplicationContextAware)factory).setApplicationContext(applicationContext);
/*     */         }
/* 324 */         BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(factory);
/* 325 */         if (bw.isWritableProperty("localeResolver")) {
/* 326 */           bw.setPropertyValue("localeResolver", resolver);
/*     */         }
/* 328 */         if (bw.isWritableProperty("definitionDAO")) {
/* 329 */           bw.setPropertyValue("definitionDAO", createLocaleDefinitionDao(applicationContext, resolver));
/*     */         }
/* 331 */         return factory;
/*     */       }
/*     */ 
/* 334 */       return super.createDefinitionsFactory(applicationContext, resolver);
/*     */     }
/*     */ 
/*     */     protected PreparerFactory createPreparerFactory(ApplicationContext context)
/*     */     {
/* 340 */       if (TilesConfigurer.this.preparerFactoryClass != null) {
/* 341 */         return (PreparerFactory)BeanUtils.instantiate(TilesConfigurer.this.preparerFactoryClass);
/*     */       }
/* 343 */       return super.createPreparerFactory(context);
/*     */     }
/*     */ 
/*     */     protected LocaleResolver createLocaleResolver(ApplicationContext context)
/*     */     {
/* 349 */       return new SpringLocaleResolver();
/*     */     }
/*     */ 
/*     */     protected AttributeEvaluatorFactory createAttributeEvaluatorFactory(ApplicationContext context, LocaleResolver resolver)
/*     */     {
/* 355 */       return new BasicAttributeEvaluatorFactory(createELEvaluator(context));
/*     */     }
/*     */ 
/*     */     private AttributeEvaluator createELEvaluator(ApplicationContext context) {
/* 359 */       if (TilesConfigurer.tilesElPresent) {
/* 360 */         AttributeEvaluator evaluator = new TilesConfigurer.TilesElActivator(TilesConfigurer.this, null).createEvaluator();
/* 361 */         if (evaluator != null) {
/* 362 */           return evaluator;
/*     */         }
/*     */       }
/* 365 */       return new DirectAttributeEvaluator();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class SpringTilesInitializer extends DefaultTilesInitializer
/*     */   {
/*     */     private SpringTilesInitializer()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected AbstractTilesContainerFactory createContainerFactory(ApplicationContext context)
/*     */     {
/* 271 */       return new TilesConfigurer.SpringTilesContainerFactory(TilesConfigurer.this, null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles3.TilesConfigurer
 * JD-Core Version:    0.6.2
 */