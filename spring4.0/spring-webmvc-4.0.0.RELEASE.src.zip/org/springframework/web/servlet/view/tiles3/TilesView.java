/*     */ package org.springframework.web.servlet.view.tiles3;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.tiles.TilesContainer;
/*     */ import org.apache.tiles.access.TilesAccess;
/*     */ import org.apache.tiles.renderer.DefinitionRenderer;
/*     */ import org.apache.tiles.request.ApplicationContext;
/*     */ import org.apache.tiles.request.Request;
/*     */ import org.apache.tiles.request.render.Renderer;
/*     */ import org.apache.tiles.request.servlet.ServletRequest;
/*     */ import org.apache.tiles.request.servlet.ServletUtil;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.servlet.support.JstlUtils;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*     */ 
/*     */ public class TilesView extends AbstractUrlBasedView
/*     */ {
/*     */   private Renderer renderer;
/*  55 */   private boolean exposeJstlAttributes = true;
/*     */   private ApplicationContext applicationContext;
/*     */ 
/*     */   public void setRenderer(Renderer renderer)
/*     */   {
/*  65 */     this.renderer = renderer;
/*     */   }
/*     */ 
/*     */   protected void setExposeJstlAttributes(boolean exposeJstlAttributes)
/*     */   {
/*  73 */     this.exposeJstlAttributes = exposeJstlAttributes;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws Exception
/*     */   {
/*  78 */     super.afterPropertiesSet();
/*     */ 
/*  80 */     this.applicationContext = ServletUtil.getApplicationContext(getServletContext());
/*  81 */     if (this.renderer == null) {
/*  82 */       TilesContainer container = TilesAccess.getContainer(this.applicationContext);
/*  83 */       this.renderer = new DefinitionRenderer(container);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean checkResource(final Locale locale)
/*     */     throws Exception
/*     */   {
/*  90 */     HttpServletRequest servletRequest = null;
/*  91 */     RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/*  92 */     if ((requestAttributes instanceof ServletRequestAttributes)) {
/*  93 */       servletRequest = ((ServletRequestAttributes)requestAttributes).getRequest();
/*     */     }
/*  95 */     Request request = new ServletRequest(this.applicationContext, servletRequest, null)
/*     */     {
/*     */       public Locale getRequestLocale() {
/*  98 */         return locale;
/*     */       }
/*     */     };
/* 101 */     return this.renderer.isRenderable(getUrl(), request);
/*     */   }
/*     */ 
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 108 */     exposeModelAsRequestAttributes(model, request);
/* 109 */     if (this.exposeJstlAttributes) {
/* 110 */       JstlUtils.exposeLocalizationContext(new RequestContext(request, getServletContext()));
/*     */     }
/*     */ 
/* 113 */     Request tilesRequest = createTilesRequest(request, response);
/* 114 */     this.renderer.render(getUrl(), tilesRequest);
/*     */   }
/*     */ 
/*     */   protected Request createTilesRequest(final HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 125 */     return new ServletRequest(this.applicationContext, request, response)
/*     */     {
/*     */       public Locale getRequestLocale() {
/* 128 */         return RequestContextUtils.getLocale(request);
/*     */       }
/*     */     };
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles3.TilesView
 * JD-Core Version:    0.6.2
 */