/*    */ package org.springframework.web.servlet.view.tiles3;
/*    */ 
/*    */ import org.apache.tiles.request.render.Renderer;
/*    */ import org.springframework.web.servlet.view.UrlBasedViewResolver;
/*    */ 
/*    */ public class TilesViewResolver extends UrlBasedViewResolver
/*    */ {
/*    */   private Renderer renderer;
/*    */ 
/*    */   protected Class<?> getViewClass()
/*    */   {
/* 36 */     return TilesView.class;
/*    */   }
/*    */ 
/*    */   public void setRenderer(Renderer renderer)
/*    */   {
/* 45 */     this.renderer = renderer;
/*    */   }
/*    */ 
/*    */   protected TilesView buildView(String viewName) throws Exception
/*    */   {
/* 50 */     TilesView view = (TilesView)super.buildView(viewName);
/* 51 */     view.setRenderer(this.renderer);
/* 52 */     return view;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.tiles3.TilesViewResolver
 * JD-Core Version:    0.6.2
 */