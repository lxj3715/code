package org.springframework.web.servlet.view.velocity;

import org.apache.velocity.app.VelocityEngine;

public abstract interface VelocityConfig
{
  public abstract VelocityEngine getVelocityEngine();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.velocity.VelocityConfig
 * JD-Core Version:    0.6.2
 */