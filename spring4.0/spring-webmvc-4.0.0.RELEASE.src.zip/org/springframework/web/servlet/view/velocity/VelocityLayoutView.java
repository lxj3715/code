/*     */ package org.springframework.web.servlet.view.velocity;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.velocity.Template;
/*     */ import org.apache.velocity.context.Context;
/*     */ import org.apache.velocity.exception.ResourceNotFoundException;
/*     */ import org.springframework.core.NestedIOException;
/*     */ 
/*     */ public class VelocityLayoutView extends VelocityToolboxView
/*     */ {
/*     */   public static final String DEFAULT_LAYOUT_URL = "layout.vm";
/*     */   public static final String DEFAULT_LAYOUT_KEY = "layout";
/*     */   public static final String DEFAULT_SCREEN_CONTENT_KEY = "screen_content";
/*  72 */   private String layoutUrl = "layout.vm";
/*     */ 
/*  74 */   private String layoutKey = "layout";
/*     */ 
/*  76 */   private String screenContentKey = "screen_content";
/*     */ 
/*     */   public void setLayoutUrl(String layoutUrl)
/*     */   {
/*  85 */     this.layoutUrl = layoutUrl;
/*     */   }
/*     */ 
/*     */   public void setLayoutKey(String layoutKey)
/*     */   {
/*  99 */     this.layoutKey = layoutKey;
/*     */   }
/*     */ 
/*     */   public void setScreenContentKey(String screenContentKey)
/*     */   {
/* 111 */     this.screenContentKey = screenContentKey;
/*     */   }
/*     */ 
/*     */   public boolean checkResource(Locale locale)
/*     */     throws Exception
/*     */   {
/* 123 */     if (!super.checkResource(locale)) {
/* 124 */       return false;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 129 */       getTemplate(this.layoutUrl);
/* 130 */       return true;
/*     */     }
/*     */     catch (ResourceNotFoundException ex) {
/* 133 */       throw new NestedIOException("Cannot find Velocity template for URL [" + this.layoutUrl + "]: Did you specify the correct resource loader path?", ex);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 137 */       throw new NestedIOException("Could not load Velocity template for URL [" + this.layoutUrl + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doRender(Context context, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 150 */     renderScreenContent(context);
/*     */ 
/* 156 */     String layoutUrlToUse = (String)context.get(this.layoutKey);
/* 157 */     if (layoutUrlToUse != null) {
/* 158 */       if (this.logger.isDebugEnabled()) {
/* 159 */         this.logger.debug("Screen content template has requested layout [" + layoutUrlToUse + "]");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 164 */       layoutUrlToUse = this.layoutUrl;
/*     */     }
/*     */ 
/* 167 */     mergeTemplate(getTemplate(layoutUrlToUse), context, response);
/*     */   }
/*     */ 
/*     */   private void renderScreenContent(Context velocityContext)
/*     */     throws Exception
/*     */   {
/* 174 */     if (this.logger.isDebugEnabled()) {
/* 175 */       this.logger.debug("Rendering screen content template [" + getUrl() + "]");
/*     */     }
/*     */ 
/* 178 */     StringWriter sw = new StringWriter();
/* 179 */     Template screenContentTemplate = getTemplate(getUrl());
/* 180 */     screenContentTemplate.merge(velocityContext, sw);
/*     */ 
/* 183 */     velocityContext.put(this.screenContentKey, sw.toString());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.velocity.VelocityLayoutView
 * JD-Core Version:    0.6.2
 */