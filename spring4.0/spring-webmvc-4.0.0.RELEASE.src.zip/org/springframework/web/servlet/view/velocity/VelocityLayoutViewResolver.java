/*     */ package org.springframework.web.servlet.view.velocity;
/*     */ 
/*     */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*     */ 
/*     */ public class VelocityLayoutViewResolver extends VelocityViewResolver
/*     */ {
/*     */   private String layoutUrl;
/*     */   private String layoutKey;
/*     */   private String screenContentKey;
/*     */ 
/*     */   protected Class<?> requiredViewClass()
/*     */   {
/*  50 */     return VelocityLayoutView.class;
/*     */   }
/*     */ 
/*     */   public void setLayoutUrl(String layoutUrl)
/*     */   {
/*  60 */     this.layoutUrl = layoutUrl;
/*     */   }
/*     */ 
/*     */   public void setLayoutKey(String layoutKey)
/*     */   {
/*  75 */     this.layoutKey = layoutKey;
/*     */   }
/*     */ 
/*     */   public void setScreenContentKey(String screenContentKey)
/*     */   {
/*  88 */     this.screenContentKey = screenContentKey;
/*     */   }
/*     */ 
/*     */   protected AbstractUrlBasedView buildView(String viewName)
/*     */     throws Exception
/*     */   {
/*  94 */     VelocityLayoutView view = (VelocityLayoutView)super.buildView(viewName);
/*     */ 
/*  96 */     if (this.layoutUrl != null) {
/*  97 */       view.setLayoutUrl(this.layoutUrl);
/*     */     }
/*  99 */     if (this.layoutKey != null) {
/* 100 */       view.setLayoutKey(this.layoutKey);
/*     */     }
/* 102 */     if (this.screenContentKey != null) {
/* 103 */       view.setScreenContentKey(this.screenContentKey);
/*     */     }
/* 105 */     return view;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.velocity.VelocityLayoutViewResolver
 * JD-Core Version:    0.6.2
 */