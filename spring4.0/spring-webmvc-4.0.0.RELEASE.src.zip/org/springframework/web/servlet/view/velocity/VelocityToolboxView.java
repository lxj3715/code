/*     */ package org.springframework.web.servlet.view.velocity;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.context.Context;
/*     */ import org.apache.velocity.tools.view.ToolboxManager;
/*     */ import org.apache.velocity.tools.view.context.ChainedContext;
/*     */ import org.apache.velocity.tools.view.servlet.ServletToolboxManager;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class VelocityToolboxView extends VelocityView
/*     */ {
/*     */   private String toolboxConfigLocation;
/*     */ 
/*     */   public void setToolboxConfigLocation(String toolboxConfigLocation)
/*     */   {
/*  82 */     this.toolboxConfigLocation = toolboxConfigLocation;
/*     */   }
/*     */ 
/*     */   protected String getToolboxConfigLocation()
/*     */   {
/*  89 */     return this.toolboxConfigLocation;
/*     */   }
/*     */ 
/*     */   protected Context createVelocityContext(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 105 */     ChainedContext velocityContext = new ChainedContext(new VelocityContext(model), 
/* 105 */       getVelocityEngine(), request, response, getServletContext());
/*     */ 
/* 108 */     if (getToolboxConfigLocation() != null) {
/* 109 */       ToolboxManager toolboxManager = ServletToolboxManager.getInstance(
/* 110 */         getServletContext(), getToolboxConfigLocation());
/* 111 */       Map toolboxContext = toolboxManager.getToolbox(velocityContext);
/* 112 */       velocityContext.setToolbox(toolboxContext);
/*     */     }
/*     */ 
/* 115 */     return velocityContext;
/*     */   }
/*     */ 
/*     */   protected void initTool(Object tool, Context velocityContext)
/*     */     throws Exception
/*     */   {
/* 126 */     Method initMethod = ClassUtils.getMethodIfAvailable(tool.getClass(), "init", new Class[] { Object.class });
/* 127 */     if (initMethod != null)
/* 128 */       ReflectionUtils.invokeMethod(initMethod, tool, new Object[] { velocityContext });
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.velocity.VelocityToolboxView
 * JD-Core Version:    0.6.2
 */