/*     */ package org.springframework.web.servlet.view.velocity;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.velocity.Template;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.context.Context;
/*     */ import org.apache.velocity.exception.MethodInvocationException;
/*     */ import org.apache.velocity.exception.ResourceNotFoundException;
/*     */ import org.apache.velocity.tools.generic.DateTool;
/*     */ import org.apache.velocity.tools.generic.NumberTool;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.core.NestedIOException;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ import org.springframework.web.servlet.view.AbstractTemplateView;
/*     */ import org.springframework.web.util.NestedServletException;
/*     */ 
/*     */ public class VelocityView extends AbstractTemplateView
/*     */ {
/*     */   private Map<String, Class<?>> toolAttributes;
/*     */   private String dateToolAttribute;
/*     */   private String numberToolAttribute;
/*     */   private String encoding;
/*     */   private boolean cacheTemplate;
/*     */   private VelocityEngine velocityEngine;
/*     */   private Template template;
/*     */ 
/*     */   public VelocityView()
/*     */   {
/*  97 */     this.cacheTemplate = false;
/*     */   }
/*     */ 
/*     */   public void setToolAttributes(Map<String, Class<?>> toolAttributes)
/*     */   {
/* 132 */     this.toolAttributes = toolAttributes;
/*     */   }
/*     */ 
/*     */   public void setDateToolAttribute(String dateToolAttribute)
/*     */   {
/* 146 */     this.dateToolAttribute = dateToolAttribute;
/*     */   }
/*     */ 
/*     */   public void setNumberToolAttribute(String numberToolAttribute)
/*     */   {
/* 160 */     this.numberToolAttribute = numberToolAttribute;
/*     */   }
/*     */ 
/*     */   public void setEncoding(String encoding)
/*     */   {
/* 170 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */   protected String getEncoding()
/*     */   {
/* 177 */     return this.encoding;
/*     */   }
/*     */ 
/*     */   public void setCacheTemplate(boolean cacheTemplate)
/*     */   {
/* 188 */     this.cacheTemplate = cacheTemplate;
/*     */   }
/*     */ 
/*     */   protected boolean isCacheTemplate()
/*     */   {
/* 195 */     return this.cacheTemplate;
/*     */   }
/*     */ 
/*     */   public void setVelocityEngine(VelocityEngine velocityEngine)
/*     */   {
/* 205 */     this.velocityEngine = velocityEngine;
/*     */   }
/*     */ 
/*     */   protected VelocityEngine getVelocityEngine()
/*     */   {
/* 212 */     return this.velocityEngine;
/*     */   }
/*     */ 
/*     */   protected void initApplicationContext()
/*     */     throws BeansException
/*     */   {
/* 222 */     super.initApplicationContext();
/*     */ 
/* 224 */     if (getVelocityEngine() == null)
/*     */     {
/* 226 */       setVelocityEngine(autodetectVelocityEngine());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected VelocityEngine autodetectVelocityEngine()
/*     */     throws BeansException
/*     */   {
/*     */     try
/*     */     {
/* 240 */       VelocityConfig velocityConfig = (VelocityConfig)BeanFactoryUtils.beanOfTypeIncludingAncestors(
/* 241 */         getApplicationContext(), VelocityConfig.class, true, false);
/* 242 */       return velocityConfig.getVelocityEngine();
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {
/* 245 */       throw new ApplicationContextException("Must define a single VelocityConfig bean in this web application context (may be inherited): VelocityConfigurer is the usual implementation. This bean may be given any name.", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean checkResource(Locale locale)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 261 */       this.template = getTemplate(getUrl());
/* 262 */       return true;
/*     */     }
/*     */     catch (ResourceNotFoundException ex) {
/* 265 */       if (this.logger.isDebugEnabled()) {
/* 266 */         this.logger.debug("No Velocity view found for URL: " + getUrl());
/*     */       }
/* 268 */       return false;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 272 */       throw new NestedIOException("Could not load Velocity template for URL [" + 
/* 272 */         getUrl() + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void renderMergedTemplateModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 286 */     exposeHelpers(model, request);
/*     */ 
/* 288 */     Context velocityContext = createVelocityContext(model, request, response);
/* 289 */     exposeHelpers(velocityContext, request, response);
/* 290 */     exposeToolAttributes(velocityContext, request);
/*     */ 
/* 292 */     doRender(velocityContext, response);
/*     */   }
/*     */ 
/*     */   protected void exposeHelpers(Map<String, Object> model, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   protected Context createVelocityContext(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 331 */     return createVelocityContext(model);
/*     */   }
/*     */ 
/*     */   protected Context createVelocityContext(Map<String, Object> model)
/*     */     throws Exception
/*     */   {
/* 346 */     return new VelocityContext(model);
/*     */   }
/*     */ 
/*     */   protected void exposeHelpers(Context velocityContext, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 365 */     exposeHelpers(velocityContext, request);
/*     */   }
/*     */ 
/*     */   protected void exposeHelpers(Context velocityContext, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void exposeToolAttributes(Context velocityContext, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 395 */     if (this.toolAttributes != null) {
/* 396 */       for (Map.Entry entry : this.toolAttributes.entrySet()) {
/* 397 */         String attributeName = (String)entry.getKey();
/* 398 */         Class toolClass = (Class)entry.getValue();
/*     */         try {
/* 400 */           Object tool = toolClass.newInstance();
/* 401 */           initTool(tool, velocityContext);
/* 402 */           velocityContext.put(attributeName, tool);
/*     */         }
/*     */         catch (Exception ex) {
/* 405 */           throw new NestedServletException("Could not instantiate Velocity tool '" + attributeName + "'", ex);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 411 */     if ((this.dateToolAttribute != null) || (this.numberToolAttribute != null)) {
/* 412 */       if (this.dateToolAttribute != null) {
/* 413 */         velocityContext.put(this.dateToolAttribute, new LocaleAwareDateTool(request));
/*     */       }
/* 415 */       if (this.numberToolAttribute != null)
/* 416 */         velocityContext.put(this.numberToolAttribute, new LocaleAwareNumberTool(request));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void initTool(Object tool, Context velocityContext)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void doRender(Context context, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 459 */     if (this.logger.isDebugEnabled()) {
/* 460 */       this.logger.debug("Rendering Velocity template [" + getUrl() + "] in VelocityView '" + getBeanName() + "'");
/*     */     }
/* 462 */     mergeTemplate(getTemplate(), context, response);
/*     */   }
/*     */ 
/*     */   protected Template getTemplate()
/*     */     throws Exception
/*     */   {
/* 480 */     if ((isCacheTemplate()) && (this.template != null)) {
/* 481 */       return this.template;
/*     */     }
/*     */ 
/* 484 */     return getTemplate(getUrl());
/*     */   }
/*     */ 
/*     */   protected Template getTemplate(String name)
/*     */     throws Exception
/*     */   {
/* 501 */     return getEncoding() != null ? 
/* 500 */       getVelocityEngine().getTemplate(name, getEncoding()) : 
/* 501 */       getVelocityEngine().getTemplate(name);
/*     */   }
/*     */ 
/*     */   protected void mergeTemplate(Template template, Context context, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 517 */       template.merge(context, response.getWriter());
/*     */     }
/*     */     catch (MethodInvocationException ex) {
/* 520 */       Throwable cause = ex.getWrappedThrowable();
/*     */ 
/* 524 */       throw new NestedServletException("Method invocation failed during rendering of Velocity view with name '" + 
/* 523 */         getBeanName() + "': " + ex.getMessage() + "; reference [" + ex.getReferenceName() + "], method '" + ex
/* 524 */         .getMethodName() + "'", cause == null ? ex : cause);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class LocaleAwareNumberTool extends NumberTool
/*     */   {
/*     */     private final HttpServletRequest request;
/*     */ 
/*     */     public LocaleAwareNumberTool(HttpServletRequest request)
/*     */     {
/* 567 */       this.request = request;
/*     */     }
/*     */ 
/*     */     public Locale getLocale()
/*     */     {
/* 572 */       return RequestContextUtils.getLocale(this.request);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class LocaleAwareDateTool extends DateTool
/*     */   {
/*     */     private final HttpServletRequest request;
/*     */ 
/*     */     public LocaleAwareDateTool(HttpServletRequest request)
/*     */     {
/* 541 */       this.request = request;
/*     */     }
/*     */ 
/*     */     public Locale getLocale()
/*     */     {
/* 546 */       return RequestContextUtils.getLocale(this.request);
/*     */     }
/*     */ 
/*     */     public TimeZone getTimeZone()
/*     */     {
/* 551 */       TimeZone timeZone = RequestContextUtils.getTimeZone(this.request);
/* 552 */       return timeZone != null ? timeZone : super.getTimeZone();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.velocity.VelocityView
 * JD-Core Version:    0.6.2
 */