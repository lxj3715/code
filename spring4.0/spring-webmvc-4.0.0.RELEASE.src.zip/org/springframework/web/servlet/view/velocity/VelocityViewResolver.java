/*     */ package org.springframework.web.servlet.view.velocity;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.web.servlet.view.AbstractTemplateViewResolver;
/*     */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*     */ 
/*     */ public class VelocityViewResolver extends AbstractTemplateViewResolver
/*     */ {
/*     */   private String dateToolAttribute;
/*     */   private String numberToolAttribute;
/*     */   private String toolboxConfigLocation;
/*     */ 
/*     */   public VelocityViewResolver()
/*     */   {
/*  54 */     setViewClass(requiredViewClass());
/*     */   }
/*     */ 
/*     */   protected Class<?> requiredViewClass()
/*     */   {
/*  62 */     return VelocityView.class;
/*     */   }
/*     */ 
/*     */   public void setDateToolAttribute(String dateToolAttribute)
/*     */   {
/*  73 */     this.dateToolAttribute = dateToolAttribute;
/*     */   }
/*     */ 
/*     */   public void setNumberToolAttribute(String numberToolAttribute)
/*     */   {
/*  83 */     this.numberToolAttribute = numberToolAttribute;
/*     */   }
/*     */ 
/*     */   public void setToolboxConfigLocation(String toolboxConfigLocation)
/*     */   {
/* 100 */     this.toolboxConfigLocation = toolboxConfigLocation;
/*     */   }
/*     */ 
/*     */   protected void initApplicationContext()
/*     */   {
/* 106 */     super.initApplicationContext();
/*     */ 
/* 108 */     if (this.toolboxConfigLocation != null)
/* 109 */       if (VelocityView.class.equals(getViewClass())) {
/* 110 */         this.logger.info("Using VelocityToolboxView instead of default VelocityView due to specified toolboxConfigLocation");
/*     */ 
/* 112 */         setViewClass(VelocityToolboxView.class);
/*     */       }
/* 114 */       else if (!VelocityToolboxView.class.isAssignableFrom(getViewClass()))
/*     */       {
/* 117 */         throw new IllegalArgumentException("Given view class [" + 
/* 116 */           getViewClass().getName() + "] is not of type [" + VelocityToolboxView.class
/* 117 */           .getName() + "], which it needs to be in case of a specified toolboxConfigLocation");
/*     */       }
/*     */   }
/*     */ 
/*     */   protected AbstractUrlBasedView buildView(String viewName)
/*     */     throws Exception
/*     */   {
/* 126 */     VelocityView view = (VelocityView)super.buildView(viewName);
/* 127 */     view.setDateToolAttribute(this.dateToolAttribute);
/* 128 */     view.setNumberToolAttribute(this.numberToolAttribute);
/* 129 */     if (this.toolboxConfigLocation != null) {
/* 130 */       ((VelocityToolboxView)view).setToolboxConfigLocation(this.toolboxConfigLocation);
/*     */     }
/* 132 */     return view;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.velocity.VelocityViewResolver
 * JD-Core Version:    0.6.2
 */