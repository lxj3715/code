/*     */ package org.springframework.web.servlet.view.xml;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.oxm.Marshaller;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.web.servlet.view.AbstractView;
/*     */ 
/*     */ public class MarshallingView extends AbstractView
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "application/xml";
/*     */   private Marshaller marshaller;
/*     */   private String modelKey;
/*     */ 
/*     */   public MarshallingView()
/*     */   {
/*  61 */     setContentType("application/xml");
/*  62 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */   public MarshallingView(Marshaller marshaller)
/*     */   {
/*  69 */     Assert.notNull(marshaller, "'marshaller' must not be null");
/*  70 */     setContentType("application/xml");
/*  71 */     this.marshaller = marshaller;
/*  72 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */   public void setMarshaller(Marshaller marshaller)
/*     */   {
/*  79 */     Assert.notNull(marshaller, "'marshaller' must not be null");
/*  80 */     this.marshaller = marshaller;
/*     */   }
/*     */ 
/*     */   public void setModelKey(String modelKey)
/*     */   {
/*  90 */     this.modelKey = modelKey;
/*     */   }
/*     */ 
/*     */   protected void initApplicationContext() throws BeansException
/*     */   {
/*  95 */     Assert.notNull(this.marshaller, "Property 'marshaller' is required");
/*     */   }
/*     */ 
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 102 */     Object toBeMarshalled = locateToBeMarshalled(model);
/* 103 */     if (toBeMarshalled == null) {
/* 104 */       throw new ServletException("Unable to locate object to be marshalled in model: " + model);
/*     */     }
/* 106 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(2048);
/* 107 */     this.marshaller.marshal(toBeMarshalled, new StreamResult(bos));
/*     */ 
/* 109 */     setResponseContentType(request, response);
/* 110 */     response.setContentLength(bos.size());
/*     */ 
/* 112 */     FileCopyUtils.copy(bos.toByteArray(), response.getOutputStream());
/*     */   }
/*     */ 
/*     */   protected Object locateToBeMarshalled(Map<String, Object> model)
/*     */     throws ServletException
/*     */   {
/* 127 */     if (this.modelKey != null) {
/* 128 */       o = model.get(this.modelKey);
/* 129 */       if (o == null) {
/* 130 */         throw new ServletException("Model contains no object with key [" + this.modelKey + "]");
/*     */       }
/* 132 */       if (!this.marshaller.supports(o.getClass())) {
/* 133 */         throw new ServletException("Model object [" + o + "] retrieved via key [" + this.modelKey + "] is not supported by the Marshaller");
/*     */       }
/*     */ 
/* 136 */       return o;
/*     */     }
/* 138 */     for (Object o = model.values().iterator(); o.hasNext(); ) { Object o = o.next();
/* 139 */       if ((o != null) && (this.marshaller.supports(o.getClass()))) {
/* 140 */         return o;
/*     */       }
/*     */     }
/* 143 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.xml.MarshallingView
 * JD-Core Version:    0.6.2
 */