/*     */ package org.springframework.web.servlet.view.xslt;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URI;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.xml.transform.ErrorListener;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Templates;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.TransformerFactoryConfigurationError;
/*     */ import javax.xml.transform.URIResolver;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.SimpleTransformErrorListener;
/*     */ import org.springframework.util.xml.TransformerUtils;
/*     */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public class XsltView extends AbstractUrlBasedView
/*     */ {
/*     */   private Class<?> transformerFactoryClass;
/*     */   private String sourceKey;
/*     */   private URIResolver uriResolver;
/*  82 */   private ErrorListener errorListener = new SimpleTransformErrorListener(this.logger);
/*     */ 
/*  84 */   private boolean indent = true;
/*     */   private Properties outputProperties;
/*  88 */   private boolean cacheTemplates = true;
/*     */   private TransformerFactory transformerFactory;
/*     */   private Templates cachedTemplates;
/*     */ 
/*     */   public void setTransformerFactoryClass(Class<?> transformerFactoryClass)
/*     */   {
/* 101 */     Assert.isAssignable(TransformerFactory.class, transformerFactoryClass);
/* 102 */     this.transformerFactoryClass = transformerFactoryClass;
/*     */   }
/*     */ 
/*     */   public void setSourceKey(String sourceKey)
/*     */   {
/* 115 */     this.sourceKey = sourceKey;
/*     */   }
/*     */ 
/*     */   public void setUriResolver(URIResolver uriResolver)
/*     */   {
/* 123 */     this.uriResolver = uriResolver;
/*     */   }
/*     */ 
/*     */   public void setErrorListener(ErrorListener errorListener)
/*     */   {
/* 136 */     this.errorListener = (errorListener != null ? errorListener : new SimpleTransformErrorListener(this.logger));
/*     */   }
/*     */ 
/*     */   public void setIndent(boolean indent)
/*     */   {
/* 147 */     this.indent = indent;
/*     */   }
/*     */ 
/*     */   public void setOutputProperties(Properties outputProperties)
/*     */   {
/* 157 */     this.outputProperties = outputProperties;
/*     */   }
/*     */ 
/*     */   public void setCacheTemplates(boolean cacheTemplates)
/*     */   {
/* 166 */     this.cacheTemplates = cacheTemplates;
/*     */   }
/*     */ 
/*     */   protected void initApplicationContext()
/*     */     throws BeansException
/*     */   {
/* 175 */     this.transformerFactory = newTransformerFactory(this.transformerFactoryClass);
/* 176 */     this.transformerFactory.setErrorListener(this.errorListener);
/* 177 */     if (this.uriResolver != null) {
/* 178 */       this.transformerFactory.setURIResolver(this.uriResolver);
/*     */     }
/* 180 */     if (this.cacheTemplates)
/* 181 */       this.cachedTemplates = loadTemplates();
/*     */   }
/*     */ 
/*     */   protected TransformerFactory newTransformerFactory(Class<?> transformerFactoryClass)
/*     */   {
/* 199 */     if (transformerFactoryClass != null) {
/*     */       try {
/* 201 */         return (TransformerFactory)transformerFactoryClass.newInstance();
/*     */       }
/*     */       catch (Exception ex) {
/* 204 */         throw new TransformerFactoryConfigurationError(ex, "Could not instantiate TransformerFactory");
/*     */       }
/*     */     }
/*     */ 
/* 208 */     return TransformerFactory.newInstance();
/*     */   }
/*     */ 
/*     */   protected final TransformerFactory getTransformerFactory()
/*     */   {
/* 217 */     return this.transformerFactory;
/*     */   }
/*     */ 
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 226 */     Templates templates = this.cachedTemplates;
/* 227 */     if (templates == null) {
/* 228 */       templates = loadTemplates();
/*     */     }
/*     */ 
/* 231 */     Transformer transformer = createTransformer(templates);
/* 232 */     configureTransformer(model, response, transformer);
/* 233 */     configureResponse(model, response, transformer);
/* 234 */     Source source = null;
/*     */     try {
/* 236 */       source = locateSource(model);
/* 237 */       if (source == null) {
/* 238 */         throw new IllegalArgumentException("Unable to locate Source object in model: " + model);
/*     */       }
/* 240 */       transformer.transform(source, createResult(response));
/*     */     }
/*     */     finally {
/* 243 */       closeSourceIfNecessary(source);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Result createResult(HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 256 */     return new StreamResult(response.getOutputStream());
/*     */   }
/*     */ 
/*     */   protected Source locateSource(Map<String, Object> model)
/*     */     throws Exception
/*     */   {
/* 272 */     if (this.sourceKey != null) {
/* 273 */       return convertSource(model.get(this.sourceKey));
/*     */     }
/* 275 */     Object source = CollectionUtils.findValueOfType(model.values(), getSourceTypes());
/* 276 */     return source != null ? convertSource(source) : null;
/*     */   }
/*     */ 
/*     */   protected Class<?>[] getSourceTypes()
/*     */   {
/* 287 */     return new Class[] { Source.class, Document.class, Node.class, Reader.class, InputStream.class, Resource.class };
/*     */   }
/*     */ 
/*     */   protected Source convertSource(Object source)
/*     */     throws Exception
/*     */   {
/* 298 */     if ((source instanceof Source)) {
/* 299 */       return (Source)source;
/*     */     }
/* 301 */     if ((source instanceof Document)) {
/* 302 */       return new DOMSource(((Document)source).getDocumentElement());
/*     */     }
/* 304 */     if ((source instanceof Node)) {
/* 305 */       return new DOMSource((Node)source);
/*     */     }
/* 307 */     if ((source instanceof Reader)) {
/* 308 */       return new StreamSource((Reader)source);
/*     */     }
/* 310 */     if ((source instanceof InputStream)) {
/* 311 */       return new StreamSource((InputStream)source);
/*     */     }
/* 313 */     if ((source instanceof Resource)) {
/* 314 */       Resource resource = (Resource)source;
/* 315 */       return new StreamSource(resource.getInputStream(), resource.getURI().toASCIIString());
/*     */     }
/*     */ 
/* 318 */     throw new IllegalArgumentException("Value '" + source + "' cannot be converted to XSLT Source");
/*     */   }
/*     */ 
/*     */   protected void configureTransformer(Map<String, Object> model, HttpServletResponse response, Transformer transformer)
/*     */   {
/* 337 */     copyModelParameters(model, transformer);
/* 338 */     copyOutputProperties(transformer);
/* 339 */     configureIndentation(transformer);
/*     */   }
/*     */ 
/*     */   protected final void configureIndentation(Transformer transformer)
/*     */   {
/* 349 */     if (this.indent) {
/* 350 */       TransformerUtils.enableIndenting(transformer);
/*     */     }
/*     */     else
/* 353 */       TransformerUtils.disableIndenting(transformer);
/*     */   }
/*     */ 
/*     */   protected final void copyOutputProperties(Transformer transformer)
/*     */   {
/* 364 */     if (this.outputProperties != null) {
/* 365 */       Enumeration en = this.outputProperties.propertyNames();
/* 366 */       while (en.hasMoreElements()) {
/* 367 */         String name = (String)en.nextElement();
/* 368 */         transformer.setOutputProperty(name, this.outputProperties.getProperty(name));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final void copyModelParameters(Map<String, Object> model, Transformer transformer)
/*     */   {
/* 381 */     for (Map.Entry entry : model.entrySet())
/* 382 */       transformer.setParameter((String)entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */   protected void configureResponse(Map<String, Object> model, HttpServletResponse response, Transformer transformer)
/*     */   {
/* 398 */     String contentType = getContentType();
/* 399 */     String mediaType = transformer.getOutputProperty("media-type");
/* 400 */     String encoding = transformer.getOutputProperty("encoding");
/* 401 */     if (StringUtils.hasText(mediaType)) {
/* 402 */       contentType = mediaType;
/*     */     }
/* 404 */     if (StringUtils.hasText(encoding))
/*     */     {
/* 406 */       if ((contentType != null) && (!contentType.toLowerCase().contains(";charset="))) {
/* 407 */         contentType = contentType + ";charset=" + encoding;
/*     */       }
/*     */     }
/* 410 */     response.setContentType(contentType);
/*     */   }
/*     */ 
/*     */   private Templates loadTemplates()
/*     */     throws ApplicationContextException
/*     */   {
/* 417 */     Source stylesheetSource = getStylesheetSource();
/*     */     try {
/* 419 */       Templates templates = this.transformerFactory.newTemplates(stylesheetSource);
/* 420 */       if (this.logger.isDebugEnabled()) {
/* 421 */         this.logger.debug("Loading templates '" + templates + "'");
/*     */       }
/* 423 */       return templates;
/*     */     }
/*     */     catch (TransformerConfigurationException ex) {
/* 426 */       throw new ApplicationContextException("Can't load stylesheet from '" + getUrl() + "'", ex);
/*     */     }
/*     */     finally {
/* 429 */       closeSourceIfNecessary(stylesheetSource);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Transformer createTransformer(Templates templates)
/*     */     throws TransformerConfigurationException
/*     */   {
/* 442 */     Transformer transformer = templates.newTransformer();
/* 443 */     if (this.uriResolver != null) {
/* 444 */       transformer.setURIResolver(this.uriResolver);
/*     */     }
/* 446 */     return transformer;
/*     */   }
/*     */ 
/*     */   protected Source getStylesheetSource()
/*     */   {
/* 454 */     String url = getUrl();
/* 455 */     if (this.logger.isDebugEnabled())
/* 456 */       this.logger.debug("Loading XSLT stylesheet from '" + url + "'");
/*     */     try
/*     */     {
/* 459 */       Resource resource = getApplicationContext().getResource(url);
/* 460 */       return new StreamSource(resource.getInputStream(), resource.getURI().toASCIIString());
/*     */     }
/*     */     catch (IOException ex) {
/* 463 */       throw new ApplicationContextException("Can't load XSLT stylesheet from '" + url + "'", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void closeSourceIfNecessary(Source source)
/*     */   {
/* 473 */     if ((source instanceof StreamSource)) {
/* 474 */       StreamSource streamSource = (StreamSource)source;
/* 475 */       if (streamSource.getReader() != null) {
/*     */         try {
/* 477 */           streamSource.getReader().close();
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */         }
/*     */       }
/* 483 */       if (streamSource.getInputStream() != null)
/*     */         try {
/* 485 */           streamSource.getInputStream().close();
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.xslt.XsltView
 * JD-Core Version:    0.6.2
 */