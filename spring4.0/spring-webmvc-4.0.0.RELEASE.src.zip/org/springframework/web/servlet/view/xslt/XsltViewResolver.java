/*     */ package org.springframework.web.servlet.view.xslt;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import javax.xml.transform.ErrorListener;
/*     */ import javax.xml.transform.URIResolver;
/*     */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*     */ import org.springframework.web.servlet.view.UrlBasedViewResolver;
/*     */ 
/*     */ public class XsltViewResolver extends UrlBasedViewResolver
/*     */ {
/*     */   private String sourceKey;
/*     */   private URIResolver uriResolver;
/*     */   private ErrorListener errorListener;
/*  44 */   private boolean indent = true;
/*     */   private Properties outputProperties;
/*  48 */   private boolean cacheTemplates = true;
/*     */ 
/*     */   public XsltViewResolver()
/*     */   {
/*  52 */     setViewClass(XsltView.class);
/*     */   }
/*     */ 
/*     */   public void setSourceKey(String sourceKey)
/*     */   {
/*  65 */     this.sourceKey = sourceKey;
/*     */   }
/*     */ 
/*     */   public void setUriResolver(URIResolver uriResolver)
/*     */   {
/*  73 */     this.uriResolver = uriResolver;
/*     */   }
/*     */ 
/*     */   public void setErrorListener(ErrorListener errorListener)
/*     */   {
/*  86 */     this.errorListener = errorListener;
/*     */   }
/*     */ 
/*     */   public void setIndent(boolean indent)
/*     */   {
/*  97 */     this.indent = indent;
/*     */   }
/*     */ 
/*     */   public void setOutputProperties(Properties outputProperties)
/*     */   {
/* 107 */     this.outputProperties = outputProperties;
/*     */   }
/*     */ 
/*     */   public void setCacheTemplates(boolean cacheTemplates)
/*     */   {
/* 116 */     this.cacheTemplates = cacheTemplates;
/*     */   }
/*     */ 
/*     */   protected Class<?> requiredViewClass()
/*     */   {
/* 122 */     return XsltView.class;
/*     */   }
/*     */ 
/*     */   protected AbstractUrlBasedView buildView(String viewName) throws Exception
/*     */   {
/* 127 */     XsltView view = (XsltView)super.buildView(viewName);
/* 128 */     view.setSourceKey(this.sourceKey);
/* 129 */     if (this.uriResolver != null) {
/* 130 */       view.setUriResolver(this.uriResolver);
/*     */     }
/* 132 */     if (this.errorListener != null) {
/* 133 */       view.setErrorListener(this.errorListener);
/*     */     }
/* 135 */     view.setIndent(this.indent);
/* 136 */     view.setOutputProperties(this.outputProperties);
/* 137 */     view.setCacheTemplates(this.cacheTemplates);
/* 138 */     return view;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.view.xslt.XsltViewResolver
 * JD-Core Version:    0.6.2
 */