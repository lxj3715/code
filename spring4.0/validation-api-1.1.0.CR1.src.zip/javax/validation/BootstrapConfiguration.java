package javax.validation;

import java.util.Map;
import java.util.Set;
import javax.validation.executable.ExecutableType;

public abstract interface BootstrapConfiguration
{
  public abstract String getDefaultProviderClassName();

  public abstract String getConstraintValidatorFactoryClassName();

  public abstract String getMessageInterpolatorClassName();

  public abstract String getTraversableResolverClassName();

  public abstract String getParameterNameProviderClassName();

  public abstract Set<String> getConstraintMappingResourcePaths();

  public abstract Set<ExecutableType> getValidatedExecutableTypes();

  public abstract Map<String, String> getProperties();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.BootstrapConfiguration
 * JD-Core Version:    0.6.2
 */