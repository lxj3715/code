/*    */ package javax.validation;
/*    */ 
/*    */ public class ConstraintDeclarationException extends ValidationException
/*    */ {
/*    */   public ConstraintDeclarationException(String message)
/*    */   {
/* 27 */     super(message);
/*    */   }
/*    */ 
/*    */   public ConstraintDeclarationException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ConstraintDeclarationException(String message, Throwable cause) {
/* 35 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ConstraintDeclarationException(Throwable cause) {
/* 39 */     super(cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.ConstraintDeclarationException
 * JD-Core Version:    0.6.2
 */