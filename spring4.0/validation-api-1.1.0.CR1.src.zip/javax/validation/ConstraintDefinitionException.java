/*    */ package javax.validation;
/*    */ 
/*    */ public class ConstraintDefinitionException extends ValidationException
/*    */ {
/*    */   public ConstraintDefinitionException(String message)
/*    */   {
/* 27 */     super(message);
/*    */   }
/*    */ 
/*    */   public ConstraintDefinitionException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ConstraintDefinitionException(String message, Throwable cause) {
/* 35 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ConstraintDefinitionException(Throwable cause) {
/* 39 */     super(cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.ConstraintDefinitionException
 * JD-Core Version:    0.6.2
 */