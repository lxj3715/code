package javax.validation;

import java.lang.annotation.Annotation;

public abstract interface ConstraintValidator<A extends Annotation, T>
{
  public abstract void initialize(A paramA);

  public abstract boolean isValid(T paramT, ConstraintValidatorContext paramConstraintValidatorContext);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.ConstraintValidator
 * JD-Core Version:    0.6.2
 */