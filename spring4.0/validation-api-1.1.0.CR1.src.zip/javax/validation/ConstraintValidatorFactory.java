package javax.validation;

public abstract interface ConstraintValidatorFactory
{
  public abstract <T extends ConstraintValidator<?, ?>> T getInstance(Class<T> paramClass);

  public abstract void releaseInstance(ConstraintValidator<?, ?> paramConstraintValidator);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.ConstraintValidatorFactory
 * JD-Core Version:    0.6.2
 */