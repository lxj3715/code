/*    */ package javax.validation;
/*    */ 
/*    */ public enum ElementKind
/*    */ {
/* 35 */   BEAN, 
/*    */ 
/* 40 */   PROPERTY, 
/*    */ 
/* 45 */   METHOD, 
/*    */ 
/* 50 */   CONSTRUCTOR, 
/*    */ 
/* 55 */   PARAMETER, 
/*    */ 
/* 60 */   CROSS_PARAMETER, 
/*    */ 
/* 65 */   RETURN_VALUE;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.ElementKind
 * JD-Core Version:    0.6.2
 */