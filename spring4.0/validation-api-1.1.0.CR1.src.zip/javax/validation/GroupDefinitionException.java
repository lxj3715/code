/*    */ package javax.validation;
/*    */ 
/*    */ public class GroupDefinitionException extends ValidationException
/*    */ {
/*    */   public GroupDefinitionException(String message)
/*    */   {
/* 26 */     super(message);
/*    */   }
/*    */ 
/*    */   public GroupDefinitionException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public GroupDefinitionException(String message, Throwable cause) {
/* 34 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public GroupDefinitionException(Throwable cause) {
/* 38 */     super(cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.GroupDefinitionException
 * JD-Core Version:    0.6.2
 */