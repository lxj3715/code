package javax.validation;

import java.util.Locale;
import javax.validation.metadata.ConstraintDescriptor;

public abstract interface MessageInterpolator
{
  public abstract String interpolate(String paramString, Context paramContext);

  public abstract String interpolate(String paramString, Context paramContext, Locale paramLocale);

  public static abstract interface Context
  {
    public abstract ConstraintDescriptor<?> getConstraintDescriptor();

    public abstract Object getValidatedValue();

    public abstract <T> T unwrap(Class<T> paramClass);
  }
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.MessageInterpolator
 * JD-Core Version:    0.6.2
 */