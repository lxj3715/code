package javax.validation;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.List;

public abstract interface ParameterNameProvider
{
  public abstract List<String> getParameterNames(Constructor<?> paramConstructor);

  public abstract List<String> getParameterNames(Method paramMethod);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.ParameterNameProvider
 * JD-Core Version:    0.6.2
 */