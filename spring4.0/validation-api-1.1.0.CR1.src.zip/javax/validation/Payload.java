package javax.validation;

public abstract interface Payload
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.Payload
 * JD-Core Version:    0.6.2
 */