package javax.validation;

import java.lang.annotation.ElementType;

public abstract interface TraversableResolver
{
  public abstract boolean isReachable(Object paramObject, Path.Node paramNode, Class<?> paramClass, Path paramPath, ElementType paramElementType);

  public abstract boolean isCascadable(Object paramObject, Path.Node paramNode, Class<?> paramClass, Path paramPath, ElementType paramElementType);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.TraversableResolver
 * JD-Core Version:    0.6.2
 */