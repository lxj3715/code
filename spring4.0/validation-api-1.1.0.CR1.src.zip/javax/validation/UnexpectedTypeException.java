/*    */ package javax.validation;
/*    */ 
/*    */ public class UnexpectedTypeException extends ConstraintDeclarationException
/*    */ {
/*    */   public UnexpectedTypeException(String message)
/*    */   {
/* 27 */     super(message);
/*    */   }
/*    */ 
/*    */   public UnexpectedTypeException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public UnexpectedTypeException(String message, Throwable cause) {
/* 35 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public UnexpectedTypeException(Throwable cause) {
/* 39 */     super(cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.UnexpectedTypeException
 * JD-Core Version:    0.6.2
 */