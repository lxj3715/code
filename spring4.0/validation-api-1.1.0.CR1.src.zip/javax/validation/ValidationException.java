/*    */ package javax.validation;
/*    */ 
/*    */ public class ValidationException extends RuntimeException
/*    */ {
/*    */   public ValidationException(String message)
/*    */   {
/* 26 */     super(message);
/*    */   }
/*    */ 
/*    */   public ValidationException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ValidationException(String message, Throwable cause) {
/* 34 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ValidationException(Throwable cause) {
/* 38 */     super(cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.ValidationException
 * JD-Core Version:    0.6.2
 */