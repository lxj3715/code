package javax.validation;

import java.util.List;
import javax.validation.spi.ValidationProvider;

public abstract interface ValidationProviderResolver
{
  public abstract List<ValidationProvider<?>> getValidationProviders();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.ValidationProviderResolver
 * JD-Core Version:    0.6.2
 */