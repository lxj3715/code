package javax.validation;

import java.util.Set;
import javax.validation.executable.ExecutableValidator;
import javax.validation.metadata.BeanDescriptor;

public abstract interface Validator
{
  public abstract <T> Set<ConstraintViolation<T>> validate(T paramT, Class<?>[] paramArrayOfClass);

  public abstract <T> Set<ConstraintViolation<T>> validateProperty(T paramT, String paramString, Class<?>[] paramArrayOfClass);

  public abstract <T> Set<ConstraintViolation<T>> validateValue(Class<T> paramClass, String paramString, Object paramObject, Class<?>[] paramArrayOfClass);

  public abstract BeanDescriptor getConstraintsForClass(Class<?> paramClass);

  public abstract <T> T unwrap(Class<T> paramClass);

  public abstract ExecutableValidator forExecutables();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.Validator
 * JD-Core Version:    0.6.2
 */