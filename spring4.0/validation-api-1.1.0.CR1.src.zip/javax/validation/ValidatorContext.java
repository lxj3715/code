package javax.validation;

public abstract interface ValidatorContext
{
  public abstract ValidatorContext messageInterpolator(MessageInterpolator paramMessageInterpolator);

  public abstract ValidatorContext traversableResolver(TraversableResolver paramTraversableResolver);

  public abstract ValidatorContext constraintValidatorFactory(ConstraintValidatorFactory paramConstraintValidatorFactory);

  public abstract ValidatorContext parameterNameProvider(ParameterNameProvider paramParameterNameProvider);

  public abstract Validator getValidator();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.ValidatorContext
 * JD-Core Version:    0.6.2
 */