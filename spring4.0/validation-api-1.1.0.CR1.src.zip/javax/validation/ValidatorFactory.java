package javax.validation;

public abstract interface ValidatorFactory
{
  public abstract Validator getValidator();

  public abstract ValidatorContext usingContext();

  public abstract MessageInterpolator getMessageInterpolator();

  public abstract TraversableResolver getTraversableResolver();

  public abstract ConstraintValidatorFactory getConstraintValidatorFactory();

  public abstract ParameterNameProvider getParameterNameProvider();

  public abstract <T> T unwrap(Class<T> paramClass);

  public abstract void close();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.ValidatorFactory
 * JD-Core Version:    0.6.2
 */