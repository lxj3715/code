package javax.validation.bootstrap;

import javax.validation.Configuration;
import javax.validation.ValidationProviderResolver;

public abstract interface ProviderSpecificBootstrap<T extends Configuration<T>>
{
  public abstract ProviderSpecificBootstrap<T> providerResolver(ValidationProviderResolver paramValidationProviderResolver);

  public abstract T configure();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.bootstrap.ProviderSpecificBootstrap
 * JD-Core Version:    0.6.2
 */