/*     */ package javax.validation.constraints;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Documented;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ import javax.validation.Constraint;
/*     */ import javax.validation.Payload;
/*     */ 
/*     */ @Target({java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.FIELD, java.lang.annotation.ElementType.ANNOTATION_TYPE, java.lang.annotation.ElementType.CONSTRUCTOR, java.lang.annotation.ElementType.PARAMETER})
/*     */ @Retention(RetentionPolicy.RUNTIME)
/*     */ @Documented
/*     */ @Constraint(validatedBy={})
/*     */ public @interface Pattern
/*     */ {
/*     */   public abstract String regexp();
/*     */ 
/*     */   public abstract Flag[] flags();
/*     */ 
/*     */   public abstract String message();
/*     */ 
/*     */   public abstract Class<?>[] groups();
/*     */ 
/*     */   public abstract Class<? extends Payload>[] payload();
/*     */ 
/*     */   @Target({java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.FIELD, java.lang.annotation.ElementType.ANNOTATION_TYPE, java.lang.annotation.ElementType.CONSTRUCTOR, java.lang.annotation.ElementType.PARAMETER})
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   @Documented
/*     */   public static @interface List
/*     */   {
/*     */     public abstract Pattern[] value();
/*     */   }
/*     */ 
/*     */   public static enum Flag
/*     */   {
/*  82 */     UNIX_LINES(1), 
/*     */ 
/*  89 */     CASE_INSENSITIVE(2), 
/*     */ 
/*  96 */     COMMENTS(4), 
/*     */ 
/* 103 */     MULTILINE(8), 
/*     */ 
/* 110 */     DOTALL(32), 
/*     */ 
/* 117 */     UNICODE_CASE(64), 
/*     */ 
/* 124 */     CANON_EQ(128);
/*     */ 
/*     */     private final int value;
/*     */ 
/*     */     private Flag(int value)
/*     */     {
/* 130 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public int getValue()
/*     */     {
/* 137 */       return this.value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.constraints.Pattern
 * JD-Core Version:    0.6.2
 */