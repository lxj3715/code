/*    */ package javax.validation.constraintvalidation;
/*    */ 
/*    */ public enum ValidationTarget
/*    */ {
/* 32 */   ANNOTATED_ELEMENT, 
/*    */ 
/* 37 */   PARAMETERS;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.constraintvalidation.ValidationTarget
 * JD-Core Version:    0.6.2
 */