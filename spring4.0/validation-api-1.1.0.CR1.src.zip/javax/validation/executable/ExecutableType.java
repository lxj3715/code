/*    */ package javax.validation.executable;
/*    */ 
/*    */ public enum ExecutableType
/*    */ {
/* 34 */   NONE, 
/*    */ 
/* 39 */   CONSTRUCTORS, 
/*    */ 
/* 49 */   NON_GETTER_METHODS, 
/*    */ 
/* 60 */   GETTER_METHODS, 
/*    */ 
/* 65 */   ALL;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.executable.ExecutableType
 * JD-Core Version:    0.6.2
 */