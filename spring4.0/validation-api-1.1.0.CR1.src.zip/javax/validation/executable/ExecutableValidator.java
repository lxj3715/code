package javax.validation.executable;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Set;
import javax.validation.ConstraintViolation;

public abstract interface ExecutableValidator
{
  public abstract <T> Set<ConstraintViolation<T>> validateParameters(T paramT, Method paramMethod, Object[] paramArrayOfObject, Class<?>[] paramArrayOfClass);

  public abstract <T> Set<ConstraintViolation<T>> validateReturnValue(T paramT, Method paramMethod, Object paramObject, Class<?>[] paramArrayOfClass);

  public abstract <T> Set<ConstraintViolation<T>> validateConstructorParameters(Constructor<? extends T> paramConstructor, Object[] paramArrayOfObject, Class<?>[] paramArrayOfClass);

  public abstract <T> Set<ConstraintViolation<T>> validateConstructorReturnValue(Constructor<? extends T> paramConstructor, T paramT, Class<?>[] paramArrayOfClass);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.executable.ExecutableValidator
 * JD-Core Version:    0.6.2
 */