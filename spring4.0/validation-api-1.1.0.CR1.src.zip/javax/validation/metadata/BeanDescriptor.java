package javax.validation.metadata;

import java.util.Set;

public abstract interface BeanDescriptor extends ElementDescriptor
{
  public abstract boolean isBeanConstrained();

  public abstract boolean hasConstrainedExecutables();

  public abstract PropertyDescriptor getConstraintsForProperty(String paramString);

  public abstract Set<PropertyDescriptor> getConstrainedProperties();

  public abstract MethodDescriptor getConstraintsForMethod(String paramString, Class<?>[] paramArrayOfClass);

  public abstract Set<MethodDescriptor> getConstrainedMethods();

  public abstract ConstructorDescriptor getConstraintsForConstructor(Class<?>[] paramArrayOfClass);

  public abstract Set<ConstructorDescriptor> getConstrainedConstructors();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.metadata.BeanDescriptor
 * JD-Core Version:    0.6.2
 */