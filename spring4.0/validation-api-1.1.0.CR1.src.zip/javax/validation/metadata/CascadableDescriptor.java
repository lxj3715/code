package javax.validation.metadata;

import java.util.Set;

public abstract interface CascadableDescriptor
{
  public abstract boolean isCascaded();

  public abstract Set<GroupConversionDescriptor> getGroupConversions();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.metadata.CascadableDescriptor
 * JD-Core Version:    0.6.2
 */