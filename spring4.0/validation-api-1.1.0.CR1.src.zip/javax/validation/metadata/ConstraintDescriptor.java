package javax.validation.metadata;

import java.lang.annotation.Annotation;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.ConstraintTarget;
import javax.validation.ConstraintValidator;
import javax.validation.Payload;

public abstract interface ConstraintDescriptor<T extends Annotation>
{
  public abstract T getAnnotation();

  public abstract String getMessageTemplate();

  public abstract Set<Class<?>> getGroups();

  public abstract Set<Class<? extends Payload>> getPayload();

  public abstract ConstraintTarget getValidationAppliesTo();

  public abstract List<Class<? extends ConstraintValidator<T, ?>>> getConstraintValidatorClasses();

  public abstract Map<String, Object> getAttributes();

  public abstract Set<ConstraintDescriptor<?>> getComposingConstraints();

  public abstract boolean isReportAsSingleViolation();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.metadata.ConstraintDescriptor
 * JD-Core Version:    0.6.2
 */