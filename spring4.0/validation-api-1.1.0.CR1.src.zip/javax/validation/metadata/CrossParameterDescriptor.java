package javax.validation.metadata;

public abstract interface CrossParameterDescriptor extends ElementDescriptor
{
  public abstract Class<?> getElementClass();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.metadata.CrossParameterDescriptor
 * JD-Core Version:    0.6.2
 */