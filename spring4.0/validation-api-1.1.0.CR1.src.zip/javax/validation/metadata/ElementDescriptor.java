package javax.validation.metadata;

import java.lang.annotation.ElementType;
import java.util.Set;

public abstract interface ElementDescriptor
{
  public abstract boolean hasConstraints();

  public abstract Class<?> getElementClass();

  public abstract Set<ConstraintDescriptor<?>> getConstraintDescriptors();

  public abstract ConstraintFinder findConstraints();

  public static abstract interface ConstraintFinder
  {
    public abstract ConstraintFinder unorderedAndMatchingGroups(Class<?>[] paramArrayOfClass);

    public abstract ConstraintFinder lookingAt(Scope paramScope);

    public abstract ConstraintFinder declaredOn(ElementType[] paramArrayOfElementType);

    public abstract Set<ConstraintDescriptor<?>> getConstraintDescriptors();

    public abstract boolean hasConstraints();
  }
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.metadata.ElementDescriptor
 * JD-Core Version:    0.6.2
 */