package javax.validation.metadata;

import java.util.List;
import java.util.Set;

public abstract interface ExecutableDescriptor extends ElementDescriptor
{
  public abstract String getName();

  public abstract List<ParameterDescriptor> getParameterDescriptors();

  public abstract CrossParameterDescriptor getCrossParameterDescriptor();

  public abstract ReturnValueDescriptor getReturnValueDescriptor();

  public abstract boolean areParametersConstrained();

  public abstract boolean isReturnValueConstrained();

  public abstract boolean hasConstraints();

  public abstract Set<ConstraintDescriptor<?>> getConstraintDescriptors();

  public abstract ElementDescriptor.ConstraintFinder findConstraints();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.metadata.ExecutableDescriptor
 * JD-Core Version:    0.6.2
 */