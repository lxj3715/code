package javax.validation.metadata;

public abstract interface GroupConversionDescriptor
{
  public abstract Class<?> getFrom();

  public abstract Class<?> getTo();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.metadata.GroupConversionDescriptor
 * JD-Core Version:    0.6.2
 */