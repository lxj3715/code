package javax.validation.metadata;

public abstract interface ParameterDescriptor extends ElementDescriptor, CascadableDescriptor
{
  public abstract int getIndex();

  public abstract String getName();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.metadata.ParameterDescriptor
 * JD-Core Version:    0.6.2
 */