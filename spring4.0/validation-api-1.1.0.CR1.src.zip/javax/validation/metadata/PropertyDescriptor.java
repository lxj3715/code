package javax.validation.metadata;

public abstract interface PropertyDescriptor extends ElementDescriptor, CascadableDescriptor
{
  public abstract String getPropertyName();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.metadata.PropertyDescriptor
 * JD-Core Version:    0.6.2
 */