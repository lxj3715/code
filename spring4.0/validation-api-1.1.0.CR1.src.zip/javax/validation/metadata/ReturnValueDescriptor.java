package javax.validation.metadata;

public abstract interface ReturnValueDescriptor extends ElementDescriptor, CascadableDescriptor
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.metadata.ReturnValueDescriptor
 * JD-Core Version:    0.6.2
 */