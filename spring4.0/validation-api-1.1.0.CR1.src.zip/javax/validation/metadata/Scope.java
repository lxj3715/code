/*    */ package javax.validation.metadata;
/*    */ 
/*    */ public enum Scope
/*    */ {
/* 31 */   LOCAL_ELEMENT, 
/*    */ 
/* 37 */   HIERARCHY;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.metadata.Scope
 * JD-Core Version:    0.6.2
 */