package javax.validation.spi;

import javax.validation.ValidationProviderResolver;

public abstract interface BootstrapState
{
  public abstract ValidationProviderResolver getValidationProviderResolver();

  public abstract ValidationProviderResolver getDefaultValidationProviderResolver();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.spi.BootstrapState
 * JD-Core Version:    0.6.2
 */