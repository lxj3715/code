package javax.validation.spi;

import java.io.InputStream;
import java.util.Map;
import java.util.Set;
import javax.validation.ConstraintValidatorFactory;
import javax.validation.MessageInterpolator;
import javax.validation.ParameterNameProvider;
import javax.validation.TraversableResolver;

public abstract interface ConfigurationState
{
  public abstract boolean isIgnoreXmlConfiguration();

  public abstract MessageInterpolator getMessageInterpolator();

  public abstract Set<InputStream> getMappingStreams();

  public abstract ConstraintValidatorFactory getConstraintValidatorFactory();

  public abstract TraversableResolver getTraversableResolver();

  public abstract ParameterNameProvider getParameterNameProvider();

  public abstract Map<String, String> getProperties();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.spi.ConfigurationState
 * JD-Core Version:    0.6.2
 */