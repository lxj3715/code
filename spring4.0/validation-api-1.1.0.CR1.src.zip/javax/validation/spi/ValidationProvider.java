package javax.validation.spi;

import javax.validation.Configuration;
import javax.validation.ValidatorFactory;

public abstract interface ValidationProvider<T extends Configuration<T>>
{
  public abstract T createSpecializedConfiguration(BootstrapState paramBootstrapState);

  public abstract Configuration<?> createGenericConfiguration(BootstrapState paramBootstrapState);

  public abstract ValidatorFactory buildValidatorFactory(ConfigurationState paramConfigurationState);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\validation-api-1.1.0.CR1.jar
 * Qualified Name:     javax.validation.spi.ValidationProvider
 * JD-Core Version:    0.6.2
 */